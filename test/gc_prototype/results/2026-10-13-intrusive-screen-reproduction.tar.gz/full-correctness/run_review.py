import argparse
import contextlib
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

ROOT=Path('/root/.codex/worktrees/f396/medaka')
OUT=Path(__file__).resolve().parent
FROZEN=Path('/tmp/medaka-intrusive-promotion-85')
INPUTS=OUT/'inputs'
FILES=('gc.h','gc.c','workload.c','run.py','adversarial.c','pool_review.c','prepared_api.c',
       'llvm_contract/contract.ll','llvm_contract/driver.c','llvm_contract/validate_llvm.py')

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def prepare():
    manifest=json.loads((FROZEN/'manifest.json').read_text())
    INPUTS.mkdir(exist_ok=True)
    for name in FILES:
        source=FROZEN/'candidate'/name if name in ('gc.c','gc.h','workload.c') else ROOT/'test/gc_prototype'/name
        destination=INPUTS/name
        destination.parent.mkdir(exist_ok=True,parents=True)
        shutil.copyfile(source,destination)
        if name in ('gc.c','gc.h','workload.c'):
            assert sha(destination)==manifest['source_sha256']['candidate'][name]
        else:
            assert destination.read_bytes()==source.read_bytes()
    for name in ('gc.h','workload.c'):
        assert (INPUTS/name).read_bytes()==(FROZEN/'baseline'/name).read_bytes()
    runtime=subprocess.check_output(['git','show',manifest['baseline_commit']+':runtime/medaka_rt.c'],cwd=ROOT)
    assert runtime==(ROOT/'runtime/medaka_rt.c').read_bytes(), 'adapter runtime differs from exact85'
    record={'mode':'full unchanged prototype correctness; no timing execution',
            'module':str(ROOT/'test/gc_prototype/run.py'),
            'module_sha256':sha(ROOT/'test/gc_prototype/run.py'),
            'HERE_override':str(INPUTS),'REPO_override':str(ROOT),
            'argv':['run.py','--correctness-only'],
            'candidate_sha256':manifest['source_sha256']['candidate'],
            'input_sha256':{name:sha(INPUTS/name) for name in FILES},
            'runtime_sha256':hashlib.sha256(runtime).hexdigest(),
            'assertion_changes':'none; existing assertions derive actual static/work metadata dynamically',
            'driver_text':Path(__file__).read_text(),'driver_sha256':sha(Path(__file__))}
    (OUT/'preparation.json').write_text(json.dumps(record,indent=2)+'\n')
    return record

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--execute',action='store_true')
    args=parser.parse_args()
    prepared=prepare()
    if not args.execute:
        print(json.dumps({'prepared':True,'execution_performed':False,'input_sha256':prepared['input_sha256']}))
        return
    assert not (OUT/'execution.json').exists(), 'preserve prior execution evidence'
    for name in list(os.environ):
        if name.startswith(('GC_','MEDAKA_')) or name in ('ASAN_OPTIONS','UBSAN_OPTIONS'):
            os.environ.pop(name)
    compiler=Path(shutil.which('clang')).resolve()
    os.environ.update(CC=str(compiler),ASAN_OPTIONS='detect_leaks=0',UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1',TMPDIR=str(OUT))
    spec=importlib.util.spec_from_file_location('unchanged_gc_correctness',ROOT/'test/gc_prototype/run.py')
    module=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    module.HERE=INPUTS
    module.REPO=ROOT
    real_run=subprocess.run
    commands=[]
    def observed_run(*argv,**kwargs):
        command=argv[0] if argv else kwargs['args']
        env=kwargs.get('env',os.environ)
        record={'argv':[str(x) for x in command],
                'environment':{k:v for k,v in env.items() if k.startswith('GC_') or k in ('CC','ASAN_OPTIONS','UBSAN_OPTIONS')},
                'cwd':str(kwargs.get('cwd',Path.cwd()))}
        try:
            result=real_run(*argv,**kwargs)
            record.update(returncode=result.returncode,stdout=result.stdout,stderr=result.stderr)
            if result.returncode==0 and '-o' in command:
                binary=Path(command[command.index('-o')+1])
                if binary.is_file(): record['binary_sha256']=sha(binary)
            return result
        except subprocess.CalledProcessError as error:
            record.update(returncode=error.returncode,stdout=error.stdout,stderr=error.stderr)
            raise
        except BaseException as error:
            record.update(error=repr(error))
            raise
        finally:
            commands.append(record)
    execution={'prepared':prepared,'compiler_executable':str(compiler),'compiler_sha256':sha(compiler),'status':'running'}
    subprocess.run=observed_run
    sys.argv=['run.py','--correctness-only']
    try:
        with (OUT/'stdout.log').open('w') as stdout, (OUT/'stderr.log').open('w') as stderr:
            with contextlib.redirect_stdout(stdout), contextlib.redirect_stderr(stderr):
                module.main()
        assert {name:sha(INPUTS/name) for name in FILES}==prepared['input_sha256']
        assert sha(ROOT/'test/gc_prototype/run.py')==prepared['module_sha256']
        execution['status']='passed'
        execution['actual_runner_returncode']=0
    except BaseException as error:
        execution['status']='failed'
        execution['error']=repr(error)
        raise
    finally:
        subprocess.run=real_run
        execution['commands']=commands
        execution['build_commands']=module.BUILD_COMMANDS
        execution['inputs_unchanged']={name:sha(INPUTS/name) for name in FILES}==prepared['input_sha256']
        execution['stdout']=(OUT/'stdout.log').read_text()
        execution['stderr']=(OUT/'stderr.log').read_text()
        (OUT/'execution.json').write_text(json.dumps(execution,indent=2)+'\n')
    print(json.dumps({'status':execution['status'],'actual_runner_returncode':execution['actual_runner_returncode'],
                      'stdout_tail':execution['stdout'].splitlines()[-5:],'execution':str(OUT/'execution.json')}))

if __name__=='__main__':
    main()
