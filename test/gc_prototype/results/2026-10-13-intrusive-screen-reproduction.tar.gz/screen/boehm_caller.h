#ifndef PROTOTYPE_BOEHM_CALLER_H
#define PROTOTYPE_BOEHM_CALLER_H
#include <gc/gc.h>
#define GC_ASSERT(expr) ((void)0)
#include <gc/gc_inline.h>
#if GC_VERSION_MAJOR == 8 && GC_VERSION_MINOR == 2
#define MDK_ALLOC_INLINE_LIMIT ((GC_TINY_FREELISTS - 1) * GC_GRANULE_BYTES)
extern __thread void **prototype_caller_freelists;
void *prototype_caller_refill(long long n);
static inline void *prototype_caller_alloc(long long n) {
  size_t size = (size_t)n;
  void **fl = prototype_caller_freelists;
  if (__builtin_expect(fl != NULL && size < MDK_ALLOC_INLINE_LIMIT, 1)) {
    void **slot = fl + (size + GC_GRANULE_BYTES) / GC_GRANULE_BYTES;
    void *r = *slot;
    if (__builtin_expect((GC_word)r > GC_TINY_FREELISTS + 1, 1)) {
      void *next = *(void **)r;
      *slot = next;
      *(void **)r = 0;
      GC_PREFETCH_FOR_WRITE(next);
      GC_end_stubborn_change(slot);
      GC_reachable_here(next);
      return r;
    }
  }
  return prototype_caller_refill(n);
}

#else
static inline void *prototype_caller_alloc(long long n) { return GC_malloc((size_t)n); }
#endif
#endif
