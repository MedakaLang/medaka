#define _POSIX_C_SOURCE 200809L
#include <assert.h>
#include <stdio.h>
#include <sys/resource.h>
int main(void) {
  struct rusage usage;
  assert(getrusage(RUSAGE_SELF, &usage) == 0);
#ifdef __APPLE__
  size_t bytes = (size_t)usage.ru_maxrss;
#else
  size_t bytes = (size_t)usage.ru_maxrss * 1024;
#endif
  printf("{\"launcher_floor_rss_bytes\":%zu}\n", bytes);
  return 0;
}
