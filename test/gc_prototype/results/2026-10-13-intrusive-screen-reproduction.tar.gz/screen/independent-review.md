Independent source and reducer review passed before native execution.

{
  "reviewer": "pool_review",
  "control_count": 51,
  "native_builds_or_workloads": 0,
  "hashes": {
    "run.py": "b44cdedb94e8f1f775a41b266bdd15d74ef16a97fb922e564cce4bc38cd6f6bc",
    "PROTOCOL.md": "67317a985fd26ea1035a7fe0fbdfecdac1e8dc26b880f133064c6a98f7c0386a",
    "reducer_controls.py": "fc1be44e4b7be59358a50c9b67b4c13c88c4ba85735f78e43f8d3bfa4f3b8fa6",
    "reducer-controls.json": "d6b7c11b350f853f79e67d608dfa249f7f8da9e2061fd4d1723b39df3b2177a8"
  },
  "controls_snapshot": "reducer-controls-frozen.md",
  "snapshot_sha256": "d6b7c11b350f853f79e67d608dfa249f7f8da9e2061fd4d1723b39df3b2177a8",
  "freeze": "Runner automatically hashes all .py and .md inputs before and after execution; exact runner source unchanged."
}
