#include <gc/gc.h>
#define GC_ASSERT(expr) ((void)0)
#include <gc/gc_inline.h>
#if GC_VERSION_MAJOR == 8 && GC_VERSION_MINOR == 2

/* The smallest request that does not fit an inline free list: n + 1 rounded up
 * to granules must stay below GC_TINY_FREELISTS. */
#define MDK_ALLOC_INLINE_LIMIT ((GC_TINY_FREELISTS - 1) * GC_GRANULE_BYTES)

static __thread void **mdk_alloc_freelists;

static void **mdk_alloc_freelists_init(void) {
  void **fl = GC_malloc_uncollectable(GC_TINY_FREELISTS * sizeof(void *));
  mdk_alloc_freelists = fl;
  return fl;
}

/* The whole of gc_inline.h's allocation: refill an empty list, or fall back to
 * GC_malloc.  Kept out of line so mdk_alloc's hit path saves no registers. */
static __attribute__((noinline)) void *mdk_alloc_refill(long long n) {
  size_t size = (size_t)n;
  if (size >= MDK_ALLOC_INLINE_LIMIT) return GC_malloc(size);
  size_t granules = (size + GC_GRANULE_BYTES) / GC_GRANULE_BYTES;
  void **fl = mdk_alloc_freelists;
  void *r;
  if (fl == NULL) {
    fl = mdk_alloc_freelists_init();
    if (fl == NULL) return GC_malloc(size);
  }
  GC_FAST_MALLOC_GRANS(r, granules, fl, 0, GC_I_NORMAL, GC_malloc(size),
                       *(void **)r = 0);
  return r;
}

/* The hit branch of GC_FAST_MALLOC_GRANS for the NORMAL kind, step for step: a
 * list entry above GC_TINY_FREELISTS + 1 is an object, not a count or NULL.
 * noinline: inlined, this body makes small runtime helpers that box a result
 * (mdk_num_sub) too large for ThinLTO to inline into emitted code, and keeping
 * those helpers inlinable is worth more than a call here. */
__attribute__((noinline)) void *prototype_inline_alloc(long long n) {
  size_t size = (size_t)n;
  void **fl = mdk_alloc_freelists;
  if (__builtin_expect(fl != NULL && size < MDK_ALLOC_INLINE_LIMIT, 1)) {
    void **slot = fl + (size + GC_GRANULE_BYTES) / GC_GRANULE_BYTES;
    void *r = *slot;
    if (__builtin_expect((GC_word)r > GC_TINY_FREELISTS + 1, 1)) {
      void *next = *(void **)r;
      *slot = next;
      *(void **)r = 0;
      GC_PREFETCH_FOR_WRITE(next);
      GC_end_stubborn_change(slot);
      GC_reachable_here(next);
      return r;
    }
  }
  return mdk_alloc_refill(n);
}

#else
void *prototype_inline_alloc(long long n) { return GC_malloc((size_t)n); }
#endif

#if GC_VERSION_MAJOR == 8 && GC_VERSION_MINOR == 2

/* The smallest request that does not fit an inline free list: n + 1 rounded up
 * to granules must stay below GC_TINY_FREELISTS. */
#define MDK_ALLOC_INLINE_LIMIT ((GC_TINY_FREELISTS - 1) * GC_GRANULE_BYTES)

__thread void **prototype_caller_freelists;

static void **prototype_caller_freelists_init(void) {
  void **fl = GC_malloc_uncollectable(GC_TINY_FREELISTS * sizeof(void *));
  prototype_caller_freelists = fl;
  return fl;
}

/* The whole of gc_inline.h's allocation: refill an empty list, or fall back to
 * GC_malloc.  Kept out of line so prototype_caller's hit path saves no registers. */
__attribute__((noinline)) void *prototype_caller_refill(long long n) {
  size_t size = (size_t)n;
  if (size >= MDK_ALLOC_INLINE_LIMIT) return GC_malloc(size);
  size_t granules = (size + GC_GRANULE_BYTES) / GC_GRANULE_BYTES;
  void **fl = prototype_caller_freelists;
  void *r;
  if (fl == NULL) {
    fl = prototype_caller_freelists_init();
    if (fl == NULL) return GC_malloc(size);
  }
  GC_FAST_MALLOC_GRANS(r, granules, fl, 0, GC_I_NORMAL, GC_malloc(size),
                       *(void **)r = 0);
  return r;
}

/* The hit branch of GC_FAST_MALLOC_GRANS for the NORMAL kind, step for step: a
 * list entry above GC_TINY_FREELISTS + 1 is an object, not a count or NULL.
 * noinline: inlined, this body makes small runtime helpers that box a result
 * (mdk_num_sub) too large for ThinLTO to inline into emitted code, and keeping
 * those helpers inlinable is worth more than a call here. */

#endif

int prototype_inline_enabled(void) {
#if GC_VERSION_MAJOR == 8 && GC_VERSION_MINOR == 2
  return 1;
#else
  return 0;
#endif
}
size_t prototype_inline_root_bytes(void) {
#if GC_VERSION_MAJOR == 8 && GC_VERSION_MINOR == 2
#ifdef USE_CALLER_INLINE
  return prototype_caller_freelists ? GC_TINY_FREELISTS * sizeof(void *) : 0;
#else
  return mdk_alloc_freelists ? GC_TINY_FREELISTS * sizeof(void *) : 0;
#endif
#else
  return 0;
#endif
}
