"""Independent synthetic protocol controls; no native process may execute."""
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import sys

sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('intrusive_screen_review',HERE/'run.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
def forbidden(*args,**kwargs):raise RuntimeError('native execution forbidden in reducer review')
m.command=forbidden
for name in ('run','Popen','check_output','check_call'):setattr(m.subprocess,name,forbidden)
PROFILES=('ephemeral','list','tree','mutation','atomic','mixed','sizes')
CELLS=[(p,n) for p in PROFILES for n in (262144,262136)]+[('tree',16777216),('tree',16777208)]
ARMS=('custom-baseline','custom-intrusive','boehm-historical-default','boehm-historical-fixed128','boehm-caller-default','boehm-caller-fixed128')
PRIMARY=(('tree',262144),('tree',262136))
assert m.CELLS==CELLS and m.ARMS==ARMS
def data():
    rows=[];floors=[]
    for q in range(6):
        for p,n in CELLS:
            floors.append(dict(round=q,profile=p,capacity=n,rss_bytes=5*1048576))
            for i in range(6):
                a=ARMS[(q+i)%6]
                elapsed=(.9 if (p,n) in PRIMARY else 1.) if a=='custom-intrusive' else (1. if a=='custom-baseline' else 1.1+.1*ARMS[2:].index(a))
                row=dict(profile=p,count=5000000,elapsed_seconds=elapsed,preparation_seconds=0,
                    process_peak_rss_bytes=100*1048576,accounted_bytes=1000,peak_accounted_bytes=1200,
                    work_queue_bytes=512,static_metadata_bytes=992,allocations=5000000,
                    copied_bytes=160000000,payload_bytes=120000000,boehm_heap_bytes=1000,
                    boehm_heap_minus_free_bytes=900,boehm_total_allocated_bytes=1100)
                if a=='custom-intrusive':row.update(accounted_bytes=752,peak_accounted_bytes=1000,work_queue_bytes=256,static_metadata_bytes=1000)
                rows.append(dict(round=q,profile=p,capacity=n,position=i,arm=a,row=row))
    return rows,floors
def candidates(rows,cell):return sorted((x for x in rows if (x['profile'],x['capacity'])==cell and x['arm']=='custom-intrusive'),key=lambda x:x['round'])
def baselines(rows,cell):return sorted((x for x in rows if (x['profile'],x['capacity'])==cell and x['arm']=='custom-baseline'),key=lambda x:x['round'])
def ratios(rows,cell,values):
    for c,b,v in zip(candidates(rows,cell),baselines(rows,cell),values):c['row']['elapsed_seconds']=b['row']['elapsed_seconds']*v
def cell(summary,target):return next(x for x in summary['cells'] if (x['profile'],x['capacity'])==target)
checks=[]
def grade(label,rows,floors,advance,predicate=None):
    result=m.summary(rows,floors)
    assert result['screen_advance']==advance,label
    if predicate:assert predicate(result),label
    checks.append(dict(case=label,expected_advance=advance,observed_advance=result['screen_advance'],passed=True))

r,f=data();grade('both primary gains; all controls and RSS safe',r,f,True)
for primary in PRIMARY:
    r,f=data();ratios(r,primary,[.9]*4+[1.,1.]);grade('four of six gains insufficient '+str(primary),r,f,False)
    r,f=data();ratios(r,primary,[.9]*5+[1.2]);grade('five of six gains sufficient '+str(primary),r,f,True)
    r,f=data();ratios(r,primary,[.95]*6);grade('strict .95 equality fails primary '+str(primary),r,f,False)
    r,f=data();ratios(r,primary,[1.]*6);grade('only one primary gaining cannot advance '+str(primary),r,f,False)
for other in (x for x in CELLS if x not in PRIMARY):
    r,f=data();ratios(r,other,[1.06]*6)
    grade('secondary repeatable regression rejects '+str(other),r,f,False,lambda s,t=other:cell(s,t)['repeatable_regression'])
for values,label in (([1.06]*4+[1.,1.],'four secondary regressions remain inconclusive'),([1.05]*6,'strict1.05 equality is not secondary regression')):
    r,f=data();ratios(r,('atomic',262144),values);grade(label,r,f,True,lambda s:not cell(s,('atomic',262144))['repeatable_regression'])
r,f=data()
for b,v in zip(baselines(r,PRIMARY[0]),[1.,1.,1.,100.,100.,100.]):b['row']['elapsed_seconds']=v
ratios(r,PRIMARY[0],[.9,.9,20000.,.9,.9,.9])
grade('paired median qualifies despite ratio-of-medians outlier',r,f,True)
for target in CELLS:
    r,f=data()
    for x in candidates(r,target):x['row']['process_peak_rss_bytes']=111*1048576
    grade('material total RSS above110pct rejects '+str(target),r,f,False,lambda s,t=target:cell(s,t)['RSS_regression'])
r,f=data()
for x in candidates(r,('atomic',262144)):x['row']['process_peak_rss_bytes']=110*1048576
grade('strict110pct RSS equality does not reject',r,f,True)
r,f=data()
for x in f:
    if (x['profile'],x['capacity'])==('atomic',262144):x['rss_bytes']=50*1048576
for x in candidates(r,('atomic',262144)):x['row']['process_peak_rss_bytes']=111*1048576
grade('baseline exactly twice floor is material',r,f,False,lambda s:cell(s,('atomic',262144))['RSS_materially_above_floor'])
r,f=data()
for x in f:
    if (x['profile'],x['capacity'])==('atomic',262144):x['rss_bytes']=51*1048576
for x in candidates(r,('atomic',262144)):x['row']['process_peak_rss_bytes']=500*1048576
grade('below twice floor remains inconclusive without subtraction',r,f,True,lambda s:not cell(s,('atomic',262144))['RSS_materially_above_floor'] and not cell(s,('atomic',262144))['RSS_regression'])
r,f=data()
for x,v in zip((x for x in f if (x['profile'],x['capacity'])==('atomic',262144)),[1,1,49,51,100,100]):x['rss_bytes']=v*1048576
for x in candidates(r,('atomic',262144)):x['row']['process_peak_rss_bytes']=111*1048576
grade('floor uses all-six median rather than maximum',r,f,False)
r,f=data()
for x,v in zip((x for x in f if (x['profile'],x['capacity'])==('atomic',262144)),[1,1,50,52,100,100]):x['rss_bytes']=v*1048576
for x in candidates(r,('atomic',262144)):x['row']['process_peak_rss_bytes']=111*1048576
grade('floor median differs from first/minimum',r,f,True,lambda s:not cell(s,('atomic',262144))['RSS_materially_above_floor'])

r,f=data();base=baselines(r,PRIMARY[0])[0]['row'];candidate=candidates(r,PRIMARY[0])[0]['row']
m.pair(base,candidate)
for label,key,value in (('unexplained logical copy change','copied_bytes',1),('missing static head charge','static_metadata_bytes',999),('missing current accounting charge','accounted_bytes',744),('major-only queue cannot exceed baseline','work_queue_bytes',1024)):
    bad=copy.deepcopy(candidate);bad[key]=value
    if key=='work_queue_bytes':bad['accounted_bytes']=base['accounted_bytes']+8+value-base['work_queue_bytes']
    failed=False
    try:m.pair(base,bad)
    except AssertionError:failed=True
    assert failed,label
    checks.append(dict(case=label,expected_assertion=True,observed_assertion=True,passed=True))
report=dict(status='passed synthetic independent protocol controls; no workloads/processes',count=len(checks),checks=checks,
    runner_sha256=hashlib.sha256((HERE/'run.py').read_bytes()).hexdigest(),
    protocol_sha256=hashlib.sha256((HERE/'PROTOCOL.md').read_bytes()).hexdigest(),
    fixture_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    interpretation='Artificial deterministic times/RSS exercise frozen threshold boundaries and collection accounting guards; no performance estimates are drawn.')
(HERE/'reducer-controls.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(dict(status=report['status'],count=len(checks),runner_sha256=report['runner_sha256'])))
