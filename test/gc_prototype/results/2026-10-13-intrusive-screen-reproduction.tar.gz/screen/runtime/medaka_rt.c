/* Medaka native runtime — Stage 2.4 DE-RISKING SPIKE (slices 1–3).
 *
 * This is NOT the real runtime.  It is the minimal C stub the spike's emitted
 * LLVM IR links against to prove the emit -> clang -> link -> run -> diff
 * toolchain end-to-end (see compiler/STAGE2-DESIGN.md §2.4 and the "Value
 * representation & calling convention" section of compiler/RUNTIME-DESIGN.md).
 *
 * Scope discipline (matches the emitter): integers, floats, booleans, let, if,
 * functions, (slice 3) algebraic data types + pattern matching, and (native
 * extern catalog slice 1) heap Strings + the minimal string/IO leaf externs
 * (`mdk_str_lit`, `mdk_print_str`, `mdk_int_to_string`).  ADT and String cells
 * box through the same mdk_alloc below.  No closures / records / dispatch beyond
 * what the emitter already drives.
 *
 * VALUE REPRESENTATION (PROVISIONAL — see RUNTIME-DESIGN.md, revisable):
 *   A Medaka value is a uniform 64-bit word (`i64` in the IR).
 *     - Integers are IMMEDIATE: word = (n << 1) | 1   (low bit 1 => tagged int).
 *       63-bit signed range; untag = word >> 1 (arithmetic).
 *     - Booleans reuse the immediate-int encoding (0 / 1) — slice 1 is statically
 *       typed, so the emitter picks the print routine by static type and never
 *       needs to tell a Bool from an Int at runtime.  A polymorphic rep will need
 *       to (a documented limitation surfaced by this spike).
 *     - Floats are BOXED: word is a pointer (low bit 0, malloc is >=8-aligned) to
 *       a 16-byte heap cell { i64 header = TAG_FLOAT, double payload }.  This is
 *       what surfaces "floats don't fit in a tagged-int word" -> the alloc below.
 *     - ADT values are BOXED (slice 3): word is a pointer to a cell
 *       { i64 tag (constructor name hashed), field0, field1, ... } — one 8-byte
 *       word each.  Same boxed-pointer discipline as Float, extended to n fields;
 *       allocated through the same mdk_alloc.
 *
 * The tag arithmetic lives in the EMITTED IR (so the cost is visible); these
 * helpers take/return *native* C scalars (the emitter untags/unboxes first).
 *
 * GC: the spike now runs on the Boehm conservative collector (bdw-gc).  mdk_alloc
 *   routes to GC_malloc; immediates are odd words (low bit 1), so Boehm never
 *   mistakes an Int/Char/Bool/Unit/nullary-ctor for a pointer, and every boxed
 *   value is an 8-byte-aligned real pointer Boehm tracks natively
 *   (RUNTIME-DESIGN.md §8.0 fact 3, §8.1).  Precise GC remains future work.
 */
/* _GNU_SOURCE: on glibc/Linux, pthread_getattr_np (used by the P0-2 fault
 * backstop to find the worker stack bounds) is only declared under it.  No-op on
 * Darwin, which uses pthread_get_stackaddr_np instead. */
#ifndef _GNU_SOURCE
#define _GNU_SOURCE
#endif
#include <dirent.h>
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#include <math.h>
#include <string.h>
#include <stdnoreturn.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <time.h>
#include <unistd.h>
#include <sys/wait.h>
#include <signal.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <netdb.h>
#include <arpa/inet.h>
#include <poll.h>
#include <fcntl.h>
#include <stdint.h>
#include <sys/random.h>
#ifdef __APPLE__
#include <mach-o/dyld.h>
#endif
#include <pthread.h>
/* GC_THREADS MUST be defined before <gc.h> so Boehm exposes GC_pthread_create /
 * GC_pthread_join.  The compiler runs its whole pipeline on a large-stack worker
 * thread (see `int main` at the bottom of this file); a thread created with raw
 * pthread_create would NOT have its stack registered as a GC root, so Boehm would
 * collect still-live objects and corrupt the heap.  GC_pthread_create registers
 * the worker's stack, keeping conservative scanning correct on it. */
#define GC_THREADS
#include <gc.h>
/* gc_inline.h asserts each allocation's size with GC_size, a call per cell, unless
 * GC_ASSERT is already defined.  mdk_alloc's fast path must not pay it. */
#define GC_ASSERT(expr) ((void)0)
#include <gc/gc_inline.h>

/* Initial heap to pre-expand, in bytes, for the COMPILER/CLI only: the stage-B
 * provenance object (test/build_native_medaka.sh) defines this for ./medaka. Every
 * other link (user programs, the emitter, the seed) keeps the weak 0, so none of
 * them pre-expand the heap. An explicit GC_INITIAL_HEAP_SIZE in the environment wins. */
__attribute__((weak)) const long long mdk_gc_initial_heap_bytes = 0;

/* Initialize Boehm once before main().  This runtime owns `int main` (bottom of
 * this file); the emitted IR's entry is `mdk_program_main`, which we run on a
 * GC_pthread_create'd large-stack worker thread.  A constructor runs first, near
 * the bottom of the process stack, which is where GC_INIT wants to capture the
 * (main-thread) stack base; the worker thread's own stack is registered
 * separately by GC_pthread_create.  GC_malloc would otherwise lazily init on its
 * first call. */

__attribute__((constructor)) static void mdk_gc_init(void) {
  GC_INIT();
  if (mdk_gc_initial_heap_bytes > 0 && !getenv("GC_INITIAL_HEAP_SIZE"))
    GC_expand_hp((size_t)mdk_gc_initial_heap_bytes);
  /* Perf tuning (compiler/PERF-RESULTS.md): Medaka workloads are
   * allocation-heavy and mostly short-lived (the emitter alone allocates
   * ~4200 cells/run plus every cons/closure/ADT).  The default free-space
   * divisor (3) collects aggressively to keep RSS low; we trade some memory
   * for fewer collection pauses by letting the heap grow further between GCs.
   * Env var GC_FREE_SPACE_DIVISOR still overrides this if set. */
  if (!getenv("GC_FREE_SPACE_DIVISOR")) GC_set_free_space_divisor(1);
}

/* Allocate `n` bytes in the GC heap, with GC_malloc's semantics (conservative,
 * collected); every extern that RETURNS a Medaka value goes through this single
 * entry point, so the malloc->GC swap was one function (RUNTIME-DESIGN.md §2a).
 * The result is >=8-byte-aligned, zeroed memory — satisfying the boxed-pointer
 * alignment contract the value rep relies on.  The emitted IR declares this with
 * allockind("alloc,zeroed") and noalias, so LLVM may delete an unused cell and
 * forward its stores: the function must stay free of observable side effects
 * beyond the allocation, and must return zeroed memory.
 *
 * On libgc 8.2, small cells come from this thread's own free lists through
 * Boehm's inline allocator (gc_inline.h) rather than GC_malloc, which per call
 * saves its registers, looks up libgc's thread-local lists and goes through
 * GC_malloc_kind (#503).  The contract holds the same way GC_malloc's own
 * thread-local path keeps it, which uses the same macro:
 *   - size: a request takes the granule count GC_malloc would give it, `n` plus
 *     the one byte Boehm appends when interior pointers are recognised, rounded
 *     up to 16-byte granules.  gc_inline.h leaves that byte to the caller, and the
 *     collector does not trace an object's last word on the assumption it is
 *     there.  Any `n` that is not below MDK_ALLOC_INLINE_LIMIT as an unsigned
 *     size, a negative one included, goes to GC_malloc unchanged.
 *   - zeroed: a NORMAL-kind free list holds cleared objects whose first word
 *     links to the next; the hit path clears that word.
 *   - retention: the list heads live in an uncollectable block, which the
 *     collector scans, so each list's first object is reachable from it and
 *     every later one from the link word of the one before.  A thread-local
 *     head alone would not do, since Boehm does not scan thread-local storage
 *     on every platform; the thread-local variable only finds the block.  The
 *     block is never freed, so each thread that allocates keeps one, and the
 *     cells on its lists, for the life of the process.
 * Only the NORMAL kind takes this path.  A pointer-free object's link word is
 * never traced, so a PTRFREE list kept this way would lose all but its head.
 * The hit path copies libgc 8.2's free-list encoding, so other versions use
 * GC_malloc. */
#if GC_VERSION_MAJOR == 8 && GC_VERSION_MINOR == 2

/* The smallest request that does not fit an inline free list: n + 1 rounded up
 * to granules must stay below GC_TINY_FREELISTS. */
#define MDK_ALLOC_INLINE_LIMIT ((GC_TINY_FREELISTS - 1) * GC_GRANULE_BYTES)

static __thread void **mdk_alloc_freelists;

static void **mdk_alloc_freelists_init(void) {
  void **fl = GC_malloc_uncollectable(GC_TINY_FREELISTS * sizeof(void *));
  mdk_alloc_freelists = fl;
  return fl;
}

/* The whole of gc_inline.h's allocation: refill an empty list, or fall back to
 * GC_malloc.  Kept out of line so mdk_alloc's hit path saves no registers. */
static __attribute__((noinline)) void *mdk_alloc_refill(long long n) {
  size_t size = (size_t)n;
  if (size >= MDK_ALLOC_INLINE_LIMIT) return GC_malloc(size);
  size_t granules = (size + GC_GRANULE_BYTES) / GC_GRANULE_BYTES;
  void **fl = mdk_alloc_freelists;
  void *r;
  if (fl == NULL) {
    fl = mdk_alloc_freelists_init();
    if (fl == NULL) return GC_malloc(size);
  }
  GC_FAST_MALLOC_GRANS(r, granules, fl, 0, GC_I_NORMAL, GC_malloc(size),
                       *(void **)r = 0);
  return r;
}

/* The hit branch of GC_FAST_MALLOC_GRANS for the NORMAL kind, step for step: a
 * list entry above GC_TINY_FREELISTS + 1 is an object, not a count or NULL.
 * noinline: inlined, this body makes small runtime helpers that box a result
 * (mdk_num_sub) too large for ThinLTO to inline into emitted code, and keeping
 * those helpers inlinable is worth more than a call here. */
__attribute__((noinline)) void *mdk_alloc(long long n) {
  size_t size = (size_t)n;
  void **fl = mdk_alloc_freelists;
  if (__builtin_expect(fl != NULL && size < MDK_ALLOC_INLINE_LIMIT, 1)) {
    void **slot = fl + (size + GC_GRANULE_BYTES) / GC_GRANULE_BYTES;
    void *r = *slot;
    if (__builtin_expect((GC_word)r > GC_TINY_FREELISTS + 1, 1)) {
      void *next = *(void **)r;
      *slot = next;
      *(void **)r = 0;
      GC_PREFETCH_FOR_WRITE(next);
      GC_end_stubborn_change(slot);
      GC_reachable_here(next);
      return r;
    }
  }
  return mdk_alloc_refill(n);
}

#else
void *mdk_alloc(long long n) { return GC_malloc((size_t)n); }
#endif

/* Allocate `n` bytes of POINTER-FREE memory (raw bytes / string cells).  Routes to
 * Boehm's GC_malloc_atomic: the block is never scanned for pointers during mark, so
 * the GC does not waste mark time walking string contents (the emitter produces an
 * enormous volume of transient string garbage).  Callers MUST fully initialise the
 * block before any read — GC_malloc_atomic does not zero — and the block MUST contain
 * no pointers the collector needs to follow.  String cells qualify: their header is
 * three integer words (tag, byte_len, cp_count) followed by raw UTF-8 bytes, all
 * written by mdk_str_lit; no field is a heap pointer.  The emitted IR declares this
 * with allockind("alloc,uninitialized") and noalias: LLVM assumes the contents are
 * unspecified and that the call has no side effect beyond the allocation. */
void *mdk_alloc_atomic(long long n) { return GC_malloc_atomic((size_t)n); }

/* ---- generic arity-aware closure application (partial application / PAPs) ----
 *
 * A CLOSURE cell is `[ i64 arity | i64 code_ptr | captures... ]`: field 0 is the
 * closure's callable arity (the number of value args its lifted `@mdk_lamN` define
 * takes AFTER the leading `%clos` word), field 1 the code pointer.  The emitter
 * calls a closure INLINE (`code_ptr(cw, args...)`) only when it can prove the
 * supplied count equals the runtime arity; otherwise it routes through __mdk_apply.
 *
 * A PARTIAL APPLICATION (PAP) is `[ i64 -1 | i64 orig_cw | i64 n_supplied |
 * supplied_args... ]`: the -1 header sentinel (never equals a real supplied count
 * >= 1) forces every application of a PAP through __mdk_apply, which FLATTENS it —
 * re-dispatching the original closure against (already-supplied ++ new) args.  So a
 * PAP is never called via the inline fast path and needs no per-arity trampoline. */
#define MDK_MAX_ARITY 16

typedef long long mdk_i64;

mdk_i64 __mdk_apply(mdk_i64 cw, mdk_i64 argc, const mdk_i64 *argv);

/* call `code`(cw, argv[0..argc-1]) — argc statically-typed via a small switch. */
static mdk_i64 mdk_call_exact(mdk_i64 code, mdk_i64 cw, mdk_i64 argc,
                              const mdk_i64 *a) {
  switch (argc) {
    case 0:  return ((mdk_i64(*)(mdk_i64))code)(cw);
    case 1:  return ((mdk_i64(*)(mdk_i64,mdk_i64))code)(cw,a[0]);
    case 2:  return ((mdk_i64(*)(mdk_i64,mdk_i64,mdk_i64))code)(cw,a[0],a[1]);
    case 3:  return ((mdk_i64(*)(mdk_i64,mdk_i64,mdk_i64,mdk_i64))code)(cw,a[0],a[1],a[2]);
    case 4:  return ((mdk_i64(*)(mdk_i64,mdk_i64,mdk_i64,mdk_i64,mdk_i64))code)(cw,a[0],a[1],a[2],a[3]);
    case 5:  return ((mdk_i64(*)(mdk_i64,mdk_i64,mdk_i64,mdk_i64,mdk_i64,mdk_i64))code)(cw,a[0],a[1],a[2],a[3],a[4]);
    case 6:  return ((mdk_i64(*)(mdk_i64,mdk_i64,mdk_i64,mdk_i64,mdk_i64,mdk_i64,mdk_i64))code)(cw,a[0],a[1],a[2],a[3],a[4],a[5]);
    case 7:  return ((mdk_i64(*)(mdk_i64,mdk_i64,mdk_i64,mdk_i64,mdk_i64,mdk_i64,mdk_i64,mdk_i64))code)(cw,a[0],a[1],a[2],a[3],a[4],a[5],a[6]);
    case 8:  return ((mdk_i64(*)(mdk_i64,mdk_i64,mdk_i64,mdk_i64,mdk_i64,mdk_i64,mdk_i64,mdk_i64,mdk_i64))code)(cw,a[0],a[1],a[2],a[3],a[4],a[5],a[6],a[7]);
    default:
      /* arity > 8: saturate 8 at a time, then apply the surplus. */
      {
        mdk_i64 r = ((mdk_i64(*)(mdk_i64,mdk_i64,mdk_i64,mdk_i64,mdk_i64,mdk_i64,mdk_i64,mdk_i64,mdk_i64))code)
                      (cw,a[0],a[1],a[2],a[3],a[4],a[5],a[6],a[7]);
        return __mdk_apply(r, argc - 8, a + 8);
      }
  }
}

/* build a PAP capturing `cw` plus the `argc` args already supplied. */
static mdk_i64 mdk_make_pap(mdk_i64 cw, mdk_i64 argc, const mdk_i64 *argv) {
  mdk_i64 *cell = (mdk_i64 *)mdk_alloc((long long)(8 * (3 + argc)));
  cell[0] = -1;         /* PAP sentinel header */
  cell[1] = cw;         /* the original closure */
  cell[2] = argc;       /* number of args captured so far */
  for (mdk_i64 i = 0; i < argc; i++) cell[3 + i] = argv[i];
  return (mdk_i64)cell;
}

/* apply the closure/PAP word `cw` to `argc` args (a pointer to `argc` i64 words).
 * The single entry point for any application the emitter could not resolve to an
 * exact-arity inline call. */
mdk_i64 __mdk_apply(mdk_i64 cw, mdk_i64 argc, const mdk_i64 *argv) {
  mdk_i64 *cell = (mdk_i64 *)cw;
  if (cell[0] == -1) {
    /* PAP: flatten — combine already-supplied args with the new ones and
     * re-dispatch against the underlying closure. */
    mdk_i64 orig = cell[1];
    mdk_i64 nsup = cell[2];
    mdk_i64 total = nsup + argc;
    mdk_i64 stackbuf[2 * MDK_MAX_ARITY];
    mdk_i64 *buf = stackbuf;
    if (total > (mdk_i64)(2 * MDK_MAX_ARITY))
      buf = (mdk_i64 *)mdk_alloc((long long)(8 * total));
    for (mdk_i64 i = 0; i < nsup; i++) buf[i] = ((mdk_i64 *)cw)[3 + i];
    for (mdk_i64 i = 0; i < argc; i++) buf[nsup + i] = argv[i];
    return __mdk_apply(orig, total, buf);
  }
  {
    mdk_i64 arity = cell[0];
    mdk_i64 code = cell[1];
    if (argc == arity) return mdk_call_exact(code, cw, argc, argv);
    if (argc < arity) return mdk_make_pap(cw, argc, argv);
    /* over-application: saturate `arity`, then apply the surplus to the result. */
    {
      mdk_i64 r = mdk_call_exact(code, cw, arity, argv);
      return __mdk_apply(r, argc - arity, argv + arity);
    }
  }
}

/* Forward-declared: defined below (near mdk_putstr) alongside the rest of the
   "run drops stdout on panic" stash/flush machinery; mdk_oob is an abort path
   that needs it but is emitted earlier in this file. */
static void mdk_flush_run_stdout_on_abort(void);

noreturn void mdk_oob(void) {
  mdk_flush_run_stdout_on_abort();
  fprintf(stderr, "runtime error [E-INDEX-OOB]: index out of bounds\n");
  exit(1);
}

/* Out-of-range access raised by a container's own Index/IndexMut impl that already
 * knows what it wants to say (`indexError : String -> a`), as opposed to mdk_oob_at
 * below, which is handed a bare index and does the wording here.  A container keyed
 * by something other than an Int -- a map, a set -- has no number to interpolate, so
 * the message has to travel.
 *
 * `w` is a tagged pointer to a Medaka string cell, the same rep mdk_panic reads: byte
 * length in word 1, bytes at +24.  Unlike mdk_panic there is no 0x01-sentinel branch,
 * because no caller here hands over a pre-formatted diagnostic -- every one passes
 * plain prose, so the coded banner is unconditional. */
noreturn void mdk_oob_msg(long long w) {
  mdk_flush_run_stdout_on_abort();
  const char *cell = (const char *)w;
  long long byte_len = ((const long long *)cell)[1];
  fputs("runtime error [E-INDEX-OOB]: ", stderr);
  fwrite(cell + 24, 1, (size_t)byte_len, stderr);
  fputc('\n', stderr);
  exit(1);
}

/* Out-of-range `arr[i]` / `arr[i] := v` raised by a container's OWN Index/IndexMut
 * impl, carrying the offending index (#1787).  `idx` is a RAW (already >>1-untagged)
 * i64, matching mdk_slice_oob's convention.
 *
 * Why this exists rather than letting the impl interpolate its own message and pass
 * it to mdk_oob: mdk_oob takes no argument, so the message the impl built was
 * evaluated and DISCARDED on native -- `run` printed "index 7 out of bounds" while a
 * built binary printed "index out of bounds" for the same program.  The dead
 * interpolation was not free: it cost ~10 points of LLVM inline cost, which put
 * `index`/`setIndex` at 235 against a threshold of 225 and stopped them being inlined
 * into hot loops, making `arr[i] := v` ~15% slower than the `Array.set` function it
 * desugars to.  Formatting here fixes both: the engines agree, and the impl's cold
 * branch is one call. */
noreturn void mdk_oob_at(long long idx) {
  mdk_flush_run_stdout_on_abort();
  fprintf(stderr, "runtime error [E-INDEX-OOB]: index %lld out of bounds\n", idx);
  exit(1);
}

/* Out-of-range `arr.[lo..hi]` / `arr.[lo..=hi]` (#550).  The emitted slice used to
 * allocate `end - lo` slots and copy `a[lo + i]` with NO bounds check, so an
 * over-range slice READ OFF THE END OF THE HEAP and surfaced whatever it found —
 * including live pointers — as ordinary Ints, at exit 0.  `run` raised E-SLICE-OOB
 * all along (sliceArray, compiler/eval/eval.mdk); only the native path was unchecked.
 *
 * `lo`/`hi_incl` are RAW (already >>1-untagged) i64s, and `hi_incl` is the INCLUSIVE
 * upper bound (end - 1) so the text is byte-identical to the interpreter's
 * `slice [\{lo}..\{hiX - 1}] out of bounds`.  Unlike mdk_oob (whose message carries no
 * number, so it needs no args) exact parity with `run` is cheap here: this is an abort
 * path, so the two extra argument words cost nothing on the hot path. */
noreturn void mdk_slice_oob(long long lo, long long hi_incl) {
  mdk_flush_run_stdout_on_abort();
  fprintf(stderr, "runtime error [E-SLICE-OOB]: slice [%lld..%lld] out of bounds\n",
          lo, hi_incl);
  exit(1);
}

/* #561 PR-A: a top-level nullary value global that refers to itself during its own
 * initialization (a non-productive cyclic value, e.g. `x = x + 1`, or a mutual
 * `a = b; b = a`).  The native backend emits such globals LAZILY — forced on first
 * use, with a per-global state flag (@mdk_gs_<name>) black-holed to state 1 while the
 * body runs — and re-entering a still-forcing cell calls this, matching the reference
 * engine (eval)'s forceMemo/blackholeCell E-CYCLIC-VALUE.  `name` is a static C string
 * naming the offending binding.  Flushes buffered stdout on the abort path exactly as
 * mdk_oob/mdk_slice_oob do (the "run drops stdout on panic" machinery). */
noreturn void mdk_cyclic_value(const char* name) {
  mdk_flush_run_stdout_on_abort();
  fprintf(stderr,
          "runtime error [E-CYCLIC-VALUE]: %s refers to itself during initialization (non-productive cyclic value)\n",
          name);
  exit(1);
}

/* Print an Int.  Matches the tree-walker oracle: Eval.pp_value (VInt n) =
 * string_of_int n, then eval_probe adds a trailing newline. */
void mdk_print_int(long long v) { printf("%lld\n", v); }

/* Print a Bool for the VALUE-MAIN auto-print (emitPrint LTBool -> the sole caller;
 * llvm_emit.mdk's `if mainIsUnit e mty then () else emitPrint e mv mty`).
 *
 * Renders the CONSTRUCTOR names `True`/`False` — Medaka's own `impl Display Bool`
 * (stdlib/core.mdk: `display True = "True"`).  That is the contract a SHIPPING
 * binary produces: `medaka build` runs the composite-main auto-print wrap
 * (compiler/driver/main_autoprint.mdk), which rewrites `main = <e>` into
 * `main = println <e>`, so a Bool value-main renders through `display`.  The WasmGC
 * backend's peer ($mdk_print_bool in compiler/backend/wasm_preamble.mdk) already
 * writes "True"/"False", with a comment saying it MUST agree with native's
 * println/display — this function was the last holdout.
 *
 * It previously printed OCaml's `string_of_bool` ("true"/"false") to match the
 * OCaml oracle's Eval.pp_value.  That oracle was REMOVED 2026-06-26, so the
 * lowercase rendering survived only in the PRELUDE-FREE emit probes
 * (test/bin/llvm_emit_main), where no `println` is in scope and the wrap cannot
 * fire.  That is why test/diff_compiler_llvm.sh was grading a rendering no
 * `medaka build` binary can ever emit. */
void mdk_print_bool(long long v) { printf(v ? "True\n" : "False\n"); }

/* Render the canonical Medaka float lexeme into `out` (needs >= 32 bytes).
 *
 * DECIDED 2026-06-15 / REVISED 2026-07-15 (issue #57): SHORTEST-ROUND-TRIP.  The
 * lexeme is the fewest significant digits that `strtod` reads back to the
 * bit-identical double — so `debug (0.1 + 0.2)` renders "0.30000000000000004",
 * not the old "%.12g" truncation "0.3".  Digits come from `%.*e` at the smallest
 * precision whose round-trip is bit-exact (compared as uint64 bit patterns, not
 * `double ==`, so a NaN can never spuriously match).
 *
 * The EXPONENT THRESHOLD is unchanged from the historical "%.12g" rule
 * (scientific iff decimal exponent < -4 or >= 12), so whole/round values still
 * print "N.0" (100.0, not "1e+02") and only values that genuinely need >12 sig
 * digits move.  Scientific form is lowercase 'e' + sign + 2-digit-padded exponent
 * (e.g. "1e-07", "1e+20"), which the post-#51 lexer reads back.  The ".0" append
 * rule tags a bare-integer lexeme (no '.'/'e').  inf/nan pass through untouched
 * ("inf"/"-inf"/"nan"), never the loop.  This helper is the SINGLE source of truth
 * shared by mdk_print_float (bare-Float auto-print) and mdk_float_to_string (the
 * floatToString extern) — they MUST stay byte-identical, and both mirror the JS
 * host copies in test/wasm/run.js and playground/worker.js. */
static void mdk_float_lexeme(double d, char *out) {
  if (isnan(d)) { strcpy(out, "nan"); return; }
  if (isinf(d)) { strcpy(out, d < 0 ? "-inf" : "inf"); return; }
  if (d == 0.0) { strcpy(out, (1.0 / d < 0) ? "-0.0" : "0.0"); return; }

  /* shortest significant-digit count: %.*e with precision p-1 == p sig digits. */
  char sci[64];
  int p;
  for (p = 1; p <= 17; p++) {
    snprintf(sci, sizeof sci, "%.*e", p - 1, d);
    double rt = strtod(sci, NULL);
    uint64_t a, b;
    memcpy(&a, &rt, 8);
    memcpy(&b, &d, 8);
    if (a == b) break;
  }
  if (p > 17) snprintf(sci, sizeof sci, "%.*e", 16, d);

  /* parse sci = [-]d[.ddd]e(+|-)XX into sign, digit string, decimal exponent. */
  const char *s = sci;
  int neg = 0;
  if (*s == '-') { neg = 1; s++; }
  char digits[40];
  int nd = 0;
  digits[nd++] = *s++;                 /* leading significant digit */
  if (*s == '.') { s++; while (*s != 'e' && *s != 'E') digits[nd++] = *s++; }
  int exp = atoi(s + 1);               /* s points at 'e' */
  digits[nd] = '\0';
  while (nd > 1 && digits[nd - 1] == '0') digits[--nd] = '\0';  /* trim (defensive) */

  char body[80];
  if (exp < -4 || exp >= 12) {
    char mant[48];
    if (nd == 1) { mant[0] = digits[0]; mant[1] = '\0'; }
    else { mant[0] = digits[0]; mant[1] = '.'; strcpy(mant + 2, digits + 1); }
    snprintf(body, sizeof body, "%se%c%02d", mant, exp < 0 ? '-' : '+',
             exp < 0 ? -exp : exp);
  } else {
    int pp = exp + 1;                  /* digits before the decimal point */
    if (pp <= 0) {
      char z[24];
      int i;
      for (i = 0; i < -pp; i++) z[i] = '0';
      z[i] = '\0';
      snprintf(body, sizeof body, "0.%s%s", z, digits);
    } else if (pp >= nd) {
      char z[24];
      int i;
      for (i = 0; i < pp - nd; i++) z[i] = '0';
      z[i] = '\0';
      snprintf(body, sizeof body, "%s%s", digits, z);
    } else {
      char head[40];
      memcpy(head, digits, (size_t)pp);
      head[pp] = '\0';
      snprintf(body, sizeof body, "%s.%s", head, digits + pp);
    }
  }

  char full[96];
  if (neg) snprintf(full, sizeof full, "-%s", body);
  else     snprintf(full, sizeof full, "%s", body);
  if (!strpbrk(full, ".eEni")) strcat(full, ".0");  /* bare-int lexeme -> N.0 */
  strcpy(out, full);
}

/* Print a bare Float (the auto-print sink) via the shared canonical lexeme. */
void mdk_print_float(double d) {
  char buf[96];
  mdk_float_lexeme(d, buf);
  printf("%s\n", buf);
}

/* ── Strings (native extern catalog, slice 1) ────────────────────────────────
 * STRING REPRESENTATION — LOCKED 2026-06-07 (RUNTIME-DESIGN.md §4 / §7 decision
 * 2): UTF-8 bytes + a CACHED codepoint count, boxed as one GC cell:
 *
 *   offset  0:  i64 header     layout id (MDK_STR_TAG; not yet tag-tested — no
 *                              String match heads in this slice)
 *   offset  8:  i64 byte_len   number of UTF-8 bytes (raw / untagged)
 *   offset 16:  i64 cp_count   cached codepoint count  ->  stringLength is O(1)
 *   offset 24:  byte_len bytes of UTF-8, then a NUL (for cheap C interop)
 *
 * Caching cp_count is the choice §4 calls for (Medaka is codepoint-aware): it
 * makes `stringLength` INTRINSIC (a header read) rather than an O(n) scan — see
 * the §5 (rep)-row reconciliation in RUNTIME-DESIGN.md.  The cell rides the same
 * one-word-header boxed-pointer discipline (§8.1 / §8.4) as every other heap
 * value, so it is GC-managed for free under Boehm: the value word is an aligned
 * pointer (low bit 0) Boehm tracks, and the inline bytes are scanned harmlessly.
 *
 * Per §2a, every extern that RETURNS a Medaka String allocates it here, through
 * mdk_alloc, with this exact layout — it never hands back a
 * native-owned buffer.  mdk_int_to_string is the first such extern. */
#define MDK_STR_TAG 1

/* BYTEBLOCK REPRESENTATION — the packed byte buffer behind the `ByteBlock`
 * builtin (stdlib/runtime.mdk, "Byte blocks"), boxed as one GC cell:
 *
 *   offset  0:  i64 header     MDK_BYTEBLOCK_TAG
 *   offset  8:  i64 count      number of bytes (raw / untagged)
 *   offset 16:  count bytes, padded up to a whole word
 *
 * The header sits at offset 0, unlike the array cell, whose word 0 is its raw
 * element count -- so a length-1 array is indistinguishable from a String cell
 * and a byte block must not be given that shape.  The value is a composite in
 * the reserved type-id range (slot 4; see the MDK_TAG block below and
 * `reservedTag` in compiler/backend/llvm_emit.mdk), which no user constructor
 * tag and no other cell header can reach.  The _Static_assert beside MDK_TAG
 * pins this spelling to that formula.
 *
 * The payload holds no pointers and the two header words are integers, so the
 * cell is allocated pointer-free through mdk_alloc_atomic, exactly as a String
 * cell is; mdk_alloc_atomic does not zero, so mdk_byteblock_alloc memsets. */
#define MDK_BYTEBLOCK_TAG ((65536LL + 4LL) * 4294967296LL)

/* U64 REPRESENTATION — the boxed 64-bit unsigned integer behind the `U64`
 * builtin (docs/design/INTEGER-TYPES-DESIGN.md section 6.2), Float's cell shape:
 *
 *   offset  0:  i64 header     MDK_U64_TAG
 *   offset  8:  u64 payload    the value, all 64 bits
 *
 * The header is reserved type-id 5 (`u64CellTag` in
 * compiler/backend/llvm_emit.mdk), pinned to MDK_TAG(5, 0) beside the byte
 * block's assertion.  The cell holds no pointers, so it is allocated through
 * mdk_alloc_atomic; a literal is a private constant cell the emitter lays out
 * the same way, so nothing may write through a U64 word.  The type-lost
 * discriminators below (mdk_value_eq, mdk_value_cmp_raw, mdk_value_lt/le/gt/ge,
 * mdk_num_*, mdk_print_num) order and compute on the unsigned payload. */
#define MDK_U64_TAG ((65536LL + 5LL) * 4294967296LL)

static int mdk_is_u64(long long w) {
  return ((w & 1) == 0) && ((const long long *)w)[0] == MDK_U64_TAG;
}

static unsigned long long mdk_u64_payload(long long w) {
  return ((const unsigned long long *)w)[1];
}

static long long mdk_box_u64(unsigned long long x) {
  long long *c = (long long *)mdk_alloc_atomic(16);
  c[0] = MDK_U64_TAG;
  ((unsigned long long *)c)[1] = x;
  return (long long)c;
}

/* The auto-print sink for a `U64` result: the decimal value, as the
 * interpreter's `ppValue (VU64 …)` renders it. */
void mdk_print_u64(long long w) { printf("%llu\n", mdk_u64_payload(w)); }

/* I64 REPRESENTATION — the boxed 64-bit signed integer behind the `I64` builtin:
 * U64's cell shape and payload, the 64 bits read in two's complement, under a
 * header of its own (reserved type-id 6, `i64CellTag` in
 * compiler/backend/llvm_emit.mdk, pinned to MDK_TAG(6, 0) below).  The distinct
 * header is what lets the type-lost discriminators order, divide and print an
 * I64 signed where a U64 is unsigned. */
#define MDK_I64_TAG ((65536LL + 6LL) * 4294967296LL)

static int mdk_is_i64(long long w) {
  return ((w & 1) == 0) && ((const long long *)w)[0] == MDK_I64_TAG;
}

static long long mdk_i64_payload(long long w) {
  return ((const long long *)w)[1];
}

static long long mdk_box_i64(long long x) {
  long long *c = (long long *)mdk_alloc_atomic(16);
  c[0] = MDK_I64_TAG;
  c[1] = x;
  return (long long)c;
}

/* `/` and `%` at I64: truncating, as C's, with `minBound / -1` wrapping to
 * minBound and `minBound % -1` giving 0 (C's own quotient there is undefined). */
static long long mdk_i64_div(long long a, long long b) {
  return b == -1 ? (long long)(0ULL - (unsigned long long)a) : a / b;
}

static long long mdk_i64_mod(long long a, long long b) {
  return b == -1 ? 0 : a % b;
}

/* The auto-print sink for an `I64` result: the signed decimal value. */
void mdk_print_i64(long long w) { printf("%lld\n", mdk_i64_payload(w)); }

/* Byte-block content discriminators, used by mdk_value_eq / mdk_value_cmp_raw /
 * mdk_append below; defined with the rest of the byte-block family, beside the
 * array leaf helpers it mirrors. */
static int mdk_is_byteblock(long long w);
static long long mdk_byteblock_cmp_bytes(long long a, long long b);
noreturn static void mdk_byteblock_append_unsupported(void);

/* mdk_append's fail-closed arm: a left operand that is neither String, byte block,
 * Nil nor Cons must not be walked as a Cons chain.  Both read the reserved ADT tags
 * MDK_TAG_CONS/MDK_TAG_NIL, so they are defined down beside those. */
static int mdk_is_list_word(long long w);
noreturn static void mdk_append_unsupported(void);

/* Count UTF-8 codepoints in the first `n` bytes of `p`: every byte that is not a
 * 0b10xxxxxx continuation byte starts a new codepoint.  Exact only on
 * well-formed UTF-8, which every String cell holds: bytes from outside the
 * program reach a cell only through mdk_str_lossy or a validating producer. */
static long long mdk_utf8_cp_count(const char *p, long long n) {
  long long c = 0;
  for (long long i = 0; i < n; i++)
    if (((unsigned char)p[i] & 0xC0) != 0x80) c++;
  return c;
}

/* The byte length (1..4) of the well-formed UTF-8 sequence starting at p[i],
 * or the negated length of its maximal ill-formed subpart: the bytes accepted
 * before the sequence failed, or 1 when it failed on its lead.  `C0`/`C1` and
 * `F5` upwards are not leads; an `E0`/`F0` lead bounds its second byte below
 * (overlong), `ED` above (surrogate) and `F4` above (past U+10FFFF).  The same
 * rule, subpart for subpart, as `utf8StepAt` in stdlib/bytes.mdk and
 * `$mdk_utf8_step` in compiler/backend/wasm_preamble.mdk. */
static int mdk_utf8_step(const unsigned char *p, size_t i, size_t n) {
  unsigned char b0 = p[i];
  if (b0 <= 0x7F) return 1;
  if (b0 >= 0xC2 && b0 <= 0xDF)
    return (i + 1 < n && (p[i + 1] & 0xC0) == 0x80) ? 2 : -1;
  if (b0 >= 0xE0 && b0 <= 0xF4) {
    int wide = b0 >= 0xF0;
    unsigned char lo = (b0 == 0xE0) ? 0xA0 : (b0 == 0xF0) ? 0x90 : 0x80;
    unsigned char hi = (b0 == 0xED) ? 0x9F : (b0 == 0xF4) ? 0x8F : 0xBF;
    if (i + 1 >= n || p[i + 1] < lo || p[i + 1] > hi) return -1;
    if (i + 2 >= n || (p[i + 2] & 0xC0) != 0x80) return -2;
    if (!wide) return 3;
    if (i + 3 >= n || (p[i + 3] & 0xC0) != 0x80) return -3;
    return 4;
  }
  return -1;
}

/* The codepoint count of p[0..n) when it is well-formed UTF-8, else -1.  Eight
 * ASCII bytes at a time until the first non-ASCII byte, so the common input
 * costs about one load and one test per word. */
static long long mdk_utf8_valid_count(const char *s, size_t n) {
  const unsigned char *p = (const unsigned char *)s;
  size_t i = 0;
  long long c = 0;
  while (i < n) {
    if (i + 8 <= n) {
      uint64_t w;
      memcpy(&w, p + i, 8);
      if ((w & 0x8080808080808080ULL) == 0) { i += 8; c += 8; continue; }
    }
    if (p[i] < 0x80) { i++; c++; continue; }
    int st = mdk_utf8_step(p, i, n);
    if (st < 0) return -1;
    i += (size_t)st;
    c++;
  }
  return c;
}

/* Validate one complete byte range as canonical UTF-8 encoding Unicode scalar
 * values: the trust-boundary check for bytes supplied by foreign C code. */
static int mdk_utf8_is_valid(const char *p, size_t n) {
  return mdk_utf8_valid_count(p, n) >= 0;
}

/* A String cell holding `byte_len` bytes whose codepoint count the caller
 * already knows.  The bytes must be well-formed UTF-8. */
static long long mdk_str_cell(const char *bytes, long long byte_len,
                              long long cp_count) {
  char *cell = (char *)mdk_alloc_atomic(24 + byte_len + 1);
  ((long long *)cell)[0] = MDK_STR_TAG;
  ((long long *)cell)[1] = byte_len;
  ((long long *)cell)[2] = cp_count;
  memcpy(cell + 24, bytes, (size_t)byte_len);
  cell[24 + byte_len] = '\0';
  return (long long)cell;
}

/* Build a boxed String cell from `byte_len` bytes of well-formed UTF-8 that the
 * runtime or the program itself produced (a literal, a rendered number, a
 * slice of an existing String); return the value word (cell pointer as i64,
 * low bit 0).  Bytes from outside the program go through mdk_str_lossy. */
long long mdk_str_lit(const char *bytes, long long byte_len) {
  return mdk_str_cell(bytes, byte_len, mdk_utf8_cp_count(bytes, byte_len));
}

/* A String cell from bytes of unknown provenance: verbatim when they are
 * well-formed UTF-8, otherwise with one U+FFFD (`EF BF BD`) substituted for
 * each maximal ill-formed subpart, exactly as `bytes.decodeUtf8Lossy` does.
 * Every producer that turns outside bytes into a String routes through here or
 * validates them itself. */
static long long mdk_str_lossy(const char *bytes, long long byte_len) {
  long long valid = mdk_utf8_valid_count(bytes, (size_t)byte_len);
  if (valid >= 0) return mdk_str_cell(bytes, byte_len, valid);
  const unsigned char *p = (const unsigned char *)bytes;
  size_t n = (size_t)byte_len, out = 0;
  for (size_t i = 0; i < n;) {
    int st = mdk_utf8_step(p, i, n);
    if (st > 0) { out += (size_t)st; i += (size_t)st; }
    else { out += 3; i += (size_t)-st; }
  }
  char *cell = (char *)mdk_alloc_atomic(24 + out + 1);
  char *dst = cell + 24;
  size_t j = 0;
  long long cps = 0;
  for (size_t i = 0; i < n; cps++) {
    int st = mdk_utf8_step(p, i, n);
    if (st > 0) {
      memcpy(dst + j, p + i, (size_t)st);
      j += (size_t)st; i += (size_t)st;
    } else {
      dst[j] = (char)0xEF; dst[j + 1] = (char)0xBF; dst[j + 2] = (char)0xBD;
      j += 3; i += (size_t)-st;
    }
  }
  ((long long *)cell)[0] = MDK_STR_TAG;
  ((long long *)cell)[1] = (long long)out;
  ((long long *)cell)[2] = cps;
  dst[out] = '\0';
  return (long long)cell;
}

/* String equality on two boxed String cells.  Returns a TAGGED Medaka Bool word
 * (3 = True, 1 = False, matching the emitter's `if b then "3" else "1"` rep), so
 * the literal-switch emitter can `icmp eq i64 r, 3` to branch.  Two strings are
 * equal iff equal byte_len and byte-identical payload (codepoint count is a cache
 * of byte content, so byte_len + memcmp is sufficient and exact). */
long long mdk_string_eq(long long a, long long b) {
  const char *ca = (const char *)a;
  const char *cb = (const char *)b;
  long long la = ((const long long *)ca)[1];
  long long lb = ((const long long *)cb)[1];
  if (la != lb) return 1;
  if (memcmp(ca + 24, cb + 24, (size_t)la) != 0) return 1;
  return 3;
}

/* Polymorphic `==`/`!=` for operands whose static LTy the emitter could not
 * recover (both default to LTInt — e.g. a `feq a b = a == b` over inferred-Float
 * params, or two String-typed params whose only use is `n == name`).
 * Discriminates at run time on the low bit / header tag, the EXACT peer of
 * mdk_value_cmp_raw's Ord discriminator (they MUST stay in lockstep):
 *   - boxed String cell (even pointer, header == MDK_STR_TAG) -> byte compare;
 *   - boxed Float cell  (even pointer, header == 2)           -> double compare
 *     (issue #181: without this arm two independently-boxed floats compared as
 *     value words — i.e. by POINTER — so `feq 0.5 0.5` was False in native);
 *   - otherwise (tagged immediates — Int/Bool/Char, nullary-ctor words) compares
 *     by value word.  Well-typed operands share a type, so testing the LEFT
 *     operand suffices (matching mdk_value_cmp_raw).  Returns a TAGGED Bool
 *     (3 = True, 1 = False), matching mdk_string_eq.  `da == db` gives IEEE
 *     semantics (NaN != NaN, -0.0 == 0.0), matching the inline `fcmp oeq` path. */
long long mdk_value_eq(long long a, long long b) {
  int a_str = ((a & 1) == 0) && ((const long long *)a)[0] == MDK_STR_TAG;
  int b_str = ((b & 1) == 0) && ((const long long *)b)[0] == MDK_STR_TAG;
  if (a_str && b_str) return mdk_string_eq(a, b);
  /* A byte block compares by CONTENT, matching the interpreter's
   * `valueEq (VByteBlock …)`; the word compare below would compare heap
   * addresses, so the engines would disagree on every pair of distinct cells
   * holding the same bytes. */
  if (mdk_is_byteblock(a) && mdk_is_byteblock(b))
    return mdk_byteblock_cmp_bytes(a, b) == 0 ? 3 : 1;
  /* A U64 compares by payload: two cells holding one value are distinct
   * addresses. */
  if (mdk_is_u64(a)) return mdk_u64_payload(a) == mdk_u64_payload(b) ? 3 : 1;
  if (mdk_is_i64(a)) return mdk_i64_payload(a) == mdk_i64_payload(b) ? 3 : 1;
  int a_flt = ((a & 1) == 0) && ((const long long *)a)[0] == 2;
  if (a_flt) {
    double da = ((const double *)a)[1], db = ((const double *)b)[1];
    return da == db ? 3 : 1;
  }
  return a == b ? 3 : 1;
}

/* Print a String RAW (no quoting).  Matches Eval.pp_value (VString s) = s, then
 * the oracle's trailing newline (eval_probe / compiler ppValue). */
void mdk_print_str(long long w) {
  const char *cell = (const char *)w;
  long long byte_len = ((const long long *)cell)[1];
  fwrite(cell + 24, 1, (size_t)byte_len, stdout);
  putchar('\n');
}

/* intToString : Int -> String  (LEAF, RUNTIME-DESIGN.md §5).  The argument is a
 * TAGGED immediate int word; untag (arithmetic shift), render decimal to match
 * OCaml string_of_int, and box the result through mdk_str_lit. */
long long mdk_int_to_string(long long tagged) {
  long long n = tagged >> 1;
  char buf[32];
  /* Hand-rolled decimal, byte-identical to "%lld": snprintf's machinery was
   * the largest single cost under every key build (lenKey, "\{n}"). The
   * magnitude is taken in unsigned space so LLONG_MIN is exact. */
  unsigned long long u = n < 0 ? 0ULL - (unsigned long long)n : (unsigned long long)n;
  char *p = buf + sizeof buf;
  do {
    *--p = (char)('0' + u % 10);
    u /= 10;
  } while (u != 0);
  if (n < 0) *--p = '-';
  return mdk_str_lit(p, (long long)(buf + sizeof buf - p));
}

long long mdk_float_to_string(double d) {
  char buf[96];
  mdk_float_lexeme(d, buf);   /* shared canonical lexeme (see mdk_float_lexeme) */
  return mdk_str_lit(buf, (long long)strlen(buf));
}

/* ---------------------------------------------------------------------------
 * BUILD-BINARY STDOUT-LOSS FIX (companion to the `medaka run` "drops stdout on
 * panic" fix below, but for a COMPILED, non-interpreter `medaka build` binary).
 *
 * A compiled binary's println/print write straight through LIBC's BUFFERED
 * stdout (mdk_fwrite_str -> fwrite(..., stdout)). Every EXIT()-based abort path
 * (mdk_panic, mdk_div_zero, mdk_oob, ...) already gets that buffer out for free,
 * since libc's exit() runs stdio's atexit flush. But the SIGSEGV/SIGBUS fault
 * handler below must call _exit(), never exit() (async-signal-safety: fflush/
 * fwrite are not on the POSIX async-signal-safe list, and calling them from a
 * signal handler risks deadlocking on stdio's lock if the crashing thread
 * already held it mid-fwrite) — and _exit() skips that flush entirely. So a
 * compiled binary that prints, then recurses into a genuine stack overflow,
 * lost every byte still sitting in libc's stdout buffer (confirmed empirically:
 * exit 134, empty stdout).
 *
 * Fix mirrors mdk_flush_run_stdout_on_abort's approach (below) exactly, adapted
 * for a native buffer instead of a GC-owned Medaka string cell: every stdout
 * write ALSO copies its bytes into a plain malloc'd, doubling-growth C buffer
 * (mdk_build_stdout_track — allocation/copy happens only in NORMAL execution,
 * NEVER inside the signal handler) and updates a pointer+length pair with plain
 * word stores. At abort time mdk_flush_build_stdout_on_fatal_signal reads that
 * pointer+length and write(2)s it — no allocation, no stdio, no locks, the same
 * discipline as mdk_flush_run_stdout_on_abort. It is called ONLY from the two
 * _exit() paths below (mdk_fault_handler's stack-overflow branch and
 * mdk_chain_previous's no-previous-handler branch) — NEVER from the exit()-based
 * abort paths, which already work correctly for a compiled binary via libc's own
 * flush; calling it there too would DOUBLE-print (once via libc's real flush,
 * once via this raw write(2)). The buffer is plain malloc/realloc, NOT
 * GC_malloc/mdk_alloc — it holds no pointers, needs no scanning, and must
 * survive independent of the GC heap.
 *
 * The buffer holds only the bytes written since stdout was last flushed, so it
 * stays bounded in a program that runs indefinitely. mdk_flushstdout empties
 * it after its fflush, since those bytes have left libc and replaying them
 * would print them twice. A program that never flushes is flushed here once
 * the buffer passes MDK_BUILD_STDOUT_TRACK_MAX, which bounds its memory too;
 * that program's replay can still repeat up to that many bytes libc wrote on
 * its own when its buffer filled.
 * ------------------------------------------------------------------------- */
#define MDK_BUILD_STDOUT_TRACK_MAX (1LL << 20)
static char *mdk_build_stdout_buf = NULL;
static long long mdk_build_stdout_len = 0;
static long long mdk_build_stdout_cap = 0;

/* Everything written so far has been handed to write(2) by fflush, so none of
   it is left for the fatal-signal path to replay. */
static void mdk_build_stdout_flushed(void) { mdk_build_stdout_len = 0; }

/* Set once by `medaka run`'s driver (mdk_enable_run_stdout_flush, below).  In
   that mode the only stdout bytes this process writes during the program are
   the ones eval.mdk flushes at once (pByteBlockWriteStdoutIO), and the run
   stash is the one record of what is still unwritten; replaying this tracker
   on a fatal signal would print those flushed bytes a second time. */
static volatile int mdk_run_stdout_flush_enabled = 0;

static void mdk_build_stdout_track(const char *bytes, long long n) {
  if (n <= 0 || mdk_run_stdout_flush_enabled) return;
  if (mdk_build_stdout_len > 0
      && mdk_build_stdout_len + n > MDK_BUILD_STDOUT_TRACK_MAX) {
    fflush(stdout);
    mdk_build_stdout_flushed();
  }
  if (mdk_build_stdout_len + n > mdk_build_stdout_cap) {
    long long newcap = mdk_build_stdout_cap == 0 ? 4096 : mdk_build_stdout_cap;
    while (newcap < mdk_build_stdout_len + n) newcap *= 2;
    char *nb = (char *)realloc(mdk_build_stdout_buf, (size_t)newcap);
    if (!nb) return; /* best-effort safety net: never sacrifice the real print for it */
    mdk_build_stdout_buf = nb;
    mdk_build_stdout_cap = newcap;
  }
  memcpy(mdk_build_stdout_buf + mdk_build_stdout_len, bytes, (size_t)n);
  mdk_build_stdout_len += n;
}

/* Async-signal-safe: word reads + write(2) only, no allocation, no stdio, no
   locks. Mirrors mdk_flush_run_stdout_on_abort but for the native build-stdout
   buffer above; see the block comment there for why the two must stay separate
   flush entry points despite doing the same thing. */
static void mdk_flush_build_stdout_on_fatal_signal(void) {
  if (mdk_run_stdout_flush_enabled) return;
  const char *bytes = mdk_build_stdout_buf;
  long long len = mdk_build_stdout_len;
  while (len > 0) {
    ssize_t n = write(1, bytes, (size_t)len);
    if (n <= 0) break;
    bytes += n;
    len -= n;
  }
}

/* IO-output externs (native extern catalog slice 3).
   mdk_fwrite_str reads the string cell (bytes at offset 24, byte_len at offset 8)
   and writes to the given FILE; appends '\n' iff nl != 0. Tracks stdout writes
   (not stderr) into the fatal-signal safety-net buffer above. */
static void mdk_fwrite_str(long long w, FILE *out, int nl) {
  const char *cell = (const char *)w;
  long long byte_len = ((const long long *)cell)[1];
  if (out == stdout) mdk_build_stdout_track(cell + 24, byte_len);
  fwrite(cell + 24, 1, (size_t)byte_len, out);
  if (nl) {
    if (out == stdout) mdk_build_stdout_track("\n", 1);
    fputc('\n', out);
  }
}

/* mdk_byteblock_write_stdout writes a ByteBlock cell's bytes ([i64 tag | i64
   count | count bytes], count at offset 8, bytes at offset 16 -- no
   string-specific fields) straight to stdout, byte-for-byte, no NUL or UTF-8
   assumption. Tracks the write into the fatal-signal safety-net buffer above,
   same as mdk_fwrite_str, so a crash right after this call still flushes
   these bytes via the existing stack-overflow/signal path. */
void mdk_byteblock_write_stdout(long long bb) {
  const char *cell = (const char *)bb;
  long long n = ((const long long *)cell)[1];
  mdk_build_stdout_track(cell + 16, n);
  fwrite(cell + 16, 1, (size_t)n, stdout);
}

void mdk_putstr(long long w)    { mdk_fwrite_str(w, stdout, 0); }
void mdk_putstrln(long long w)  { mdk_fwrite_str(w, stdout, 1); }
void mdk_eputstr(long long w)   { mdk_fwrite_str(w, stderr, 0); }
void mdk_eputstrln(long long w) { mdk_fwrite_str(w, stderr, 1); }
void mdk_flushstdout(long long w) {
  (void)w;
  fflush(stdout);
  mdk_build_stdout_flushed();
}
void mdk_print_unit(void)       { printf("()\n"); }

/* ---------------------------------------------------------------------------
 * "run drops stdout on panic" fix.  `medaka run`'s tree-walking interpreter
 * buffers a program's stdout in an in-language Ref<String> (eval.mdk's
 * outputRef) and only writes it to real stdout via ONE final `putStr` call
 * after `main` returns NORMALLY (medaka_cli.mdk's `runProgramOutput`).
 * Medaka panics are NOT catchable (no exception handling, no unwind), so a
 * panicking program's buffered stdout used to be silently discarded — the
 * printed trace before the crash never reached the terminal, which made the
 * standard "does this ill-typed program actually EXECUTE" probe (`println`
 * a sentinel, then check whether it appears) blind: both `run`'s stdout AND
 * its exit code look identical whether the program ran or not.
 *
 * mdk_stash_run_stdout lets eval.mdk register the buffer's raw bytes (a
 * pointer + length into an already-allocated, GC-owned, IMMUTABLE string
 * cell -- storing the pointer performs no allocation and no observable
 * effect) after every print.  mdk_enable_run_stdout_flush is called exactly
 * once, only by the real `medaka run` CLI driver (evalModulesOutputRun /
 * evalModulesOutputAsync) -- never by the pure differential-oracle eval
 * probes, which share this exact source but never call it, so their
 * captured output (many goldens pin an EMPTY capture for a deliberately
 * panicking fixture) is unaffected.  Every abort path below -- mdk_panic,
 * mdk_div_zero, mdk_mod_zero, mdk_nonexhaustive_match, mdk_let_refute,
 * mdk_oob, and the SIGSEGV/SIGBUS fault handler for a genuine stack overflow
 * or fatal signal -- flushes the stash via write(2) before printing its own
 * diagnostic and exiting.  write(2) is async-signal-safe (unlike fflush/
 * fwrite), so the SAME flush function is safe to call from the fault
 * handler too, matching its existing "no allocation, no stdio" discipline.
 *
 * A compiled (non-interpreter) `medaka build` binary never calls
 * mdk_stash_run_stdout or mdk_enable_run_stdout_flush at all (its own
 * mdk_putstr/mdk_putstrln write straight to the real stdio `stdout` stream,
 * which `exit()` -- used by every abort path except the signal handler --
 * already flushes automatically), so the flag stays 0 and every check below
 * is a no-op for it.
 */
static const char *volatile mdk_run_stdout_bytes = NULL;
static volatile long long mdk_run_stdout_len = 0;

void mdk_enable_run_stdout_flush(long long w) {
  (void)w;
  mdk_run_stdout_flush_enabled = 1;
}

void mdk_stash_run_stdout(long long w) {
  const char *cell = (const char *)w;
  long long byte_len = ((const long long *)cell)[1];
  mdk_run_stdout_bytes = cell + 24;
  mdk_run_stdout_len = byte_len;
}

/* Async-signal-safe: only word-sized reads and write(2), no allocation, no
   stdio.  Clears the stash first so a re-entrant abort during the flush
   itself (or a later abort path, e.g. mdk_exit after this already ran)
   can't double-print. */
static void mdk_flush_run_stdout_on_abort(void) {
  if (!mdk_run_stdout_flush_enabled) return;
  const char *bytes = mdk_run_stdout_bytes;
  long long len = mdk_run_stdout_len;
  mdk_run_stdout_bytes = NULL;
  mdk_run_stdout_len = 0;
  while (len > 0) {
    ssize_t n = write(1, bytes, (size_t)len);
    if (n <= 0) break;
    bytes += n;
    len -= n;
  }
}

/* `panic` is BOTH the abort primitive the interpreter's `runtimePanic` uses to
   print an already-formatted, coded+located runtime diagnostic AND the lowering
   of a user's `panic "msg"` in a natively-compiled program.  The two want
   different framing: runtimePanic's string is complete (`f:L:C: runtime error
   [E-CODE]: msg`, or the `--json` envelope) and must print verbatim, whereas a
   raw user message needs the `runtime error [E-PANIC]:` banner so native matches
   the interpreter (loc still blocked on Core-IR-loc).  The interpreter marks its
   pre-formatted strings with a leading 0x01 sentinel byte (eval.mdk's
   runtimePanic); mdk_panic strips that and prints verbatim, else it adds the
   E-PANIC banner.  A user panic message never begins with 0x01. */
noreturn void mdk_panic(long long w) {
  mdk_flush_run_stdout_on_abort();
  const char *cell = (const char *)w;
  long long byte_len = ((const long long *)cell)[1];
  const char *bytes = cell + 24;
  if (byte_len > 0 && bytes[0] == '\x01') {
    fwrite(bytes + 1, 1, (size_t)(byte_len - 1), stderr);
  } else {
    fputs("runtime error [E-PANIC]: ", stderr);
    fwrite(bytes, 1, (size_t)byte_len, stderr);
  }
  fputc('\n', stderr);
  exit(1);
}

/* Integer divide/modulo by zero traps (LLVM emitter guards the divisor before
   the hardware sdiv/srem, whose zero-divisor behaviour is UB → silent garbage +
   exit 0).  Message matches the interpreter's runtimePanic MINUS the source
   location (Core IR carries no loc); nonzero exit. */
noreturn void mdk_div_zero(void) {
  mdk_flush_run_stdout_on_abort();
  fputs("runtime error [E-DIV-ZERO]: division by zero\n", stderr);
  exit(1);
}
noreturn void mdk_mod_zero(void) {
  mdk_flush_run_stdout_on_abort();
  fputs("runtime error [E-MOD-ZERO]: modulo by zero\n", stderr);
  exit(1);
}

/* Int overflow trap.  `Int` arithmetic whose exact result falls outside
   -2^62 .. 2^62 - 1 stops the program; the U types are the wrapping opt-out.
   The emitter checks `+`, `-`, `*`, negation and `/` (only intMinBound / -1
   overflows) with the llvm.s*.with.overflow intrinsics and calls this on the
   cold path with the untagged operands; `op` is 0 `+`, 1 `-`, 2 `*`, 3 `/`,
   4 negation (b unused).  The message matches the interpreter's runtimePanic
   minus the source location: a negative operand is parenthesized. */
static void mdk_put_operand(long long v) {
  if (v < 0) fprintf(stderr, "(%lld)", v);
  else fprintf(stderr, "%lld", v);
}
noreturn void mdk_int_overflow(long long op, long long a, long long b) {
  static const char ops[] = "+-*/";
  mdk_flush_run_stdout_on_abort();
  fputs("runtime error [E-INT-OVERFLOW]: ", stderr);
  if (op == 4) {
    fputc('-', stderr);
    mdk_put_operand(a);
  } else {
    mdk_put_operand(a);
    fprintf(stderr, " %c ", ops[op & 3]);
    mdk_put_operand(b);
  }
  fputs(" overflows Int\n", stderr);
  exit(1);
}

/* Non-exhaustive match trap.  A compiled match whose decision tree matches no
   arm previously terminated the block with a bare `unreachable` (LLVM `ud2` →
   SIGTRAP, a silent signal death with no output).  The emitter now calls this
   before the `unreachable`, matching the interpreter's runtimePanic MINUS the
   source location (Core IR carries no loc — a located native trap is a
   follow-on); nonzero exit. */
noreturn void mdk_nonexhaustive_match(void) {
  mdk_flush_run_stdout_on_abort();
  fputs("runtime error [E-NONEXHAUSTIVE-MATCH]: non-exhaustive match\n", stderr);
  exit(1);
}
/* Dict-key-mismatch dispatcher trap (#1958).  A `@mdk_disp_*`/arg-tag dispatch
   chain's fallthrough is reached when the caller's dict/discriminant cell
   carries a key that matches NONE of the emitted arms.  Every fallthrough site
   used to terminate with a bare `unreachable` on the header comment's claim
   "the typechecker proves the dict names a real impl" — that claim was already
   caught false once for a sibling chain (llvm_emit.mdk :5287, #948: a
   method-less cross-module impl produced a dict with no matching arm and the
   bare `unreachable` there was a SIGSEGV on a check-green, eval-correct
   program).  UB at `-O0` (`ud2` -> SIGTRAP) is an optimizer's coin-flip at
   `-O1`/`-O2`; this makes the failure loud and identical across opt levels
   instead.  Matches the interpreter's dispatch-miss shape MINUS the source
   location (Core IR carries no loc); nonzero exit. */
noreturn void mdk_dispatch_no_impl(void) {
  mdk_flush_run_stdout_on_abort();
  fputs("runtime error [E-DISPATCH-NO-IMPL]: dispatch found no implementation matching the dict key\n", stderr);
  exit(1);
}
/* Arg-tag dispatch reached an arm whose runtime constructor tag is shared by two
   or more DECLARED impls of the interface (#2445).  The receiver's cell tag is the
   head tycon only -- it cannot tell `Pair Int _` from `Pair String _` -- so the
   chain has two arms testing the identical constant and the first one would win
   every receiver silently, at exit 0 (measured `1|1` where the semantics and
   `medaka run` both say `1|2`).

   The emitter used to refuse the whole `medaka build` at COMPILE time on the same
   declaration facts.  That refusal could not be scoped: a program that declares the
   colliding impls but never CONSTRUCTS a receiver at that head is perfectly
   decidable, and the emitter's static view cannot tell it from a program that does
   without a whole-program receiver-reachability analysis.  So the loudness is RETIMED
   to run time here, which scopes it by ACTUAL receiver exactly the way the
   interpreter's `checkArgTagDecidable` guard already is -- only the colliding arms
   carry this trap, everything else in the chain emits its normal call.

   Echoes the interpreter's `E-AMBIGUOUS-DISPATCH` wording MINUS the source location
   and the receiver's type name (Core IR carries no loc, and this trap takes no
   arguments -- same convention as its siblings above); nonzero exit. */
noreturn void mdk_dispatch_ambiguous(void) {
  mdk_flush_run_stdout_on_abort();
  fputs("runtime error [E-AMBIGUOUS-DISPATCH]: arg-tag dispatch on this receiver is "
        "undecidable: more than one impl is declared at that type head and the runtime "
        "tag cannot choose between them\n",
        stderr);
  exit(1);
}
/* A refutable block-`let` (`let (Some y) = e` with no `else`) whose scrutinee did
   not match the pattern.  The interpreter's blockLet runtimePanics
   "E-LET-REFUTE"; the emitter previously destructured with NO tag check → an OOB
   field load on a mismatching cell → SIGSEGV.  The emitter now tag-checks the
   head ctor and calls this noreturn trap on a miss, matching run's message MINUS
   the source location (Core IR carries no loc); nonzero exit. */
noreturn void mdk_let_refute(void) {
  mdk_flush_run_stdout_on_abort();
  fputs("runtime error [E-LET-REFUTE]: let pattern match failed\n", stderr);
  exit(1);
}

/* LOCATED TRAPS.  Each abort above has an `_at` twin taking one more argument,
   the trap's source site packed as (file + 1) << 44 | line << 20 | col (16, 24
   and 20 bits; col 0-based), which prints `file:line:col: ` ahead of the same
   line, as `medaka run` does.  `file` indexes the NULL-terminated path table a
   program that has located traps defines strongly as `mdk_site_files`; this
   weak null stands in for every program that defines none (the cold seed
   bootstrap among them), the same weak-default scheme as the build stamps
   below.  A site of 0, a file number past the table, or no table prints the
   unlocated line.  The plain entries keep their signatures: the seed calls
   them. */
__attribute__((weak)) const char *const *const mdk_site_files = 0;

static void mdk_put_site(unsigned long long site) {
  unsigned long long file = site >> 44;
  const char *const *table = mdk_site_files;
  if (file == 0 || table == 0) return;
  for (unsigned long long i = 0; i + 1 < file; i++)
    if (table[i] == 0) return;
  if (table[file - 1] == 0) return;
  fprintf(stderr, "%s:%llu:%llu: ", table[file - 1], (site >> 20) & 0xFFFFFF,
          site & 0xFFFFF);
}

noreturn void mdk_div_zero_at(unsigned long long site) {
  mdk_flush_run_stdout_on_abort();
  mdk_put_site(site);
  fputs("runtime error [E-DIV-ZERO]: division by zero\n", stderr);
  exit(1);
}
noreturn void mdk_mod_zero_at(unsigned long long site) {
  mdk_flush_run_stdout_on_abort();
  mdk_put_site(site);
  fputs("runtime error [E-MOD-ZERO]: modulo by zero\n", stderr);
  exit(1);
}
noreturn void mdk_int_overflow_at(long long op, long long a, long long b,
                                  unsigned long long site) {
  static const char ops[] = "+-*/";
  mdk_flush_run_stdout_on_abort();
  mdk_put_site(site);
  fputs("runtime error [E-INT-OVERFLOW]: ", stderr);
  if (op == 4) {
    fputc('-', stderr);
    mdk_put_operand(a);
  } else {
    mdk_put_operand(a);
    fprintf(stderr, " %c ", ops[op & 3]);
    mdk_put_operand(b);
  }
  fputs(" overflows Int\n", stderr);
  exit(1);
}
noreturn void mdk_nonexhaustive_match_at(unsigned long long site) {
  mdk_flush_run_stdout_on_abort();
  mdk_put_site(site);
  fputs("runtime error [E-NONEXHAUSTIVE-MATCH]: non-exhaustive match\n", stderr);
  exit(1);
}
noreturn void mdk_let_refute_at(unsigned long long site) {
  mdk_flush_run_stdout_on_abort();
  mdk_put_site(site);
  fputs("runtime error [E-LET-REFUTE]: let pattern match failed\n", stderr);
  exit(1);
}
noreturn void mdk_oob_at_at(long long idx, unsigned long long site) {
  mdk_flush_run_stdout_on_abort();
  mdk_put_site(site);
  fprintf(stderr, "runtime error [E-INDEX-OOB]: index %lld out of bounds\n", idx);
  exit(1);
}
/* A pre-formatted message (the 0x01 sentinel, see mdk_panic) already carries
   its own location, so it prints verbatim. */
noreturn void mdk_panic_at(long long w, unsigned long long site) {
  const char *cell = (const char *)w;
  long long byte_len = ((const long long *)cell)[1];
  const char *bytes = cell + 24;
  if (byte_len > 0 && bytes[0] == '\x01') mdk_panic(w);
  mdk_flush_run_stdout_on_abort();
  mdk_put_site(site);
  fputs("runtime error [E-PANIC]: ", stderr);
  fwrite(bytes, 1, (size_t)byte_len, stderr);
  fputc('\n', stderr);
  exit(1);
}
/* User `exit n`. Unlike the other abort paths above this carries no diagnostic
   -- it is a silent, coded-free process termination -- but it still needs the
   SAME mdk_flush_run_stdout_on_abort() call they all make: under `medaka run`
   stdout is buffered in the interpreter's outputRef and normally only printed
   by the CLI driver AFTER `main` returns, so a mid-`main` `exit` call would
   otherwise silently drop everything printed before it (the same class of bug
   as "run drops stdout on panic", just for a clean exit instead of a crash).
   For a compiled `medaka build` binary the call is a no-op (mdk_run_stdout_
   flush_enabled stays 0 there — see the block comment above), and libc's own
   exit() already flushes its real buffered stdout normally, so this is safe on
   both engines without double-printing. */
noreturn void mdk_exit(long long tagged) {
  mdk_flush_run_stdout_on_abort();
  exit((int)(tagged >> 1));
}

/* Concatenate a built-in List String (native extern catalog slice 5).
   Nil = odd immediate (low bit 1, stop); Cons = even pointer to [tag | head@8 | tail@16].
   head is a String cell (byte_len@8, bytes@24). Two passes: sum byte_lens, then blit;
   mdk_str_lit recomputes cp_count correctly. Empty list (Nil) -> "" string cell. */
long long mdk_string_concat(long long list) {
  long long total = 0;
  for (long long w = list; (w & 1) == 0; w = ((const long long *)w)[2])
    total += ((const long long *)(((const long long *)w)[1]))[1];
  char *buf = (char *)mdk_alloc_atomic(total + 1);
  long long off = 0;
  for (long long w = list; (w & 1) == 0; w = ((const long long *)w)[2]) {
    long long s = ((const long long *)w)[1];
    long long bl = ((const long long *)s)[1];
    memcpy(buf + off, (const char *)s + 24, (size_t)bl);
    off += bl;
  }
  return mdk_str_lit(buf, total);
}

/* Append two String cells (++ on String, E2a).
   String cell: [i64 tag | i64 byte_len | i64 cp_count | bytes...].
   Builds the result cell DIRECTLY - one allocation, two blits, no rescan.

   This used to allocate a scratch buffer, blit both spans into it, and hand it to
   mdk_str_lit, which allocated a SECOND cell, memcpy'd the whole thing again, and
   re-counted the codepoints with mdk_utf8_cp_count.  That is 2 allocations, 2x the
   bytes, 2 full copies and one full UTF-8 scan per `++`.  On a hello-world
   `medaka check` mdk_string_append is called 902,342 times and was the #2 symbol in
   the whole process at 9.62% of instructions (callgrind, S-3-check-floor), so the
   redundancy was worth removing on attribution alone.

   PARITY, not an approximation, on both fields the old path recomputed:
     * byte_len is al + bl by construction, exactly as before.
     * cp_count is ADDITIVE.  mdk_utf8_cp_count counts bytes whose top two bits are
       not 0b10 - a per-BYTE predicate with no cross-byte state - so its count over
       the concatenation of two byte spans is always the sum of its counts over each
       span.  Each operand cell already stores a cp_count at word 2, so the sum is
       exactly what a rescan would have returned - PROVIDED every producer of a
       String cell stores a count that agrees with mdk_utf8_cp_count's definition.
       That count is the true codepoint count, and the one mdk_string_to_chars
       and mdk_utf8_cursor_offset walk by, only because every cell holds well-formed
       UTF-8: two well-formed spans concatenate to a well-formed span, and every
       producer of a cell keeps the rule, so the invariant holds by induction:
         - mdk_str_lit, which calls mdk_utf8_cp_count outright, over bytes the
           program or the runtime itself produced;
         - mdk_str_cell / mdk_str_lossy, which validate outside bytes (replacing
           each ill-formed subpart with U+FFFD) and store the counted codepoints;
         - this function, whose result is a sum of two conforming counts;
         - the EMITTER, which mints a String-literal cell as a module-scope constant
           (`@.strc.N`, llvm_emit.mdk `emitLit (LString s)`) with the count computed
           at compile time as `arrayLength (stringToChars s)` - i.e. one per decoded
           codepoint, which for the byte encoding of that same literal is exactly the
           number of non-continuation bytes mdk_utf8_cp_count would count.
       A producer that stores anything else (a UTF-16 unit count, a grapheme count,
       a lazily-filled 0), or that copies outside bytes in without validating them,
       silently breaks this function, without touching it.
   Atomic allocation is retained (the cell is a header plus raw bytes, never a
   pointer), and every byte of it is written here, so GC_malloc_atomic not zeroing is
   irrelevant - matching mdk_str_lit's own contract. */
long long mdk_string_append(long long a, long long b) {
  long long al = ((const long long *)a)[1];
  long long bl = ((const long long *)b)[1];
  long long total = al + bl;
  char *cell = (char *)mdk_alloc_atomic(24 + total + 1);
  ((long long *)cell)[0] = MDK_STR_TAG;
  ((long long *)cell)[1] = total;
  ((long long *)cell)[2] = ((const long long *)a)[2] + ((const long long *)b)[2];
  memcpy(cell + 24,      (const char *)a + 24, (size_t)al);
  memcpy(cell + 24 + al, (const char *)b + 24, (size_t)bl);
  cell[24 + total] = '\0';
  return (long long)cell;
}

/* Append two persistent lists (++ on List, E2a).
   Walks xs collecting heads into a stack array, then conses them onto ys
   back-to-front so the result is xs ++ ys.  ys is shared (not copied). */
long long mdk_cons(long long head, long long tail);  /* defined below (slice 10) */
long long mdk_list_append(long long xs, long long ys) {
  long long n = 0;
  for (long long w = xs; (w & 1) == 0; w = ((const long long *)w)[2]) n++;
  if (n == 0) return ys;
  long long *heads = (long long *)mdk_alloc(8 * n);
  long long i = 0;
  for (long long w = xs; (w & 1) == 0; w = ((const long long *)w)[2])
    heads[i++] = ((const long long *)w)[1];
  long long acc = ys;
  for (long long j = n - 1; j >= 0; j--) acc = mdk_cons(heads[j], acc);
  return acc;
}

/* List index `xs.[i]` (Medaka EIndex on a List receiver).  A List is a chain of
 * Cons cells ([tag@0 | head@8 | tail@16], Nil = odd immediate), NOT an array, so
 * we walk the chain.  Mirrors the interpreter's listNthAt (eval.mdk): `i <= 0`
 * returns the current head (negative index returns the head, NOT a panic);
 * running off the end (hitting Nil) panics via @mdk_oob.  `idx` is a tagged Int
 * (>> 1 to untag).  Returns the stored head word verbatim. */
long long mdk_list_index(long long xs, long long idx) {
  long long i = idx >> 1;
  for (long long w = xs; (w & 1) == 0; w = ((const long long *)w)[2]) {
    if (i <= 0) return ((const long long *)w)[1];
    i--;
  }
  mdk_oob();
  return 0; /* unreachable */
}

/* List slice `xs.[lo..hi]` (Medaka ESlice on a List receiver).  Collects the
 * elements at indices [lo, hi) into a NEW list.  Mirrors the interpreter's
 * listSliceV/listSliceGo (eval.mdk): CLAMPS (no OOB panic) — walks with a running
 * index, keeps heads where lo <= i < hi, stops at hi or end-of-list.  `lo`/`hi`
 * are tagged Ints (>> 1 to untag); the emitter has already applied the inclusive
 * hi+1 adjustment.  Two passes (count then cons back-to-front) so the result is in
 * original order; the result is always Nil-terminated (mdk_nil). */
long long mdk_nil(void);
long long mdk_list_slice(long long xs, long long lo, long long hi) {
  long long l = lo >> 1, h = hi >> 1;
  long long n = 0, i = 0;
  for (long long w = xs; (w & 1) == 0; w = ((const long long *)w)[2], i++) {
    if (i >= h) break;
    if (i >= l) n++;
  }
  if (n == 0) return mdk_nil();
  long long *heads = (long long *)mdk_alloc(8 * n);
  long long k = 0;
  i = 0;
  for (long long w = xs; (w & 1) == 0; w = ((const long long *)w)[2], i++) {
    if (i >= h) break;
    if (i >= l) heads[k++] = ((const long long *)w)[1];
  }
  long long acc = mdk_nil();
  for (long long j = n - 1; j >= 0; j--) acc = mdk_cons(heads[j], acc);
  return acc;
}

/* Runtime header-dispatch fallback for `++` (Medaka concat) whose operand
 * static LTy the emitter cannot recover (census-B gap #3 residual: the
 * scanTriple/splitLines string-builders).  Every left operand this arm can
 * legitimately meet is a String or a List, distinguishable at runtime:
 *   Nil immediate                      -> list append
 *   even boxed, header==MDK_STR_TAG    -> String cell   -> string append
 *   even boxed, header==MDK_TAG_CONS   -> Cons cell     -> list append
 * The result VALUE is always correct; the caller's static result LTy only
 * drives downstream instruction/print selection.
 *
 * Anything else FAILS CLOSED.  This helper is untyped, so a typechecker gap that
 * leaves a `++` on a user `Semigroup` type unrouted delivers that type's cell
 * here; walking it as a Cons chain reads an arbitrary field as a tail pointer
 * (#3204: a SIGSEGV where the interpreter panicked).  A byte block is the one
 * such header with its own message, because `stdlib/bytes.mdk`'s `Bytes` is a
 * newtype over `ByteBlock` and its packed payload is the shape most likely to be
 * mistaken for cells; every other header takes the generic arm. */
long long mdk_append(long long a, long long b) {
  if ((a & 1) == 0 && ((const long long *)a)[0] == MDK_STR_TAG)
    return mdk_string_append(a, b);
  if (mdk_is_byteblock(a)) mdk_byteblock_append_unsupported();
  if (!mdk_is_list_word(a)) mdk_append_unsupported();
  return mdk_list_append(a, b);
}

/* Array cell: [i64 count | elem0@8 | ...]; total 8*(count+1) bytes.
   count is raw (untagged); Int args are tagged (>> 1 to untag).
   Native extern catalog slice 7 (array leaf). */
long long mdk_array_make(long long n_tagged, long long x) {
  long long n = n_tagged >> 1;
  long long *cell = (long long *)mdk_alloc(8 * (n + 1));
  cell[0] = n;
  for (long long i = 0; i < n; i++) cell[i + 1] = x;
  return (long long)cell;
}
long long mdk_array_copy(long long src) {
  const long long *s = (const long long *)src;
  long long n = s[0];
  long long *cell = (long long *)mdk_alloc(8 * (n + 1));
  memcpy(cell, s, (size_t)(8 * (n + 1)));
  return (long long)cell;
}
void mdk_array_blit(long long src, long long so_t, long long dst,
                    long long dof_t, long long len_t) {
  const long long *s = (const long long *)src;
  long long *d = (long long *)dst;
  memmove(d + 1 + (dof_t >> 1), s + 1 + (so_t >> 1),
          (size_t)(8 * (len_t >> 1)));
}
void mdk_array_fill(long long x, long long arr) {
  long long *a = (long long *)arr;
  long long n = a[0];
  for (long long i = 0; i < n; i++) a[i + 1] = x;
}
long long mdk_array_from_list(long long list) {
  long long n = 0;
  for (long long w = list; (w & 1) == 0; w = ((const long long *)w)[2]) n++;
  long long *cell = (long long *)mdk_alloc(8 * (n + 1));
  cell[0] = n;
  long long i = 0;
  for (long long w = list; (w & 1) == 0; w = ((const long long *)w)[2])
    cell[++i] = ((const long long *)w)[1];
  return (long long)cell;
}

/* ── byte-block leaf externs (the `ByteBlock` builtin) ──────────────────────
   Cell = [i64 MDK_BYTEBLOCK_TAG | i64 count | count bytes, word-padded]; see the
   BYTEBLOCK REPRESENTATION note beside MDK_STR_TAG.  These mirror the array leaf
   helpers above, one byte per element instead of one tagged word.  Int args are
   tagged (>> 1 to untag); Int results are tagged ((x << 1) | 1).  The Unsafe
   variants take no bounds check -- `internalExterns` (compiler/frontend/
   resolve.mdk) keeps them out of user programs. */
static unsigned char *mdk_byteblock_bytes(long long bb) {
  return (unsigned char *)bb + 16;
}
static long long mdk_byteblock_count(long long bb) {
  return ((const long long *)bb)[1];
}
static int mdk_is_byteblock(long long w) {
  return ((w & 1) == 0) && ((const long long *)w)[0] == MDK_BYTEBLOCK_TAG;
}
noreturn static void mdk_byteblock_append_unsupported(void) {
  mdk_flush_run_stdout_on_abort();
  fputs("runtime error [E-BYTEBLOCK-APPEND]: ++ is not defined on ByteBlock\n",
        stderr);
  exit(1);
}

/* Fresh zeroed cell of `n` bytes.  mdk_alloc_atomic leaves the block
   uninitialised, so the whole cell is memset before the header is stamped. */
static long long *mdk_byteblock_alloc(long long n) {
  long long bytes = 16 + ((n + 7) / 8) * 8;
  long long *cell = (long long *)mdk_alloc_atomic(bytes);
  memset(cell, 0, (size_t)bytes);
  cell[0] = MDK_BYTEBLOCK_TAG;
  cell[1] = n;
  return cell;
}

/* Lexicographic over the bytes, shorter prefix first -- the ordering half of
   mdk_value_eq / mdk_value_cmp_raw's byte-block arms. */
static long long mdk_byteblock_cmp_bytes(long long a, long long b) {
  long long na = mdk_byteblock_count(a), nb = mdk_byteblock_count(b);
  long long n = na < nb ? na : nb;
  int c = n > 0 ? memcmp(mdk_byteblock_bytes(a), mdk_byteblock_bytes(b),
                         (size_t)n)
                : 0;
  if (c != 0) return c < 0 ? -1 : 1;
  return na < nb ? -1 : na > nb ? 1 : 0;
}

long long mdk_byteblock_make(long long n_tagged) {
  return (long long)mdk_byteblock_alloc(n_tagged >> 1);
}
long long mdk_byteblock_length(long long bb) {
  return (mdk_byteblock_count(bb) << 1) | 1;
}
long long mdk_byteblock_get(long long i_tagged, long long bb) {
  return ((long long)mdk_byteblock_bytes(bb)[i_tagged >> 1] << 1) | 1;
}
void mdk_byteblock_set(long long i_tagged, long long v_tagged, long long bb) {
  mdk_byteblock_bytes(bb)[i_tagged >> 1] = (unsigned char)(v_tagged >> 1);
}
long long mdk_byteblock_copy(long long n_tagged, long long bb) {
  long long n = n_tagged >> 1;
  long long *cell = mdk_byteblock_alloc(n);
  if (n > 0) memcpy((unsigned char *)cell + 16, mdk_byteblock_bytes(bb),
                    (size_t)n);
  return (long long)cell;
}
/* byteBlockBlit src srcOff dst dstOff len.  memmove, not memcpy: src and dst
   may be the same cell with overlapping regions, and the interpreter's arm
   delegates to arrayBlit, which is memmove too. */
void mdk_byteblock_blit(long long src, long long so_t, long long dst,
                        long long dof_t, long long len_t) {
  long long len = len_t >> 1;
  if (len > 0)
    memmove(mdk_byteblock_bytes(dst) + (dof_t >> 1),
            mdk_byteblock_bytes(src) + (so_t >> 1), (size_t)len);
}
long long mdk_byteblock_from_int_array(long long arr) {
  const long long *a = (const long long *)arr;
  long long n = a[0];
  long long *cell = mdk_byteblock_alloc(n);
  unsigned char *p = (unsigned char *)cell + 16;
  for (long long i = 0; i < n; i++) p[i] = (unsigned char)(a[i + 1] >> 1);
  return (long long)cell;
}
long long mdk_byteblock_to_int_array(long long bb) {
  long long n = mdk_byteblock_count(bb);
  const unsigned char *p = mdk_byteblock_bytes(bb);
  long long *cell = (long long *)mdk_alloc(8 * (n + 1));
  cell[0] = n;
  for (long long i = 0; i < n; i++) cell[i + 1] = ((long long)p[i] << 1) | 1;
  return (long long)cell;
}
long long mdk_byteblock_from_string(long long s) {
  long long n = ((const long long *)s)[1];
  long long *cell = mdk_byteblock_alloc(n);
  if (n > 0) memcpy((unsigned char *)cell + 16, (const char *)s + 24,
                    (size_t)n);
  return (long long)cell;
}
/* byteBlockToString: the block's bytes as a fresh String cell, the same route
   as mdk_string_from_utf8_bytes: well-formed UTF-8 is copied verbatim and each
   ill-formed subpart becomes U+FFFD (mdk_str_lossy). */
long long mdk_byteblock_to_string(long long bb) {
  return mdk_str_lossy((const char *)mdk_byteblock_bytes(bb),
                       mdk_byteblock_count(bb));
}


/* ── FFI boundary marshalling (#2074, compiler/FFI-ABI.md §2) ───────────────
 * The two crossings the emitter cannot express as a couple of inline LLVM
 * instructions.  Everything else in §2 is inline codegen: immediates are an
 * `ashr`/`shl`, a Float is the emitter's existing box/unbox, and a String going
 * OUT is just the cell pointer plus 24.
 *
 * NOT reachable from any Medaka program that declares no `extern` of its own —
 * the emitter emits their `declare`s only when the FFI index is non-empty. */

/* §2.4, Medaka → C.  MANDATORY COPY.  The Medaka array cell is
 * `{i64 count, TAGGED elem…}` (mdk_array_make above), so a raw `int64_t*` view of
 * it would hand the C side `2*v+1` for every element and a bogus leading count.
 * Copy `count` UNTAGGED words into a fresh pointer-free buffer and hand that over.
 *
 * The buffer is GC-allocated (atomic: it holds no pointers), not malloc'd, so
 * nothing has to free it — Boehm reclaims it once the call returns and the
 * caller's frame stops referencing it.  Per §2.5 the C side must not retain it
 * past its own return. */
void *mdk_ffi_array_int_out(long long arr) {
  const long long *a = (const long long *)arr;
  long long n = a[0];
  long long *buf = (long long *)mdk_alloc_atomic(8 * (n > 0 ? n : 1));
  for (long long i = 0; i < n; i++) buf[i] = a[i + 1] >> 1;
  return (void *)buf;
}

/* §2.4, C → Medaka: the COPY-BACK (#2164).  The mirror of mdk_ffi_array_int_out
 * above, emitted unconditionally after the call for every `Array` parameter.
 *
 * WHY IT MUST EXIST.  §2.4 hands C a COPY, never the live cell, so without this
 * a C function that fills a caller-allocated array fills a throwaway buffer and
 * the Medaka array is silently unchanged at exit 0 (#2164).  A Medaka FFI
 * signature has no "in" vs "out" parameter distinction, so this runs for every
 * Array argument whether or not C wrote anything — copying back an unmodified
 * buffer restores the identical words, a no-op rather than a case to detect.
 *
 * `n` is read from the LIVE cell (`a[0]`), the same count the out-copy used, so
 * this can never write past the cell however the C side mangled its own view of
 * the buffer — C was given no length channel and cannot have grown it.  Each
 * word is re-tagged `(w << 1) | 1` on the way in, exactly inverting the
 * `>> 1` the out-copy applied.
 *
 * The buffer is still live here: the emitter keeps its pointer in an SSA
 * register across the `call`, which Boehm's conservative stack scan covers the
 * same way it covers any local referenced after a call. */
void mdk_ffi_array_int_in(long long arr, const void *buf) {
  long long *a = (long long *)arr;
  const long long *b = (const long long *)buf;
  long long n = a[0];
  /* A word outside Int's 63 bits would lose its top bit to the tag, a different
   * number at exit 0; the whole copy-back is checked before any element is
   * written, so a refused call leaves the array as it was.  The same rule as an
   * `Int` result (FFI-ABI.md section 2.1a). */
  for (long long i = 0; i < n; i++) {
    if (b[i] < -4611686018427387904LL || b[i] > 4611686018427387903LL) {
      static const char msg[] =
        "foreign call wrote an int64_t outside Int's range "
        "-4611686018427387904..4611686018427387903 into an Array Int argument "
        "(compiler/FFI-ABI.md section 2.4)";
      mdk_panic(mdk_str_lit(msg, (long long)(sizeof msg - 1)));
    }
  }
  for (long long i = 0; i < n; i++) a[i + 1] = (b[i] << 1) | 1;
}

/* §2.3, C → Medaka.  MANDATORY COPY — Medaka never adopts a C-allocated buffer
 * as a String cell, so this routes through mdk_str_lit (alloc + memcpy), exactly
 * as every String-returning builtin already does.  If the C side malloc'd `s`,
 * freeing it stays the C side's job; this copy is independent.
 *
 * Length comes from the NUL terminator: a C-ABI return carries one value, so
 * there is no second channel for a byte count.  A NULL return becomes "" rather
 * than a segfault — a C function signalling failure with NULL is common, and §4
 * says a foreign call cannot fail INTO Medaka. */
long long mdk_ffi_str_in(const char *s) {
  if (s == NULL) return mdk_str_lit("", 0);
  size_t n = strlen(s);
  if (!mdk_utf8_is_valid(s, n)) {
    static const char msg[] =
      "foreign call returned a String that is not valid UTF-8: a String must "
      "contain only canonical UTF-8 encodings of Unicode scalar values "
      "(compiler/FFI-ABI.md section 2.3)";
    mdk_panic(mdk_str_lit(msg, (long long)(sizeof msg - 1)));
  }
  return mdk_str_lit(s, (long long)n);
}

/* Char scalar externs (native extern catalog slice 8).
 * Char = immediate codepoint word: word = (codepoint << 1) | 1 (same tag as Int).
 * charCode is INTRINSIC (identity re-type) — no C helper needed.
 * mdk_print_char: auto-print a Char main value (UTF-8 bytes + newline).
 * mdk_char_to_str: charToStr — encode codepoint to a boxed String cell. */
static int mdk_utf8_encode(long long cp, char *out) {
  if (cp < 0x80) { out[0]=(char)cp; return 1; }
  if (cp < 0x800) {
    out[0]=(char)(0xC0|(cp>>6)); out[1]=(char)(0x80|(cp&0x3F)); return 2; }
  if (cp < 0x10000) {
    out[0]=(char)(0xE0|(cp>>12)); out[1]=(char)(0x80|((cp>>6)&0x3F));
    out[2]=(char)(0x80|(cp&0x3F)); return 3; }
  out[0]=(char)(0xF0|(cp>>18)); out[1]=(char)(0x80|((cp>>12)&0x3F));
  out[2]=(char)(0x80|((cp>>6)&0x3F)); out[3]=(char)(0x80|(cp&0x3F)); return 4;
}
void mdk_print_char(long long tagged) {
  char buf[4]; int n = mdk_utf8_encode(tagged >> 1, buf);
  fwrite(buf, 1, (size_t)n, stdout); putchar('\n');
}
long long mdk_char_to_str(long long tagged) {
  char buf[4]; int n = mdk_utf8_encode(tagged >> 1, buf);
  return mdk_str_lit(buf, n);
}

/* String↔Char + codepoint slicing (native extern catalog slice 9).
 * Char = immediate codepoint word (cp << 1) | 1 (same as Int).
 * String cell: [i64 header | i64 byte_len@8 | i64 cp_count@16 | bytes@24 | NUL]. */
/* One-entry cursor for non-ASCII slicing: the last (cell, codepoint index,
 * byte offset) resolved.  A loop that slices a string at nearby indices
 * (either direction) resumes the walk there instead of rescanning from byte 0.  The static slot
 * lives in .bss, which the collector scans, so the cell it names cannot be
 * freed and its address reused while cached.  Cells are immutable, and the
 * program runs on a single mutator thread. */
static const char *mdk_cur_cell = 0;
static long long mdk_cur_cpi = 0, mdk_cur_b = 0;
static long long mdk_utf8_cursor_offset(const char *cell, const char *p,
                                        long long byte_len, long long cpi) {
  long long b = 0, c = 0;
  if (mdk_cur_cell == cell) {
    if (mdk_cur_cpi <= cpi) { b = mdk_cur_b; c = mdk_cur_cpi; }
    else if (mdk_cur_cpi - cpi < cpi) {
      b = mdk_cur_b; c = mdk_cur_cpi;
      while (c > cpi) {
        b--;
        while (b > 0 && ((unsigned char)p[b] & 0xC0) == 0x80) b--;
        c--;
      }
    }
  }
  while (b < byte_len && c < cpi) {
    b++;
    while (b < byte_len && ((unsigned char)p[b] & 0xC0) == 0x80) b++;
    c++;
  }
  mdk_cur_cell = cell; mdk_cur_cpi = c; mdk_cur_b = b;
  return b;
}
/* Decode the codepoint at p[b], of a cell's `byte_len` bytes.  The cell is
 * well-formed UTF-8, so the width read from the lead byte is its sequence's;
 * the clamp to `byte_len` only keeps a cell that broke that invariant from
 * being read past its end. */
static long long mdk_utf8_decode(const char *p, long long b, long long byte_len,
                                 int *w) {
  unsigned char ch = (unsigned char)p[b];
  long long cp; int n;
  if (ch < 0x80)             { cp = ch;        n = 1; }
  else if ((ch >> 5) == 0x6) { cp = ch & 0x1F; n = 2; }
  else if ((ch >> 4) == 0xE) { cp = ch & 0x0F; n = 3; }
  else                       { cp = ch & 0x07; n = 4; }
  if (n > byte_len - b) n = (int)(byte_len - b);
  for (int k = 1; k < n; k++) cp = (cp << 6) | ((unsigned char)p[b+k] & 0x3F);
  *w = n; return cp;
}
/* The output array is sized from the cached cp_count, and the loop stops
 * there even if the bytes would decode to more, so it never writes past the
 * allocation. */
long long mdk_string_to_chars(long long s) {
  const char *cell = (const char *)s;
  long long byte_len = ((const long long *)cell)[1];
  long long cp_count = ((const long long *)cell)[2];
  const char *bytes = cell + 24;
  long long *arr = (long long *)mdk_alloc(8 * (cp_count + 1));
  arr[0] = cp_count;
  long long b = 0, i = 0;
  while (b < byte_len && i < cp_count) {
    int w; long long cp = mdk_utf8_decode(bytes, b, byte_len, &w);
    arr[++i] = (cp << 1) | 1; b += w;
  }
  return (long long)arr;
}
long long mdk_string_from_chars(long long arr) {
  const long long *a = (const long long *)arr;
  long long n = a[0], total = 0; char tmp[4];
  for (long long i = 0; i < n; i++) total += mdk_utf8_encode(a[i+1] >> 1, tmp);
  char *buf = (char *)mdk_alloc(total + 1);
  long long off = 0;
  for (long long i = 0; i < n; i++) off += mdk_utf8_encode(a[i+1] >> 1, buf + off);
  return mdk_str_lit(buf, total);
}
/* stringToUtf8Bytes : String -> Array Int.  Expose the String cell's raw UTF-8
 * backing as an Array of tagged Int bytes 0..255 (O(n) copy, NO codepoint
 * re-encode).  Array cell: [i64 count | elem0@8 | ...]; Int elems are tagged. */
long long mdk_string_to_utf8_bytes(long long s) {
  const char *cell = (const char *)s;
  long long byte_len = ((const long long *)cell)[1];
  const unsigned char *bytes = (const unsigned char *)(cell + 24);
  long long *arr = (long long *)mdk_alloc(8 * (byte_len + 1));
  arr[0] = byte_len;
  for (long long i = 0; i < byte_len; i++)
    arr[i + 1] = (((long long)bytes[i]) << 1) | 1;
  return (long long)arr;
}
/* stringFromUtf8Bytes : Array Int -> String.  The low 8 bits of each tagged Int
 * element, read as UTF-8: valid UTF-8 round-trips byte-for-byte, and each
 * ill-formed subpart becomes U+FFFD (mdk_str_lossy). */
long long mdk_string_from_utf8_bytes(long long arr) {
  const long long *a = (const long long *)arr;
  long long n = a[0];
  char *buf = (char *)mdk_alloc_atomic(n + 1);
  for (long long i = 0; i < n; i++) buf[i] = (char)((a[i + 1] >> 1) & 0xFF);
  return mdk_str_lossy(buf, n);
}
long long mdk_string_slice(long long lo_t, long long hi_t, long long s) {
  const char *cell = (const char *)s;
  long long byte_len = ((const long long *)cell)[1];
  long long cp_count = ((const long long *)cell)[2];
  const char *bytes = cell + 24;
  long long lo = lo_t >> 1, hi = hi_t >> 1;
  if (lo < 0) lo = 0; else if (lo > cp_count) lo = cp_count;
  if (hi < lo) hi = lo; else if (hi > cp_count) hi = cp_count;
  /* A cell whose codepoint count equals its byte length is all ASCII, so a
   * codepoint index is its byte offset. */
  long long blo, bhi;
  if (cp_count == byte_len) { blo = lo; bhi = hi; }
  else {
    blo = mdk_utf8_cursor_offset(cell, bytes, byte_len, lo);
    bhi = mdk_utf8_cursor_offset(cell, bytes, byte_len, hi);
  }
  return mdk_str_lit(bytes + blo, bhi - blo);
}

/* ── native extern catalog slice 14: ASCII char classification + case mapping ── */
/* Predicates take a tagged Char, return raw 0/1 (emitter tags to Bool). */
long long mdk_char_is_alpha(long long t) {
  long long c = t >> 1;
  return ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z')) ? 1 : 0;
}
long long mdk_char_is_space(long long t) {
  long long c = t >> 1;
  return (c == ' ' || (c >= 9 && c <= 13)) ? 1 : 0;
}
long long mdk_char_is_upper(long long t) {
  long long c = t >> 1;
  return (c >= 'A' && c <= 'Z') ? 1 : 0;
}
long long mdk_char_is_lower(long long t) {
  long long c = t >> 1;
  return (c >= 'a' && c <= 'z') ? 1 : 0;
}
/* charIsPunct matches Unicode general categories Pc/Pd/Pe/Pf/Pi/Po/Ps for ASCII.
   Several ASCII chars that C's ispunct() includes are Unicode symbols (Sm/Sc/Sk):
   $ + < = > ^ ` | ~  — these return 0. */
long long mdk_char_is_punct(long long t) {
  long long c = t >> 1;
  switch ((int)c) {
    case '!': case '"': case '#': case '%': case '&': case '\'':
    case '(': case ')': case '*': case ',': case '-': case '.':
    case '/': case ':': case ';': case '?': case '@': case '[':
    case '\\': case ']': case '_': case '{': case '}': return 1;
    default: return 0;
  }
}
long long mdk_char_to_upper(long long t) {
  long long c = t >> 1;
  if (c >= 'a' && c <= 'z') c -= 32;
  return (c << 1) | 1;
}
long long mdk_char_to_lower(long long t) {
  long long c = t >> 1;
  if (c >= 'A' && c <= 'Z') c += 32;
  return (c << 1) | 1;
}
/* Byte-wise ASCII case map: bytes >=0x80 (UTF-8 lead/continuation) are left
   untouched, so multibyte codepoints pass through unchanged. */
long long mdk_string_to_upper(long long s) {
  const char *cell = (const char *)s;
  long long bl = ((const long long *)cell)[1];
  const char *src = cell + 24;
  char *buf = (char *)mdk_alloc(bl + 1);
  for (long long i = 0; i < bl; i++) {
    char c = src[i];
    buf[i] = (c >= 'a' && c <= 'z') ? (char)(c - 32) : c;
  }
  return mdk_str_lit(buf, bl);
}
long long mdk_string_to_lower(long long s) {
  const char *cell = (const char *)s;
  long long bl = ((const long long *)cell)[1];
  const char *src = cell + 24;
  char *buf = (char *)mdk_alloc(bl + 1);
  for (long long i = 0; i < bl; i++) {
    char c = src[i];
    buf[i] = (c >= 'A' && c <= 'Z') ? (char)(c + 32) : c;
  }
  return mdk_str_lit(buf, bl);
}

/* ── Reserved ADT tags + cell constructors (native extern catalog, slice 10) ──
 * The runtime ADTs (List, Option, Result, Ordering) get FIXED composite tags so a C
 * extern can construct their cells with a tag a later Medaka `match` agrees with.
 * These MUST stay in sync with compiler/llvm_emit.mdk `reservedTag` / `ctorTagShift`:
 *   cellTag = (reservedTypeBase + typeId) * 2^32 + ordinal.
 * Nullary ctors are IMMEDIATE ((tag<<1)|1, RUNTIME-DESIGN §8.1); ctors with fields
 * are boxed cells [i64 tag | field… ] (fields at offset 8*(i+1)), matching
 * emitCtorAlloc.  Ordinals follow core.mdk: Option = Some|None, Result = Ok|Err,
 * Ordering = Lt|Eq|Gt; List = Cons|Nil. */
#define MDK_TAG_SHIFT     4294967296LL          /* 2^32 — ctorTagShift */
#define MDK_RESERVED_BASE 65536LL               /* reservedTypeBase */
#define MDK_TAG(tid, ord) (((MDK_RESERVED_BASE + (tid)) * MDK_TAG_SHIFT) + (ord))
#define MDK_TAG_CONS MDK_TAG(0, 0)
#define MDK_TAG_NIL  MDK_TAG(0, 1)
#define MDK_TAG_SOME MDK_TAG(1, 0)
#define MDK_TAG_NONE MDK_TAG(1, 1)
#define MDK_TAG_OK   MDK_TAG(2, 0)
#define MDK_TAG_ERR  MDK_TAG(2, 1)
#define MDK_TAG_LT   MDK_TAG(3, 0)
#define MDK_TAG_EQ   MDK_TAG(3, 1)
#define MDK_TAG_GT   MDK_TAG(3, 2)

/* Reserved type-id 4 is the `ByteBlock` cell header, not an ADT: it is stamped by
 * mdk_byteblock_alloc, which runs long before this block, so it carries its own
 * spelling.  The two must be the same word, and the next runtime ADT takes id 7. */
_Static_assert(MDK_BYTEBLOCK_TAG == MDK_TAG(4, 0),
               "ByteBlock header must be reserved type-id 4, ordinal 0");
/* Reserved type-id 5 is the `U64` cell header, likewise not an ADT, and 6 the
 * `I64` cell header. */
_Static_assert(MDK_U64_TAG == MDK_TAG(5, 0),
               "U64 header must be reserved type-id 5, ordinal 0");
_Static_assert(MDK_I64_TAG == MDK_TAG(6, 0),
               "I64 header must be reserved type-id 6, ordinal 0");

/* mdk_append's list discriminator and its fail-closed arm (forward-declared with
 * the byte-block ones, up beside MDK_STR_TAG): a List word is either the Nil
 * immediate or a boxed cell whose header is the reserved Cons tag.  A nullary
 * constructor of some OTHER type is also an odd immediate, and a boxed cell of
 * some other type also has a header, so both halves test the tag itself rather
 * than the low bit alone. */
static int mdk_is_list_word(long long w) {
  if ((w & 1) == 1) return (w >> 1) == MDK_TAG_NIL;
  return ((const long long *)w)[0] == MDK_TAG_CONS;
}
noreturn static void mdk_append_unsupported(void) {
  mdk_flush_run_stdout_on_abort();
  fputs("runtime error [E-APPEND-UNROUTED]: ++ reached the untyped runtime "
        "fallback on a value that is not a String or a List\n",
        stderr);
  exit(1);
}

/* Nullary ctors — immediate words. */
long long mdk_none(void) { return (MDK_TAG_NONE << 1) | 1; }
long long mdk_nil(void)  { return (MDK_TAG_NIL  << 1) | 1; }
long long mdk_lt(void)   { return (MDK_TAG_LT   << 1) | 1; }
long long mdk_eq(void)   { return (MDK_TAG_EQ   << 1) | 1; }
long long mdk_gt(void)   { return (MDK_TAG_GT   << 1) | 1; }

/* Ctors with fields — boxed cells [tag | field…]. */
long long mdk_some(long long x) {
  long long *c = (long long *)mdk_alloc(16); c[0] = MDK_TAG_SOME; c[1] = x;
  return (long long)c;
}
long long mdk_ok(long long x) {
  long long *c = (long long *)mdk_alloc(16); c[0] = MDK_TAG_OK; c[1] = x;
  return (long long)c;
}
long long mdk_err(long long x) {
  long long *c = (long long *)mdk_alloc(16); c[0] = MDK_TAG_ERR; c[1] = x;
  return (long long)c;
}
long long mdk_cons(long long head, long long tail) {
  long long *c = (long long *)mdk_alloc(24); c[0] = MDK_TAG_CONS; c[1] = head; c[2] = tail;
  return (long long)c;
}

/* charFromCode : Int -> Option Char — slice-10 canary.  Valid scalar value (0..0x10FFFF
 * excluding the UTF-16 surrogate range, matching OCaml Uchar.is_valid) -> Some (Char
 * immediate); otherwise None.  Exercises both the boxed Some and immediate None
 * reserved tags end-to-end against the oracle. */
long long mdk_char_from_code(long long n_tagged) {
  long long n = n_tagged >> 1;
  if (n >= 0 && n <= 0x10FFFF && !(n >= 0xD800 && n <= 0xDFFF))
    return mdk_some((n << 1) | 1);   /* Some (Char immediate) */
  return mdk_none();
}

/* slice 11: ADT-returning string externs. */

/* Box a double as a Float cell [header=2 | double], matching emitter boxFloat. */
static long long mdk_box_float(double d) {
  long long *c = (long long *)mdk_alloc(16);
  c[0] = 2; ((double *)c)[1] = d; return (long long)c;
}

/* ── G3: polymorphic `Num a =>` arithmetic (runtime numeric dispatch) ─────────
 * A `Num a =>`-constrained function (`double x = x + x`) is monomorphic at the
 * IR level: its operand could be an immediate Int (odd word, low bit 1) OR a
 * boxed Float (even pointer to {header=2, double}).  The emitter cannot pick
 * int- vs float-instructions statically (the param type is the type variable
 * `a`), so for LTNum operands it emits a call to these helpers, which discriminate
 * on the low bit — exactly the discipline `mdk_append` uses for `++`.  At a
 * CONCRETE Int or Float type the emitter keeps its specialized inline IR (these
 * helpers are never reached), so every byte-diff gate is unchanged.
 *
 * Both operands of one `Num` op share a type (well-typed), so testing the LEFT
 * operand's tag suffices.  Int untag = >>1 (arithmetic); re-tag = (n<<1)|1.
 * A boxed U64 (header MDK_U64_TAG) is the third shape: it wraps modulo 2^64 and
 * divides unsigned, as the typecheck-stamped inline U64 path does, and must be
 * tested before the Float fallback, which would read its payload as a double.
 * A boxed I64 (MDK_I64_TAG) is the fourth: the same bits for `+ - *`, boxed back
 * under its own header, and a signed, truncating `/` and `%`. */
static inline int mdk_is_int(long long w) { return (w & 1) != 0; }

static int mdk_is_w64(long long w) { return mdk_is_u64(w) || mdk_is_i64(w); }

/* a 64-bit result under the header of `like`, a U64 or I64 cell. */
static long long mdk_box_w64_like(long long like, unsigned long long x) {
  return mdk_is_i64(like) ? mdk_box_i64((long long)x) : mdk_box_u64(x);
}

/* Int's arithmetic here traps as the inline path does (mdk_int_overflow): on
   the tagged words, (2a+1) + 2b = 2(a+b)+1 overflows 64 bits exactly when a+b
   overflows 63, and likewise for `-`; `*` multiplies a by 2b. */
long long mdk_num_add(long long l, long long r) {
  if (mdk_is_int(l)) {
    long long s;
    if (__builtin_add_overflow(l, r - 1, &s)) mdk_int_overflow(0, l >> 1, r >> 1);
    return s;
  }
  if (mdk_is_w64(l)) return mdk_box_w64_like(l, mdk_u64_payload(l) + mdk_u64_payload(r));
  return mdk_box_float(((double *)l)[1] + ((double *)r)[1]);
}
long long mdk_num_sub(long long l, long long r) {
  if (mdk_is_int(l)) {
    long long s;
    if (__builtin_sub_overflow(l, r - 1, &s)) mdk_int_overflow(1, l >> 1, r >> 1);
    return s;
  }
  if (mdk_is_w64(l)) return mdk_box_w64_like(l, mdk_u64_payload(l) - mdk_u64_payload(r));
  return mdk_box_float(((double *)l)[1] - ((double *)r)[1]);
}
long long mdk_num_mul(long long l, long long r) {
  if (mdk_is_int(l)) {
    long long p;
    if (__builtin_mul_overflow(l >> 1, r - 1, &p)) mdk_int_overflow(2, l >> 1, r >> 1);
    return p | 1;
  }
  if (mdk_is_w64(l)) return mdk_box_w64_like(l, mdk_u64_payload(l) * mdk_u64_payload(r));
  return mdk_box_float(((double *)l)[1] * ((double *)r)[1]);
}
long long mdk_num_div(long long l, long long r) {
  if (mdk_is_int(l)) {
    long long q, t;
    if ((r >> 1) == 0) mdk_div_zero();
    q = (l >> 1) / (r >> 1);
    if (__builtin_add_overflow(q, q, &t)) mdk_int_overflow(3, l >> 1, r >> 1);
    return t | 1;
  }
  if (mdk_is_u64(l)) {
    if (mdk_u64_payload(r) == 0) mdk_div_zero();
    return mdk_box_u64(mdk_u64_payload(l) / mdk_u64_payload(r));
  }
  if (mdk_is_i64(l)) {
    if (mdk_i64_payload(r) == 0) mdk_div_zero();
    return mdk_box_i64(mdk_i64_div(mdk_i64_payload(l), mdk_i64_payload(r)));
  }
  return mdk_box_float(((double *)l)[1] / ((double *)r)[1]);
}
long long mdk_num_mod(long long l, long long r) {
  if (mdk_is_int(l)) {
    if ((r >> 1) == 0) mdk_mod_zero();
    return (((l >> 1) % (r >> 1)) << 1) | 1;
  }
  if (mdk_is_u64(l)) {
    if (mdk_u64_payload(r) == 0) mdk_mod_zero();
    return mdk_box_u64(mdk_u64_payload(l) % mdk_u64_payload(r));
  }
  if (mdk_is_i64(l)) {
    if (mdk_i64_payload(r) == 0) mdk_mod_zero();
    return mdk_box_i64(mdk_i64_mod(mdk_i64_payload(l), mdk_i64_payload(r)));
  }
  double a = ((double *)l)[1], b = ((double *)r)[1];
  /* #345: fmod, not `a - b*trunc(a/b)`.  The trunc-cast overflows i64 when
   * |a/b| > ~9.2e18 (e.g. 1e300 % 7) -> UB garbage -> silent wrong answer.
   * fmod matches every other `%` path (frem inline emit, mdk_float_rem, eval). */
  return mdk_box_float(fmod(a, b));
}
/* floatRem : Float -> Float -> Float — fmod, which is bit-for-bit LLVM `frem`
 * (the inline emit for `Float % Float`) so the interpreter's `%` matches build. */
double mdk_float_rem(double a, double b) {
  return fmod(a, b);
}

/* libm math shims (native/LLVM only) — each a thin wrapper over math.h.
 * The evaluator (compiler/eval/eval.mdk) calls these via the runtime.mdk
 * externs; the LLVM emitter emits direct `call double @mdk_<name>(...)`. */
double mdk_sqrt(double a) { return sqrt(a); }
double mdk_cbrt(double a) { return cbrt(a); }
double mdk_exp(double a) { return exp(a); }
double mdk_log(double a) { return log(a); }
double mdk_log2(double a) { return log2(a); }
double mdk_log10(double a) { return log10(a); }
double mdk_sin(double a) { return sin(a); }
double mdk_cos(double a) { return cos(a); }
double mdk_tan(double a) { return tan(a); }
double mdk_asin(double a) { return asin(a); }
double mdk_acos(double a) { return acos(a); }
double mdk_atan(double a) { return atan(a); }
double mdk_sinh(double a) { return sinh(a); }
double mdk_cosh(double a) { return cosh(a); }
double mdk_tanh(double a) { return tanh(a); }
double mdk_floor(double a) { return floor(a); }
double mdk_ceil(double a) { return ceil(a); }
double mdk_round(double a) { return round(a); }
double mdk_trunc(double a) { return trunc(a); }
double mdk_pow(double a, double b) { return pow(a, b); }
double mdk_atan2(double a, double b) { return atan2(a, b); }
double mdk_hypot(double a, double b) { return hypot(a, b); }

/* Print a polymorphic numeric value (LTNum result of `Num a =>` arithmetic):
 * dispatch on the runtime tag like the arithmetic helpers above. */
void mdk_print_num(long long w) {
  if (mdk_is_int(w)) mdk_print_int(w >> 1);
  else if (mdk_is_u64(w)) mdk_print_u64(w);
  else if (mdk_is_i64(w)) mdk_print_i64(w);
  else mdk_print_float(((double *)w)[1]);
}

long long mdk_string_to_float(long long s) {
  const char *cell = (const char *)s;
  long long bl = ((const long long *)cell)[1];
  const char *bytes = cell + 24;
  if (bl == 0) return mdk_none();
  char *end; errno = 0;
  double d = strtod(bytes, &end);
  if (end != bytes + bl) return mdk_none();
  return mdk_some(mdk_box_float(d));
}

long long mdk_string_index_of(long long needle, long long hay) {
  const char *nc = (const char *)needle, *hc = (const char *)hay;
  long long nl = ((const long long *)nc)[1], hl = ((const long long *)hc)[1];
  const char *nb = nc + 24, *hb = hc + 24;
  if (nl == 0) return mdk_some(1);   /* empty needle -> index 0 (Int immediate) */
  for (long long b = 0; b + nl <= hl; b++)
    if (memcmp(hb + b, nb, (size_t)nl) == 0) {
      long long cp = mdk_utf8_cp_count(hb, b);
      return mdk_some((cp << 1) | 1);
    }
  return mdk_none();
}

long long mdk_string_compare(long long a, long long b) {
  const char *ac = (const char *)a, *bc = (const char *)b;
  long long al = ((const long long *)ac)[1], bl = ((const long long *)bc)[1];
  long long m = al < bl ? al : bl;
  int c = memcmp(ac + 24, bc + 24, (size_t)m);
  if (c == 0) c = (al < bl) ? -1 : (al > bl) ? 1 : 0;
  return c < 0 ? mdk_lt() : c > 0 ? mdk_gt() : mdk_eq();
}

/* Raw three-way string compare: -1 / 0 / 1 as a PLAIN i64 (NOT a tagged Ordering
 * cell).  Backs the emitter's string ordering operators (`<`/`>`/`<=`/`>=`): the
 * emitted IR does `icmp <pred> i64 (mdk_string_compare_raw a b), 0`, mirroring the
 * `cmp <pred> 0` idiom a C `strcmp` caller uses.  (mdk_string_compare returns an
 * Ordering ADT for the `Ord String.compare` method; this is the operator path.) */
long long mdk_string_compare_raw(long long a, long long b) {
  const char *ac = (const char *)a, *bc = (const char *)b;
  long long al = ((const long long *)ac)[1], bl = ((const long long *)bc)[1];
  long long m = al < bl ? al : bl;
  int c = memcmp(ac + 24, bc + 24, (size_t)m);
  if (c == 0) c = (al < bl) ? -1 : (al > bl) ? 1 : 0;
  return c < 0 ? -1 : c > 0 ? 1 : 0;
}

/* Polymorphic three-way compare over operands whose static LTy the emitter could
 * not recover — both default to LTInt, e.g. a String/Float bound through a tuple
 * destructure inside a recursive list walk (`k <= k2` where `(k,_)`/`(k2,_)` came
 * from `(String,String)` pair fields).  An inline integer `icmp` there compares
 * boxed-String/Float POINTERS as ints — pointer-identity ordering, the heap-ADDRESS
 * bug.  This is the ordering analog of mdk_value_eq: discriminate at run time on
 * the low bit / header tag and return a PLAIN -1/0/1 i64 (like
 * mdk_string_compare_raw).  Both operands of one Ord op share a type (well-typed),
 * so testing the LEFT operand suffices:
 *   - boxed String cell (even pointer, header == MDK_STR_TAG) -> byte compare;
 *   - boxed Float cell  (even pointer, header == 2)           -> double compare;
 *   - otherwise (tagged immediate: Int/Bool/Char, or a ctor word) -> word compare
 *     of the untagged (>>1) immediates, matching the inline Int icmp path.
 * At a CONCRETE Int/Float/String type the emitter keeps its specialized inline
 * IR (the `==` peer is mdk_value_eq, which carries the same String/Float/word
 * arms — keep the two in lockstep), so this is reached only at a genuinely
 * type-unknown site.
 *
 * ⚠️ #305: the Float arm is NOT IEEE — an unordered (NaN) pair collapses to 0,
 * which reads as EQ.  A three-way -1/0/1 cannot express unorderedness at all, so
 * this function MUST NOT back a relational operator: `<`/`<=`/`>`/`>=` go through
 * mdk_value_lt/le/gt/ge, which take the Float arm themselves and only fall back
 * here for the String/immediate shapes (where -1/0/1 is exact). */
long long mdk_value_cmp_raw(long long a, long long b) {
  int a_str = ((a & 1) == 0) && ((const long long *)a)[0] == MDK_STR_TAG;
  if (a_str) return mdk_string_compare_raw(a, b);
  /* Lockstep with mdk_value_eq's byte-block arm and with the interpreter's
   * `valueCompare (VByteBlock …)`: lexicographic over the bytes, shorter
   * prefix first. */
  if (mdk_is_byteblock(a)) return mdk_byteblock_cmp_bytes(a, b);
  /* Lockstep with mdk_value_eq's U64 arm: unsigned order on the payload, so a
   * value at or above 2^63 sorts above every smaller one. */
  if (mdk_is_u64(a)) {
    unsigned long long ua = mdk_u64_payload(a), ub = mdk_u64_payload(b);
    return ua < ub ? -1 : ua > ub ? 1 : 0;
  }
  /* An I64 is the same payload read signed. */
  if (mdk_is_i64(a)) {
    long long sa = mdk_i64_payload(a), sb = mdk_i64_payload(b);
    return sa < sb ? -1 : sa > sb ? 1 : 0;
  }
  int a_flt = ((a & 1) == 0) && ((const long long *)a)[0] == 2;
  if (a_flt) {
    double da = ((const double *)a)[1], db = ((const double *)b)[1];
    return da < db ? -1 : da > db ? 1 : 0;
  }
  long long ia = a >> 1, ib = b >> 1;
  return ia < ib ? -1 : ia > ib ? 1 : 0;
}

/* #305 (S0) — IEEE relational predicates for the TYPE-LOST ordering path.
 * EMITTER-SEMANTICS §4 N5/N6: `<` `<=` `>` `>=` at Float are PRIMITIVE IEEE
 * predicates on EVERY path (all four FALSE at NaN) and must never be derived
 * from `compare`/value_cmp.  The 3-way -1/0/1 Ordering that mdk_value_cmp_raw
 * returns STRUCTURALLY CANNOT express NaN's unorderedness — its Float arm
 * collapses an unordered pair to 0 (EQ), so a caller doing `cmp <= 0` read
 * `nan <= nan` as TRUE.  These four answer the relational question DIRECTLY
 * for a boxed-Float operand (the same f64 compare as the inline `fcmp ole`/…
 * the emitter uses when it CAN see Float statically — so the type-lost and
 * static paths now agree), and delegate every other shape (String cell /
 * tagged immediate) to the 3-way, which is exact for those.  Returns a TAGGED
 * Bool (3 = True, 1 = False), matching mdk_value_eq.
 *
 * mdk_value_cmp_raw KEEPS its Float arm: it is a three-way answer, still used
 * for the non-Float shapes below.  But it is NOT IEEE at NaN and must never
 * again be made to back a relational operator — that is exactly bug #305.
 * (`compare`/`min`/`max`/`sort` never route here; they go through the Ord
 * dict.  Whether `compare` at NaN should be IEEE totalOrder is issue #360.) */
static int mdk_value_is_float(long long a) {
  return ((a & 1) == 0) && ((const long long *)a)[0] == 2;
}

long long mdk_value_lt(long long a, long long b) {
  if (mdk_value_is_float(a))
    return ((const double *)a)[1] < ((const double *)b)[1] ? 3 : 1;
  return mdk_value_cmp_raw(a, b) < 0 ? 3 : 1;
}

long long mdk_value_le(long long a, long long b) {
  if (mdk_value_is_float(a))
    return ((const double *)a)[1] <= ((const double *)b)[1] ? 3 : 1;
  return mdk_value_cmp_raw(a, b) <= 0 ? 3 : 1;
}

long long mdk_value_gt(long long a, long long b) {
  if (mdk_value_is_float(a))
    return ((const double *)a)[1] > ((const double *)b)[1] ? 3 : 1;
  return mdk_value_cmp_raw(a, b) > 0 ? 3 : 1;
}

long long mdk_value_ge(long long a, long long b) {
  if (mdk_value_is_float(a))
    return ((const double *)a)[1] >= ((const double *)b)[1] ? 3 : 1;
  return mdk_value_cmp_raw(a, b) >= 0 ? 3 : 1;
}

/* slice 12: args + env ---------------------------------------------------- */
static int    mdk_argc = 0;
static char **mdk_argv = 0;
void mdk_set_args(int argc, char **argv) { mdk_argc = argc; mdk_argv = argv; }

/* args : Unit -> List String — argv[1..] as Cons cells, built back-to-front. */
long long mdk_args(long long unit_ignored) {
  (void)unit_ignored;
  long long acc = mdk_nil();
  for (int i = mdk_argc - 1; i >= 1; i--)
    acc = mdk_cons(mdk_str_lossy(mdk_argv[i], (long long)strlen(mdk_argv[i])), acc);
  return acc;
}

/* getEnv : String -> Option String.  name cell is NUL-terminated at +24. */
long long mdk_get_env(long long name) {
  const char *v = getenv((const char *)name + 24);
  if (v == 0) return mdk_none();
  return mdk_some(mdk_str_lossy(v, (long long)strlen(v)));
}

/* slice 13: file IO + stdin readers --------------------------------------- */

/* Helper: String cell from a NUL-terminated C string handed back by the host
 * (a path, a directory entry, an strerror message), so read as outside bytes. */
static long long mdk_str_cstr(const char *s) {
  return mdk_str_lossy(s, (long long)strlen(s));
}

/* Every file extern whose path is an authority receives, after its value
 * arguments, the authority granted for each path (EFFECTS-SEMANTICS §8): a
 * List String of domain elements, a trailing `*` spelling a pattern, and Nil
 * for the whole domain.  It exists for confinement and cannot change a value
 * an extern returns.
 *
 * Confinement compares canonical paths, never strings, because the kernel
 * resolves `..` and symlinks and the type checker cannot.  A path is admitted
 * when its canonical form is admitted by some element of the grant, each
 * element canonicalized the same way against the working directory:
 *   - an exact element admits the path whose canonical form equals its own;
 *   - a pattern `<dir>/<stem>*` admits a canonical path that starts with the
 *     canonical `<dir>` followed by `/<stem>`, and a pattern whose stem is empty
 *     also admits `<dir>` itself; a pattern with no `/` has the working
 *     directory as its `<dir>`, and `*` alone admits every path.
 * A refused path is reported as "<path> is outside the granted authority
 * [<elements>]": an Err from an extern that returns a Result, a panic from
 * fileExists and canonicalizePath.  The interpreter's confinePath in
 * compiler/eval/eval.mdk states the same rules and must stay in step with this
 * one. */

/* Components of `p`, split on `/`, with empty and `.` components dropped.
 * Writes into `buf` (a copy of p) and `comps`; returns the count, or -1 when
 * `p` is too long to canonicalize. */
static int mdk_path_components(const char *p, char *buf, char **comps) {
  size_t n = strlen(p);
  if (n >= PATH_MAX) return -1;
  memcpy(buf, p, n + 1);
  int count = 0;
  char *s = buf;
  while (*s) {
    while (*s == '/') *s++ = '\0';
    if (!*s) break;
    char *start = s;
    while (*s && *s != '/') s++;
    if (*s) *s++ = '\0';
    if (strcmp(start, ".") != 0) comps[count++] = start;
  }
  return count;
}

/* `base` (`/` or `.`) followed by comps[0..k), joined by `/`, into `out`. */
static int mdk_path_join(int absolute, char **comps, int k, char *out) {
  size_t len = 0;
  out[len++] = absolute ? '/' : '.';
  out[len] = '\0';
  for (int i = 0; i < k; i++) {
    size_t cl = strlen(comps[i]);
    if (len + 1 + cl >= PATH_MAX) return 0;
    if (!(absolute && len == 1)) out[len++] = '/';
    memcpy(out + len, comps[i], cl);
    len += cl;
    out[len] = '\0';
  }
  return 1;
}

/* `dir` followed by `/name`, into `out`, `dir` being canonical. */
static int mdk_path_append(char *out, const char *name) {
  size_t len = strlen(out), nl = strlen(name);
  int root = len == 1 && out[0] == '/';
  if (len + (root ? 0 : 1) + nl >= PATH_MAX) return 0;
  if (!root) out[len++] = '/';
  memcpy(out + len, name, nl + 1);
  return 1;
}

/* The canonical form of `p` into `out` (PATH_MAX bytes); 0 when it has none.
 * When every component resolves it is realpath(3).  Otherwise it is the
 * realpath of the longest prefix that resolves, followed by the remaining
 * components, which may not include `..` and whose first must be absent: an
 * entry that is present yet does not resolve is a dangling or looping symlink,
 * whose target could lie anywhere.  In entry mode the last component is
 * appended to its directory's canonical form unresolved, since unlink, rmdir,
 * rename and mkdir act on the entry, not on what it points to. */
static int mdk_canon_path(const char *p, int entry, char *out) {
  char *comps[PATH_MAX / 2 + 1];
  char buf[PATH_MAX], probe[PATH_MAX];
  if (p[0] == '\0') return 0;
  int absolute = p[0] == '/';
  int n = mdk_path_components(p, buf, comps);
  if (n < 0) return 0;
  if (entry && n > 0 && strcmp(comps[n - 1], "..") != 0) {
    char last[PATH_MAX];
    strcpy(last, comps[n - 1]);
    if (!mdk_path_join(absolute, comps, n - 1, probe)) return 0;
    if (!mdk_canon_path(probe, 0, out)) return 0;
    return mdk_path_append(out, last);
  }
  int k = n;
  for (; k >= 0; k--) {
    if (!mdk_path_join(absolute, comps, k, probe)) return 0;
    if (realpath(probe, out) != 0) break;
  }
  if (k < 0) return 0;
  if (k == n) return 1;
  for (int i = k; i < n; i++)
    if (strcmp(comps[i], "..") == 0) return 0;
  strcpy(probe, out);
  if (!mdk_path_append(probe, comps[k])) return 0;
  struct stat st;
  if (lstat(probe, &st) == 0) return 0;
  for (int i = k; i < n; i++)
    if (!mdk_path_append(out, comps[i])) return 0;
  return 1;
}

/* Whether one grant element admits the canonical path `canon`. */
static int mdk_element_admits(const char *elem, long long elem_len, const char *canon) {
  char e[PATH_MAX], d[PATH_MAX];
  if (elem_len >= PATH_MAX) return 0;
  memcpy(e, elem, (size_t)elem_len);
  e[elem_len] = '\0';
  if (elem_len > 0 && e[elem_len - 1] == '*') {
    e[elem_len - 1] = '\0';
    if (e[0] == '\0') return 1;
    char *slash = strrchr(e, '/');
    const char *stem;
    if (slash == 0) {
      strcpy(d, ".");
      stem = e;
    } else {
      stem = slash + 1;
      if (slash == e) strcpy(d, "/");
      else { *slash = '\0'; strcpy(d, e); }
    }
    char want[PATH_MAX];
    if (!mdk_canon_path(d, 0, want)) return 0;
    if (stem[0] == '\0' && strcmp(canon, want) == 0) return 1;
    if (!mdk_path_append(want, stem)) return 0;
    return strncmp(canon, want, strlen(want)) == 0;
  }
  char c[PATH_MAX];
  if (!mdk_canon_path(e, 0, c)) return 0;
  return strcmp(c, canon) == 0;
}

/* NULL when `grant` admits `path`, else the refusal message as a String cell. */
static long long mdk_confine(long long path, long long grant, int entry) {
  if (grant == mdk_nil()) return 0;
  const char *p = (const char *)path + 24;
  char canon[PATH_MAX];
  int ok = mdk_canon_path(p, entry, canon);
  for (long long g = grant; ok && g != mdk_nil(); g = ((const long long *)g)[2]) {
    long long s = ((const long long *)g)[1];
    if (mdk_element_admits((const char *)s + 24, ((const long long *)s)[1], canon))
      return 0;
  }
  long long msg = mdk_string_append(
      path, mdk_str_cstr(" is outside the granted authority ["));
  for (long long g = grant; g != mdk_nil(); g = ((const long long *)g)[2]) {
    if (g != grant) msg = mdk_string_append(msg, mdk_str_cstr(", "));
    msg = mdk_string_append(msg, mdk_str_cstr("\""));
    msg = mdk_string_append(msg, ((const long long *)g)[1]);
    msg = mdk_string_append(msg, mdk_str_cstr("\""));
  }
  return mdk_string_append(msg, mdk_str_cstr("]"));
}

struct mdk_file_bound {
  int write;
  long long grant;
  struct mdk_file_bound *parent;
};
static _Thread_local struct mdk_file_bound *mdk_file_bounds;
static const long long mdk_file_bound_unit = 1;

static int mdk_same_file_grant(long long a, long long b) {
  while (a != b) {
    if (a == mdk_nil() || b == mdk_nil()) return 0;
    if (mdk_string_eq(((const long long *)a)[1], ((const long long *)b)[1]) != 3)
      return 0;
    a = ((const long long *)a)[2];
    b = ((const long long *)b)[2];
  }
  return 1;
}

long long mdk_with_file_bound(long long write, long long grant, long long thunk) {
  /* Re-entering an existing bound adds no restriction. This return stays a
   * tail call, so a recursive bounded function does not accumulate frames. */
  if (grant == mdk_nil()) return __mdk_apply(thunk, 1, &mdk_file_bound_unit);
  for (struct mdk_file_bound *b = mdk_file_bounds; b; b = b->parent)
    if (b->write == write && mdk_same_file_grant(b->grant, grant))
      return __mdk_apply(thunk, 1, &mdk_file_bound_unit);
  struct mdk_file_bound frame = {(int)write, grant, mdk_file_bounds};
  mdk_file_bounds = &frame;
  long long result = __mdk_apply(thunk, 1, &mdk_file_bound_unit);
  mdk_file_bounds = frame.parent;
  return result;
}

static long long mdk_confine_bounds(long long path, long long grant, int entry, int write) {
  long long refused = mdk_confine(path, grant, entry);
  for (struct mdk_file_bound *b = mdk_file_bounds; !refused && b; b = b->parent)
    if (b->write == write) refused = mdk_confine(path, b->grant, entry);
  return refused;
}

#define MDK_CONFINE(path, grant, entry, write)                       \
  do {                                                        \
    long long refused_ = mdk_confine_bounds((path), (grant), (entry), (write)); \
    if (refused_) return mdk_err(refused_);                   \
  } while (0)

/* readFile : String -> Result String String — Ok content / Err msg.
 * fopen(2) happily opens a directory for reading, but SEEK_END+ftell then
 * reports an absurd size (LONG_MAX on ext4), which overflows mdk_alloc and
 * sends the GC after ~2^63 bytes — and even where it doesn't, fread on a
 * directory FD silently returns 0, so the caller would get a quiet "" for a
 * directory instead of an error.  Reject directories up front with S_ISDIR
 * (already used for fileType/stat below), mirroring the existing
 * mdk_err(mdk_str_cstr(strerror(errno))) shape.
 *
 * Contents that are not well-formed UTF-8 are an Err naming the path, never a
 * String: a file is where raw bytes most often come from, so a silent U+FFFD
 * here would lose data the caller never saw; readFileBytes is the raw route.
 * The bytes are read straight into the String cell and validated there. */
long long mdk_read_file(long long path, long long grant) {
  MDK_CONFINE(path, grant, 0, 0);
  const char *p = (const char *)path + 24;
  struct stat st;
  if (stat(p, &st) == 0 && S_ISDIR(st.st_mode))
    return mdk_err(mdk_str_cstr("Is a directory"));
  FILE *f = fopen(p, "rb");
  if (!f) return mdk_err(mdk_str_cstr(strerror(errno)));
  fseek(f, 0, SEEK_END); long n = ftell(f); fseek(f, 0, SEEK_SET);
  if (n < 0) n = 0;
  char *cell = (char *)mdk_alloc_atomic(24 + n + 1);
  size_t got = fread(cell + 24, 1, (size_t)n, f); fclose(f);
  long long cps = mdk_utf8_valid_count(cell + 24, got);
  if (cps < 0) {
    static const char msg[] =
      ": not valid UTF-8 (use readFileBytes for raw bytes)";
    return mdk_err(mdk_string_append(
      path, mdk_str_lit(msg, (long long)(sizeof msg - 1))));
  }
  ((long long *)cell)[0] = MDK_STR_TAG;
  ((long long *)cell)[1] = (long long)got;
  ((long long *)cell)[2] = cps;
  cell[24 + got] = '\0';
  return mdk_ok((long long)cell);
}

/* readFileBytes : String -> Result String (Array Int) — raw bytes, no decode.
 * Builds an Array cell [len, b0<<1|1, b1<<1|1, ...] of TAGGED int byte values
 * 0..255 (mirrors mdk_array_from_list element tagging).
 * Same directory guard as mdk_read_file — see comment there. */
long long mdk_read_file_bytes(long long path, long long grant) {
  MDK_CONFINE(path, grant, 0, 0);
  const char *p = (const char *)path + 24;
  struct stat st;
  if (stat(p, &st) == 0 && S_ISDIR(st.st_mode))
    return mdk_err(mdk_str_cstr("Is a directory"));
  FILE *f = fopen(p, "rb");
  if (!f) return mdk_err(mdk_str_cstr(strerror(errno)));
  fseek(f, 0, SEEK_END); long n = ftell(f); fseek(f, 0, SEEK_SET);
  unsigned char *buf = (unsigned char *)mdk_alloc(n + 1);
  size_t got = fread(buf, 1, (size_t)n, f); fclose(f);
  long long *cell = (long long *)mdk_alloc(8 * ((long long)got + 1));
  cell[0] = (long long)got;
  for (size_t i = 0; i < got; i++) cell[i + 1] = (((long long)buf[i]) << 1) | 1;
  return mdk_ok((long long)cell);
}

/* Bitwise / shift primitives.  Args arrive UNTAGGED (emitter untagInts them)
 * and the result is retagged by the emitter (tagInt: (r<<1)|1, which discards
 * the top bit so bitNot matches OCaml lnot on the 63-bit rep).  shiftRight is
 * LOGICAL: >> on the untagged non-negative 63-bit value == OCaml lsr for the
 * non-negative (binary-decoding) case. */
long long mdk_bit_and(long long a, long long b)    { return a & b; }
long long mdk_bit_or(long long a, long long b)     { return a | b; }
long long mdk_bit_xor(long long a, long long b)    { return a ^ b; }
long long mdk_bit_not(long long a)                 { return ~a; }

/* Int shifts.  An amount of 63 or more shifts every bit out: `shiftLeft` gives
   0 and `shiftRight` gives 0 or, for a negative value, -1 (the sign fills).  A
   negative amount panics, as it does for the U types.  `shiftLeft` discards the
   bits shifted past bit 62 (the retag drops bit 63), so it never traps; the
   unsigned shift keeps C from calling a negative operand's shift undefined.
   `shiftRight` is arithmetic: the vacated bits copy the sign. */
static noreturn void mdk_negative_shift(const char *name, long long k) {
  mdk_flush_run_stdout_on_abort();
  fprintf(stderr, "runtime error [E-PANIC]: %s: negative shift %lld\n", name, k);
  exit(1);
}
long long mdk_shift_left(long long a, long long b) {
  if (b < 0) mdk_negative_shift("shiftLeft", b);
  return b >= 63 ? 0 : (long long)((unsigned long long)a << b);
}
long long mdk_shift_right(long long a, long long b) {
  if (b < 0) mdk_negative_shift("shiftRight", b);
  return a >> (b >= 63 ? 63 : b);
}

static long long mdk_write_impl(long long path, long long content, const char *mode) {
  const char *p = (const char *)path + 24;
  const char *c = (const char *)content + 24;
  long long cl = ((const long long *)content)[1];
  FILE *f = fopen(p, mode);
  if (!f) return mdk_err(mdk_str_cstr(strerror(errno)));
  fwrite(c, 1, (size_t)cl, f); fclose(f);
  return mdk_ok(1);  /* Ok () — Unit field, value irrelevant */
}

/* writeFile : String -> String -> Result String Unit — truncating write. */
long long mdk_write_file(long long path, long long content, long long grant) {
  MDK_CONFINE(path, grant, 0, 1);
  return mdk_write_impl(path, content, "wb");
}
/* appendFile : String -> String -> Result String Unit — append (create if absent). */
long long mdk_append_file(long long path, long long content, long long grant) {
  MDK_CONFINE(path, grant, 0, 1);
  return mdk_write_impl(path, content, "ab");
}

/* writeFileBytes : String -> Array Int -> Result String Unit — write raw bytes.
 * arr[0] = length; arr[i+1] = tagged int byte ((byte << 1)|1) for i in 0..len-1.
 * Untag each element: (elem >> 1) & 0xFF.  Byte-clean write counterpart of
 * mdk_read_file_bytes. */
long long mdk_write_file_bytes(long long path, long long arr, long long grant) {
  MDK_CONFINE(path, grant, 0, 1);
  const char *p = (const char *)path + 24;
  const long long *a = (const long long *)arr;
  long long n = a[0];
  FILE *f = fopen(p, "wb");
  if (!f) return mdk_err(mdk_str_cstr(strerror(errno)));
  for (long long i = 0; i < n; i++) {
    unsigned char b = (unsigned char)((a[i + 1] >> 1) & 0xFF);
    fputc(b, f);
  }
  fclose(f);
  return mdk_ok(1);  /* Ok () — Unit field, value irrelevant */
}

/* writeFileMode : String -> Int -> String -> Result String Unit.
 * Truncating write that leaves the file at exactly `mode`'s permission bits.
 * open(2)'s mode argument applies only when the file is CREATED, and umask
 * narrows it even then; an existing file keeps whatever mode it already had.
 * fchmod on the open descriptor settles both cases, and it runs BEFORE the
 * first byte is written, so the contents never exist at a wider mode. */
long long mdk_write_file_mode(long long path, long long mode_tagged, long long content,
                               long long grant) {
  MDK_CONFINE(path, grant, 0, 1);
  const char *p = (const char *)path + 24;
  const char *c = (const char *)content + 24;
  long long cl = ((const long long *)content)[1];
  mode_t mode = (mode_t)((mode_tagged >> 1) & 07777);
  int fd = open(p, O_WRONLY | O_CREAT | O_TRUNC, mode);
  if (fd < 0) return mdk_err(mdk_str_cstr(strerror(errno)));
  if (fchmod(fd, mode) != 0) {
    int saved = errno; close(fd);
    return mdk_err(mdk_str_cstr(strerror(saved)));
  }
  { long long off = 0;
    while (off < cl) {
      ssize_t w = write(fd, c + off, (size_t)(cl - off));
      if (w < 0) {
        int saved = errno; close(fd);
        return mdk_err(mdk_str_cstr(strerror(saved)));
      }
      off += (long long)w;
    } }
  if (close(fd) != 0) return mdk_err(mdk_str_cstr(strerror(errno)));
  return mdk_ok(1);  /* Ok () — Unit field, value irrelevant */
}

/* fileMode : String -> Result String Int — st_mode's permission bits (& 07777),
 * as a tagged Int inside Ok.  stat(2), so a symlink reports its target. */
long long mdk_file_mode(long long path, long long grant) {
  MDK_CONFINE(path, grant, 0, 0);
  const char *p = (const char *)path + 24;
  struct stat st;
  if (stat(p, &st) != 0) return mdk_err(mdk_str_cstr(strerror(errno)));
  return mdk_ok(((((long long)st.st_mode) & 07777) << 1) | 1);
}

/* fileExists : String -> Bool — raw 0/1, emitter tags via tagInt. */
long long mdk_file_exists(long long path, long long grant) {
  long long refused = mdk_confine_bounds(path, grant, 0, 0);
  if (refused) mdk_panic(refused);
  return access((const char *)path + 24, F_OK) == 0 ? 1 : 0;
}

/* canonicalizePath : String -> String — realpath(3); input unchanged on failure
 * (matches the OCaml oracle's `try Unix.realpath p with _ -> p`). */
long long mdk_canonicalize_path(long long path, long long grant) {
  long long refused = mdk_confine_bounds(path, grant, 0, 0);
  if (refused) mdk_panic(refused);
  const char *p = (const char *)path + 24;
  char buf[PATH_MAX];
  if (realpath(p, buf) != 0) return mdk_str_cstr(buf);
  return mdk_str_cstr(p);
}

/* listDir : String -> Result String (List String).
 * OCaml Sys.readdir excludes "." and ".." — skip them for correctness. */
long long mdk_list_dir(long long path, long long grant) {
  MDK_CONFINE(path, grant, 0, 0);
  const char *p = (const char *)path + 24;
  DIR *d = opendir(p);
  if (!d) return mdk_err(mdk_str_cstr(strerror(errno)));
  long long acc = mdk_nil(); struct dirent *e;
  while ((e = readdir(d))) {
    if (!strcmp(e->d_name, ".") || !strcmp(e->d_name, "..")) continue;
    acc = mdk_cons(mdk_str_cstr(e->d_name), acc);
  }
  closedir(d);
  return mdk_ok(acc);
}

/* makeDir : String -> Result String Unit — mkdir 0755. */
long long mdk_make_dir(long long path, long long grant) {
  MDK_CONFINE(path, grant, 1, 1);
  const char *p = (const char *)path + 24;
  if (mkdir(p, 0755) == 0) return mdk_ok(1);  /* Ok () */
  return mdk_err(mdk_str_cstr(strerror(errno)));
}

/* removeFile : String -> Result String Unit — unlink(2). */
long long mdk_remove_file(long long path, long long grant) {
  MDK_CONFINE(path, grant, 1, 1);
  const char *p = (const char *)path + 24;
  if (unlink(p) == 0) return mdk_ok(1);  /* Ok () */
  return mdk_err(mdk_str_cstr(strerror(errno)));
}

/* rename : String -> String -> Result String Unit — rename(2) old new. */
long long mdk_rename(long long oldp, long long newp, long long grant_src,
                     long long grant_dst) {
  MDK_CONFINE(oldp, grant_src, 1, 1);
  MDK_CONFINE(newp, grant_dst, 1, 1);
  const char *o = (const char *)oldp + 24;
  const char *n = (const char *)newp + 24;
  if (rename(o, n) == 0) return mdk_ok(1);  /* Ok () */
  return mdk_err(mdk_str_cstr(strerror(errno)));
}

/* removeDir : String -> Result String Unit — rmdir(2); empty dir only. */
long long mdk_remove_dir(long long path, long long grant) {
  MDK_CONFINE(path, grant, 1, 1);
  const char *p = (const char *)path + 24;
  if (rmdir(p) == 0) return mdk_ok(1);  /* Ok () */
  return mdk_err(mdk_str_cstr(strerror(errno)));
}

/* fsync : String -> Result String Unit — open(O_RDONLY)+fsync(2)+close.
 * O_RDONLY opens both a regular file and a directory, since the durability
 * of a rename is a property of the containing directory, not either file. */
long long mdk_fsync(long long path, long long grant) {
  MDK_CONFINE(path, grant, 0, 1);
  const char *p = (const char *)path + 24;
  int fd = open(p, O_RDONLY);
  if (fd < 0) return mdk_err(mdk_str_cstr(strerror(errno)));
  if (fsync(fd) != 0) {
    int saved_errno = errno;
    close(fd);
    return mdk_err(mdk_str_cstr(strerror(saved_errno)));
  }
  close(fd);
  return mdk_ok(1);  /* Ok () */
}

/* runCommand : String -> List String -> Result (Int, String, String) String.
 * Spawns prog with args, captures stdout+stderr via temp files.
 * Ok (exitCode, stdout, stderr) once the child ran; Err osError when mkstemp or
 * fork fails.  A program that cannot be executed is Ok (127, "", strerror).
 * Tuple cell layout: [header=TUPLE_TAG, tagged_exitcode, stdout_str, stderr_str].
 * TUPLE_TAG = hashName("$tuple") = djb2 of "$tuple" = 6950939912435. */
#define MDK_TUPLE_TAG 6950939912435LL

static long long mdk_read_temp(const char *path) {
  FILE *f = fopen(path, "rb");
  if (!f) return mdk_str_cstr("");
  fseek(f, 0, SEEK_END); long n = ftell(f); fseek(f, 0, SEEK_SET);
  char *buf = (char *)mdk_alloc((size_t)(n + 1));
  size_t got = fread(buf, 1, (size_t)n, f); fclose(f);
  return mdk_str_lossy(buf, (long long)got);
}

/* Convert a Medaka List String (linked Cons/Nil cells) into a NULL-terminated
 * C argv array.  The first slot is reserved for prog (filled by caller). */
static char **mdk_list_to_argv(long long list, int *argc_out) {
  /* Count elements first. */
  int n = 0; long long cur = list;
  while (!(cur & 1)) {  /* not an immediate (Nil is immediate) */
    long long tag = ((long long *)cur)[0];
    if (tag == MDK_TAG_CONS) { n++; cur = ((long long *)cur)[2]; } else break;
  }
  /* Allocate argv: prog + n args + NULL. */
  char **argv = (char **)malloc((size_t)(n + 2) * sizeof(char *));
  argv[0] = NULL; /* filled by caller */
  cur = list;
  for (int i = 0; i < n; i++) {
    long long cell = (long long)cur;
    long long str  = ((long long *)cell)[1];
    argv[i + 1] = (char *)str + 24;  /* UTF-8 bytes start at offset 24 */
    cur = ((long long *)cell)[2];
  }
  argv[n + 1] = NULL;
  if (argc_out) *argc_out = n + 1;
  return argv;
}

/* One spawned child of runCommand or runCommandBatch: its pid and the temp
 * files its stdout and stderr are captured to.  Capturing to files rather than
 * pipes means a child that writes a lot never blocks on a reader, so any
 * number of them can run at once without draining. */
typedef struct {
  pid_t pid;
  char out_path[sizeof "/tmp/mdk_cmd_out_XXXXXX"];
  char err_path[sizeof "/tmp/mdk_cmd_err_XXXXXX"];
} mdk_cmd_child;

/* Sets SIGCHLD to SIG_DFL, saving the previous disposition in *old.  Under an
 * inherited SIG_IGN (or SA_NOCLDWAIT) the kernel reaps children itself and
 * waitpid fails with ECHILD, so no exit status could be read back. */
static void mdk_cmd_sigchld_default(struct sigaction *old) {
  struct sigaction dfl;
  memset(&dfl, 0, sizeof dfl);
  dfl.sa_handler = SIG_DFL;
  sigemptyset(&dfl.sa_mask);
  sigaction(SIGCHLD, &dfl, old);
}

static void mdk_cmd_sigchld_restore(const struct sigaction *old) {
  sigaction(SIGCHLD, old, NULL);
}

/* Starts prog with the Medaka List String args, its stdout and stderr
 * redirected to fresh temp files.  Returns 0 once the child is running.
 * Otherwise stores in *err the Err value runCommand reports and returns
 * fork's errno, or -1 when mkstemp failed.  An exec failure is not reported
 * here: the child writes strerror to its captured stderr and exits 127, so it
 * reads back as an ordinary exit. */
static int mdk_cmd_start(const char *prog, long long args_w, mdk_cmd_child *c,
                         long long *err) {
  int argc = 0;
  char **argv = mdk_list_to_argv(args_w, &argc);
  argv[0] = (char *)prog;

  strcpy(c->out_path, "/tmp/mdk_cmd_out_XXXXXX");
  strcpy(c->err_path, "/tmp/mdk_cmd_err_XXXXXX");
  int out_fd = mkstemp(c->out_path);
  int err_fd = mkstemp(c->err_path);
  if (out_fd < 0 || err_fd < 0) {
    free(argv);
    if (out_fd >= 0) { close(out_fd); unlink(c->out_path); }
    if (err_fd >= 0) { close(err_fd); unlink(c->err_path); }
    *err = mdk_err(mdk_str_cstr("mkstemp failed"));
    return -1;
  }

  pid_t pid = fork();
  if (pid < 0) {
    int saved_errno = errno;
    close(out_fd); close(err_fd);
    unlink(c->out_path); unlink(c->err_path);
    free(argv);
    *err = mdk_err(mdk_str_cstr(strerror(saved_errno)));
    return saved_errno ? saved_errno : -1;
  }
  if (pid == 0) {
    dup2(out_fd, STDOUT_FILENO);
    dup2(err_fd, STDERR_FILENO);
    close(out_fd); close(err_fd);
    execvp(prog, argv);
    const char *msg = strerror(errno);
    write(STDERR_FILENO, msg, strlen(msg));
    _exit(127);
  }
  close(out_fd); close(err_fd);
  free(argv);
  c->pid = pid;
  return 0;
}

/* Reads back a reaped child's captured output, removes its temp files, and
 * boxes Ok (exitCode, stdout, stderr).  A child killed by a signal reports
 * 128 + the signal number, as a shell does. */
static long long mdk_cmd_finish(mdk_cmd_child *c, int wstatus) {
  int code = WIFEXITED(wstatus)   ? WEXITSTATUS(wstatus)
           : WIFSIGNALED(wstatus) ? 128 + WTERMSIG(wstatus) : 1;

  long long stdout_s = mdk_read_temp(c->out_path);
  long long stderr_s = mdk_read_temp(c->err_path);
  unlink(c->out_path); unlink(c->err_path);

  long long *tup = (long long *)mdk_alloc(4 * 8);
  tup[0] = MDK_TUPLE_TAG;
  tup[1] = ((long long)code << 1) | 1;  /* tagged int */
  tup[2] = stdout_s;
  tup[3] = stderr_s;
  return mdk_ok((long long)tup);
}

/* The Err for a started child whose status waitpid could not deliver, failing
 * with saved_errno; its temp files are removed. */
static long long mdk_cmd_wait_failed(mdk_cmd_child *c, int saved_errno) {
  unlink(c->out_path); unlink(c->err_path);
  char msg[160];
  snprintf(msg, sizeof msg, "waitpid failed: %s", strerror(saved_errno));
  return mdk_err(mdk_str_cstr(msg));
}

/* waitpid on one pid, retried on EINTR. */
static pid_t mdk_cmd_waitpid(pid_t pid, int *wstatus, int flags) {
  pid_t r;
  do { r = waitpid(pid, wstatus, flags); } while (r < 0 && errno == EINTR);
  return r;
}

long long mdk_run_command(long long prog_w, long long args_w) {
  struct sigaction old;
  mdk_cmd_sigchld_default(&old);
  mdk_cmd_child c;
  long long err = 0;
  if (mdk_cmd_start((const char *)prog_w + 24, args_w, &c, &err)) {
    mdk_cmd_sigchld_restore(&old);
    return err;
  }
  int wstatus = 0;
  pid_t r = mdk_cmd_waitpid(c.pid, &wstatus, 0);
  int saved_errno = errno;
  mdk_cmd_sigchld_restore(&old);
  if (r < 0) return mdk_cmd_wait_failed(&c, saved_errno);
  return mdk_cmd_finish(&c, wstatus);
}

/* runCommandBatch : String -> Int -> List (List String)
 *                     -> List (Result String (Int, String, String)).
 * Runs prog once per argv list, at most jobs children at a time (fewer than 1
 * runs them one at a time), and returns each row's runCommand result in input
 * order.  A row that cannot be started is that row's Err and the rest still
 * run; a fork that fails with EAGAIN while children of this batch are running
 * is retried once one of them finishes.  This returns only after every child
 * it started has been reaped.
 *
 * Children are reaped by pid with WNOHANG, never with waitpid(-1), so a child
 * this call did not start keeps its exit status for whoever waits on it. */
long long mdk_run_command_batch(long long prog_w, long long jobs_w,
                                long long argvs_w) {
  const char *prog = (const char *)prog_w + 24;
  long long jobs = jobs_w >> 1;  /* tagged int */
  if (jobs < 1) jobs = 1;

  long long n = 0;
  for (long long cur = argvs_w; cur != mdk_nil(); cur = ((long long *)cur)[2])
    n++;
  if (n == 0) return mdk_nil();

  /* Rows and results hold heap values, so they live in memory the collector
   * scans; the child table holds none.  kids[k].pid is nonzero exactly while
   * row k's child is running and unreaped. */
  long long *rows = (long long *)mdk_alloc(n * 8);
  long long *res = (long long *)mdk_alloc(n * 8);
  mdk_cmd_child *kids = (mdk_cmd_child *)malloc((size_t)n * sizeof *kids);
  long long i = 0;
  for (long long cur = argvs_w; cur != mdk_nil(); cur = ((long long *)cur)[2])
    rows[i++] = ((long long *)cur)[1];

  struct sigaction old;
  mdk_cmd_sigchld_default(&old);

  long long next = 0, running = 0;
  while (next < n || running > 0) {
    while (running < jobs && next < n) {
      long long err = 0;
      int failed = mdk_cmd_start(prog, rows[next], &kids[next], &err);
      if (failed == EAGAIN && running > 0) break;
      if (failed) {
        kids[next].pid = 0;
        res[next] = err;
      } else {
        running++;
      }
      next++;
    }
    if (running == 0) continue;

    /* Sweep the running children until at least one has finished, backing
     * off from 0.1 ms to about 10 ms between sweeps. */
    long sleep_ns = 100000;
    for (;;) {
      long long settled = 0;
      for (long long k = 0; k < next; k++) {
        if (kids[k].pid == 0) continue;
        int wstatus = 0;
        pid_t r = mdk_cmd_waitpid(kids[k].pid, &wstatus, WNOHANG);
        if (r == 0) continue;
        res[k] = r < 0 ? mdk_cmd_wait_failed(&kids[k], errno)
                       : mdk_cmd_finish(&kids[k], wstatus);
        kids[k].pid = 0;
        running--;
        settled++;
      }
      if (settled > 0) break;
      struct timespec ts = { 0, sleep_ns };
      nanosleep(&ts, NULL);
      if (sleep_ns < 10000000) sleep_ns *= 2;
    }
  }

  mdk_cmd_sigchld_restore(&old);
  free(kids);

  long long acc = mdk_nil();
  for (long long k = n - 1; k >= 0; k--) acc = mdk_cons(res[k], acc);
  return acc;
}

/* executablePath : Unit -> String — absolute path of the running executable,
 * used to derive an exe-relative default MEDAKA_ROOT for a relocated binary
 * (DISTRIBUTION-DESIGN.md D1).  Linux: readlink /proc/self/exe.  macOS:
 * _NSGetExecutablePath (may itself be a relative path or contain symlinks) —
 * realpath(3) resolves both platforms' raw path to a canonical absolute form,
 * mirroring mdk_canonicalize_path's fallback-to-raw-on-failure shape. */
long long mdk_executable_path(long long unit_ignored) {
  (void)unit_ignored;
  char buf[PATH_MAX];
#ifdef __APPLE__
  uint32_t size = sizeof(buf);
  if (_NSGetExecutablePath(buf, &size) != 0) return mdk_str_cstr("");
#else
  ssize_t n = readlink("/proc/self/exe", buf, sizeof(buf) - 1);
  if (n < 0) return mdk_str_cstr("");
  buf[n] = '\0';
#endif
  char resolved[PATH_MAX];
  if (realpath(buf, resolved) != 0) return mdk_str_cstr(resolved);
  return mdk_str_cstr(buf);
}

/* BUILD PROVENANCE: three stamps this file READS and never itself defines.
 *
 * buildFingerprint : Unit -> String is the compiler-source fingerprint THIS
 * binary was built from (find compiler -name '*.mdk' | sort | hash
 * names+contents); buildCommit / buildDate are its siblings (issue #74 W8).
 * All three default to "" here, weakly, and test/build_native_medaka.sh
 * overrides them for ./medaka by linking one generated object that defines them
 * strongly. The driver reads "" as "skip the check" (issue #89), which is what
 * every path that links no such object gets: the cold seed bootstrap, the
 * emitter, oracle builds, `medaka build`, a shipped or relocated binary.
 *
 * WEAK GLOBALS AND A SEPARATE TRANSLATION UNIT, never a -D on this file, because
 * the value changes on every compiler edit and this file is inside the ThinLTO
 * unit: a value baked in here moves the runtime's summary hash, which sits in the
 * cache key of every partition that imports from the runtime, i.e. all of them.
 * Measured, same partitions and same one-module edit, varying only the
 * fingerprint: unchanged 4s and 5 of 73 cache entries written; changed 23s and
 * all 73. Compiling this file outside the LTO unit instead would also fix the
 * cache and cost ~7.7% of interpreter runtime. Weak-vs-strong is resolved by the
 * linker before LTO runs — the bitcode symbol is marked preempted, so LTO cannot
 * fold the "" away. Measured with lld; taken on faith for Apple's ld, which
 * documents the same precedence but was never run (no Darwin box), so a `medaka
 * --version` with no commit on macOS is the symptom to look for.
 *
 * These are ARRAYS, not pointers, and the strong definitions may be longer: a
 * string object takes its defining TU's size, which is the ordinary C spelling
 * for this and keeps the read a single load with no indirection. */
__attribute__((weak)) const char mdk_build_fingerprint_str[] = "";
__attribute__((weak)) const char mdk_build_commit_str[] = "";
__attribute__((weak)) const char mdk_build_date_str[] = "";

long long mdk_build_fingerprint(long long unit_ignored) {
  (void)unit_ignored;
  return mdk_str_cstr(mdk_build_fingerprint_str);
}

long long mdk_build_commit(long long unit_ignored) {
  (void)unit_ignored;
  return mdk_str_cstr(mdk_build_commit_str);
}

long long mdk_build_date(long long unit_ignored) {
  (void)unit_ignored;
  return mdk_str_cstr(mdk_build_date_str);
}

/* statFile : String -> Result String (Int, Bool, Bool, Float).
 * stat(2) the path; Ok (sizeBytes, isDir, isFile, mtimeSeconds) or Err strerror.
 * 4-tuple cell layout mirrors mdk_run_command's 3-tuple: [TUPLE_TAG, e0..e3].
 * Bool uses the native tagged encoding (True=3, False=1); Float is boxed. */
long long mdk_stat_file(long long path, long long grant) {
  MDK_CONFINE(path, grant, 0, 0);
  const char *p = (const char *)path + 24;
  struct stat st;
  if (stat(p, &st) != 0) return mdk_err(mdk_str_cstr(strerror(errno)));
  long long *tup = (long long *)mdk_alloc(5 * 8);
  tup[0] = MDK_TUPLE_TAG;
  tup[1] = (((long long)st.st_size) << 1) | 1;   /* tagged Int size */
  tup[2] = S_ISDIR(st.st_mode) ? 3 : 1;          /* Bool isDir */
  tup[3] = S_ISREG(st.st_mode) ? 3 : 1;          /* Bool isFile */
  tup[4] = mdk_box_float((double)st.st_mtime);   /* Float mtimeSeconds */
  return mdk_ok((long long)tup);
}

/* stdin readers — implemented, NOT fixtured (gate doesn't pipe stdin). */

/* readLine : Unit -> String — one line, newline stripped. */
long long mdk_read_line(long long u) {
  (void)u;
  char *line = 0; size_t cap = 0; ssize_t n = getline(&line, &cap, stdin);
  if (n < 0) { free(line); return mdk_str_cstr(""); }
  if (n > 0 && line[n-1] == '\n') n--;
  long long r = mdk_str_lossy(line, (long long)n); free(line); return r;
}

/* readLineOpt : Unit -> Option String — Some line / None at EOF. */
long long mdk_read_line_opt(long long u) {
  (void)u;
  char *line = 0; size_t cap = 0; ssize_t n = getline(&line, &cap, stdin);
  if (n < 0) { free(line); return mdk_none(); }
  if (n > 0 && line[n-1] == '\n') n--;
  long long r = mdk_some(mdk_str_lossy(line, (long long)n)); free(line); return r;
}

/* readExactly : Int -> Option String — read exactly N bytes; None at EOF or short read. */
long long mdk_read_exactly(long long n_tagged) {
  long long n = n_tagged >> 1;  /* untag Int */
  if (n <= 0) return mdk_some(mdk_str_lit("", 0));
  char *buf = (char *)malloc((size_t)n);
  size_t total = 0;
  while (total < (size_t)n) {
    size_t got = fread(buf + total, 1, (size_t)n - total, stdin);
    if (got == 0) break;
    total += got;
  }
  if (total == 0) { free(buf); return mdk_none(); }
  if ((long long)total < n) { free(buf); return mdk_none(); }
  long long r = mdk_some(mdk_str_lossy(buf, (long long)total)); free(buf); return r;
}

/* readAll : Unit -> String — all of stdin. */
long long mdk_read_all(long long u) {
  (void)u;
  size_t cap = 4096, len = 0; char *buf = (char *)malloc(cap);
  for (;;) {
    if (len == cap) { cap *= 2; buf = (char *)realloc(buf, cap); }
    size_t got = fread(buf + len, 1, cap - len, stdin); len += got;
    if (got == 0) break;
  }
  long long r = mdk_str_lossy(buf, (long long)len); free(buf); return r;
}

/* ── RNG — deterministic SplitMix64 (native extern catalog, Tier D) ───────────
 * The SAME algorithm runs in the tree-walker oracle (lib/eval.ml splitmix64_next),
 * seeded identically, so random* output is byte-identical per seed and stable
 * across backends (project decision 2026-06-07). State is a uint64; default 0;
 * mdk_set_seed sets it. Range semantics preserved from the old oracle: randomInt
 * INCLUSIVE [lo,hi]; randomFloat in [-1,1); randomChar ASCII [32,126]. */
static unsigned long long mdk_rng_state = 0;

static unsigned long long mdk_next_u64(void) {
  mdk_rng_state += 0x9E3779B97F4A7C15ULL;
  unsigned long long z = mdk_rng_state;
  z = (z ^ (z >> 30)) * 0xBF58476D1CE4E5B9ULL;
  z = (z ^ (z >> 27)) * 0x94D049BB133111EBULL;
  return z ^ (z >> 31);
}

void mdk_set_seed(long long tagged) {        /* setSeed : Int -> Unit */
  mdk_rng_state = (unsigned long long)(tagged >> 1);
}
long long mdk_random_state(long long unit) {
  (void)unit;
  return mdk_box_u64(mdk_rng_state);
}
void mdk_restore_random_state(long long state) {
  mdk_rng_state = mdk_u64_payload(state);
}
/* randomInt : Int -> Int -> Int (INCLUSIVE).  Returns a RAW int — the emitter tags it. */
/* The span hi - lo + 1 is computed unsigned: for the full Int range it is
   2^63, which a signed subtraction overflows (#3451).  lo > hi answers lo; every
   span up to 2^63 draws.  The interpreter's pRandomInt is the same rule. */
long long mdk_random_int(long long lo_t, long long hi_t) {
  long long lo = lo_t >> 1, hi = hi_t >> 1;
  if (hi < lo) return lo;
  unsigned long long span = (unsigned long long)hi - (unsigned long long)lo + 1ULL;
  return (long long)((unsigned long long)lo + mdk_next_u64() % span);
}
long long mdk_random_bool(long long u) { (void)u;  /* RAW 0/1 — emitter tags to Bool */
  return (long long)(mdk_next_u64() & 1ULL);
}
long long mdk_random_float(long long u) { (void)u;  /* boxed Float word */
  unsigned long long bits = mdk_next_u64() >> 11;
  return mdk_box_float((double)bits * (1.0 / 9007199254740992.0) * 2.0 - 1.0);
}
long long mdk_random_char(long long u) { (void)u;  /* RAW codepoint — emitter tags to Char */
  return 32 + (long long)(mdk_next_u64() % 95ULL);
}

/* osEntropyBytes : Int -> <Rand> Array Int.
 * getentropy(3) is provided by both supported hosts (glibc/Linux and Darwin)
 * and caps each request at 256 bytes. Fill in bounded chunks and expose each
 * byte as a tagged Medaka Int. There is deliberately no SplitMix fallback:
 * unavailable OS entropy is a loud failure, never predictable key material. */
long long mdk_os_entropy_bytes(long long n_tagged) {
  long long n = n_tagged >> 1;
  if (n < 0)
    mdk_panic(mdk_str_cstr("osEntropyBytes: length must be non-negative"));
  if (n > (LLONG_MAX / 8) - 1)
    mdk_panic(mdk_str_cstr("osEntropyBytes: requested length is too large"));

  long long *cell = (long long *)mdk_alloc(8 * (n + 1));
  cell[0] = n;
  unsigned char chunk[256];
  long long off = 0;
  while (off < n) {
    size_t want = (size_t)((n - off) > 256 ? 256 : (n - off));
    if (getentropy(chunk, want) != 0)
      mdk_panic(mdk_str_cstr("osEntropyBytes: operating system entropy source failed"));
    for (size_t i = 0; i < want; i++)
      cell[off + (long long)i + 1] = (((long long)chunk[i]) << 1) | 1;
    off += (long long)want;
  }
  return (long long)cell;
}

/* ── Hashable per-type hashers — SPECIFIED, byte-identical to lib/eval.ml ──────
 * The old structural `__hashRaw` (OCaml Hashtbl.hash) can't run here: this runtime
 * is type-erased, so one i64 word can't tell a tagged Int from a String pointer
 * and so can't content-hash a boxed value (equal Strings would pointer-hash
 * differently → hash_map String keys break).  Fix (the RNG playbook): each typed
 * `Hashable` impl calls one of these, specified IDENTICALLY here and in
 * lib/eval.ml (hash_*), so the hash is byte-identical across backends.  All math
 * is uint64 + masked to [0, 2^30) — NON-NEGATIVE (hash_map does `hash % cap`).
 * Each helper takes the NATIVE arg the emitter unpacks (untagged int / codepoint /
 * String cell pointer / double) and returns a RAW int the emitter tags. */
#define MDK_HASH_MASK 0x3FFFFFFFULL   /* 2^30 - 1 */

/* SplitMix64 finalizer, as a pure mixer.  == hash_mix64 (OCaml). */
static unsigned long long mdk_hash_mix64(unsigned long long x) {
  unsigned long long z = x + 0x9E3779B97F4A7C15ULL;
  z = (z ^ (z >> 30)) * 0xBF58476D1CE4E5B9ULL;
  z = (z ^ (z >> 27)) * 0x94D049BB133111EBULL;
  return z ^ (z >> 31);
}
/* hashInt : Int -> Int.  `n` is the UNTAGGED int (emitter untags). */
long long mdk_hash_int(long long n) {
  return (long long)(mdk_hash_mix64((unsigned long long)n) & MDK_HASH_MASK);
}
/* hashChar : Char -> Int.  `cp` is the UNTAGGED codepoint — same mix as hashInt. */
long long mdk_hash_char(long long cp) {
  return (long long)(mdk_hash_mix64((unsigned long long)cp) & MDK_HASH_MASK);
}
/* hashBool : Bool -> Int.  `b` is 0/1 (already non-negative). */
long long mdk_hash_bool(long long b) { return b ? 1 : 0; }
/* hashFloat : Float -> Int.  `d` is the unboxed double; normalise then mix.
 * #758: -0.0 and +0.0 are `Eq`, so they MUST hash alike — collapse both to
 * +0.0's bits.  Every NaN (any sign/payload) is canonicalised to one qNaN bit
 * pattern so all NaNs share a bucket.  Mirrors pHashFloat (eval) and
 * $mdk_hash_float (wasm) exactly, or run != build reappears. */
long long mdk_hash_float(double d) {
  unsigned long long bits;
  if (d == 0.0) {              /* +0.0 and -0.0 */
    bits = 0ULL;
  } else if (d != d) {         /* NaN, any sign/payload */
    bits = 0x7FF8000000000000ULL;
  } else {
    memcpy(&bits, &d, 8);
  }
  return (long long)(mdk_hash_mix64(bits) & MDK_HASH_MASK);
}
/* hashString : String -> Int.  FNV-1a over the cell's raw UTF-8 bytes (byte_len@8,
 * bytes@24).  offset basis 0xCBF29CE484222325, prime 0x100000001B3. */
long long mdk_hash_string(long long w) {
  const char *cell = (const char *)w;
  long long byte_len = ((const long long *)cell)[1];
  const unsigned char *bytes = (const unsigned char *)(cell + 24);
  unsigned long long h = 0xCBF29CE484222325ULL;
  for (long long i = 0; i < byte_len; i++)
    h = (h ^ (unsigned long long)bytes[i]) * 0x100000001B3ULL;
  return (long long)(h & MDK_HASH_MASK);
}

/* intBitsToFloat : Int -> Float.  Reinterpret the 64-bit pattern of the
 * (untagged) Medaka Int `n` as an IEEE 754 double and return a boxed Float.
 * The emitter calls untagInt before passing `n`, so `n` is the raw value. */
long long mdk_int_bits_to_float(long long n) {
  double d; memcpy(&d, &n, 8);
  return mdk_box_float(d);
}
/* bytesToFloat64 : Array Int -> Int -> Float.  Read 8 bytes big-endian from
 * a Medaka Array-of-Int cell starting at element index `off`.
 * Array cell layout: [i64 count | i64 elem0 | i64 elem1 | ...].
 * Each element is a TAGGED Medaka Int (value * 2 + 1); untag by >> 1.
 * `off` is also a tagged int passed from the emitter (untagged before call).
 * Returns a boxed Float. */
long long mdk_bytes_to_float64(long long arr_word, long long off) {
  const long long *a = (const long long *)arr_word;
  /* a[0] = count (raw, untagged); `off` is already untagged (emitter untags it).
   * Reads 8 elements a[1+off+0..7]; bounds-check to prevent an OOB heap read. */
  if (off < 0 || off + 8 > a[0]) mdk_oob();
  /* a[0] = count; a[1+i] = element i (TAGGED: raw >> 1 to get byte value) */
  unsigned long long bits =
    ((unsigned long long)((a[1 + off + 0] >> 1) & 0xFF) << 56) |
    ((unsigned long long)((a[1 + off + 1] >> 1) & 0xFF) << 48) |
    ((unsigned long long)((a[1 + off + 2] >> 1) & 0xFF) << 40) |
    ((unsigned long long)((a[1 + off + 3] >> 1) & 0xFF) << 32) |
    ((unsigned long long)((a[1 + off + 4] >> 1) & 0xFF) << 24) |
    ((unsigned long long)((a[1 + off + 5] >> 1) & 0xFF) << 16) |
    ((unsigned long long)((a[1 + off + 6] >> 1) & 0xFF) <<  8) |
    ((unsigned long long)((a[1 + off + 7] >> 1) & 0xFF)      );
  double d; memcpy(&d, &bits, 8);
  return mdk_box_float(d);
}

/* floatToBytes64 : Float -> Array Int.  Encode `d` as 8 big-endian IEEE 754
 * bytes and return a Medaka Array of 8 tagged Ints (each 0..255).
 * The emitter calls unboxFloat before passing, so `d` arrives as a raw double.
 * Array cell layout: [i64 count=8 | tagged_byte0 | ... | tagged_byte7].
 * Tagged Int encoding: (byte << 1) | 1 (same as all Medaka Int immediates). */
long long mdk_float_to_bytes64(double d) {
  unsigned long long bits;
  memcpy(&bits, &d, 8);
  long long *cell = (long long *)mdk_alloc(8 * 9);  /* 9 words: count + 8 elems */
  cell[0] = 8;  /* count (raw, untagged) */
  for (long long i = 0; i < 8; i++) {
    unsigned char b = (unsigned char)((bits >> (8 * (7 - i))) & 0xFF);
    cell[i + 1] = ((long long)b << 1) | 1;  /* tag as Medaka Int */
  }
  return (long long)cell;
}

/* ── debug literal externs — quoted/escaped rendering, byte-exact, no oracle ───
 * Mirror escape_string_lit / escape_char_lit in lib/eval.ml (the same escapes the
 * lexer's read_string/read_char understand), so `debug` of a String/Char round-
 * trips to valid source.  Output is boxed via mdk_str_lit. */

/* Append the escaped form of one byte to buf[*off], advancing *off. */
static void mdk_escape_byte(char *buf, long long *off, unsigned char c, char quote) {
  switch (c) {
    case '\\': buf[(*off)++]='\\'; buf[(*off)++]='\\'; break;
    case '\n': buf[(*off)++]='\\'; buf[(*off)++]='n';  break;
    case '\t': buf[(*off)++]='\\'; buf[(*off)++]='t';  break;
    case '\r': buf[(*off)++]='\\'; buf[(*off)++]='r';  break;
    case '\0': buf[(*off)++]='\\'; buf[(*off)++]='0';  break;
    default:
      if (c == (unsigned char)quote) { buf[(*off)++]='\\'; buf[(*off)++]=(char)c; }
      else buf[(*off)++]=(char)c;
  }
}
/* debugStringLit : String -> String  ->  "\"" + escape(bytes) + "\"" */
long long mdk_debug_string_lit(long long w) {
  const char *cell = (const char *)w;
  long long byte_len = ((const long long *)cell)[1];
  const unsigned char *bytes = (const unsigned char *)(cell + 24);
  char *buf = (char *)mdk_alloc(2 + 2 * byte_len + 1);  /* worst case 2 bytes/char */
  long long off = 0;
  buf[off++] = '"';
  for (long long i = 0; i < byte_len; i++) mdk_escape_byte(buf, &off, bytes[i], '"');
  buf[off++] = '"';
  return mdk_str_lit(buf, off);
}
/* debugCharLit : Char -> String  ->  "'" + escape(codepoint) + "'".  `cp` UNTAGGED.
 * Escape the control bytes like escape_char_lit; otherwise UTF-8-encode the cp. */
long long mdk_debug_char_lit(long long cp) {
  char enc[4]; int n = mdk_utf8_encode(cp, enc);
  char buf[16]; long long off = 0;
  buf[off++] = '\'';
  if (n == 1) mdk_escape_byte(buf, &off, (unsigned char)enc[0], '\'');
  else for (int i = 0; i < n; i++) buf[off++] = enc[i];
  buf[off++] = '\'';
  return mdk_str_lit(buf, off);
}

/* ── perf / instrumentation externs ────────────────────────────────────────────
 * wallTimeSec : Unit -> <IO> Float   — wall-clock seconds (gettimeofday).
 * allocBytes  : Unit -> <IO> Float   — total GC-heap bytes allocated since start.
 * Both return a boxed Float word (mdk_box_float), identical ABI to randomFloat. */

long long mdk_wall_time_sec(long long u) { (void)u;
  struct timeval tv;
  gettimeofday(&tv, NULL);
  return mdk_box_float((double)tv.tv_sec + (double)tv.tv_usec * 1e-6);
}

long long mdk_alloc_bytes(long long u) { (void)u;
  return mdk_box_float((double)GC_get_total_bytes());
}

/* monotonicSec : Unit -> <Clock> Float — monotonic clock seconds (immune to
 * wall-clock adjustment).  clock_gettime(CLOCK_MONOTONIC) is POSIX and available
 * on macOS.  Boxed Float, same ABI as wallTimeSec. */
long long mdk_monotonic_sec(long long u) { (void)u;
  struct timespec ts;
  clock_gettime(CLOCK_MONOTONIC, &ts);
  return mdk_box_float((double)ts.tv_sec + (double)ts.tv_nsec * 1e-9);
}

/* sleepMs : Int -> <Clock> Unit — sleep N milliseconds via nanosleep.  `ms_t` is
 * the TAGGED Int (>>1 to untag), mirroring mdk_set_seed's ABI.  Returns nothing. */
void mdk_sleep_ms(long long ms_t) {
  long long ms = ms_t >> 1;
  if (ms <= 0) return;
  struct timespec req;
  req.tv_sec = ms / 1000;
  req.tv_nsec = (ms % 1000) * 1000000L;
  nanosleep(&req, NULL);
}

/* ── Networking (NET-DESIGN.md) ──────────────────────────────────────────────
 * Thin blocking BSD-socket shims mirroring the file-extern ABI: String args at
 * ptr+24, tagged Int args (>>1 to untag), Result via mdk_ok/mdk_err, errno mapped
 * through strerror.  fds traffic as tagged Int ((fd<<1)|1) exactly like every Int.
 * Native-only; the wasm backend rejects the whole net set. */

#define MDK_NET_UNTAG(x) ((int)((long long)(x) >> 1))
#define MDK_NET_TAG(v)   ((((long long)(v)) << 1) | 1)

/* Belt-and-suspenders SIGPIPE guard (F7): ignore process-wide so a write to a
 * closed peer surfaces as EPIPE (a Result Err) instead of killing the process.
 * Per-socket SO_NOSIGPIPE / per-send MSG_NOSIGNAL below add the platform-specific
 * belt.  Runs before main via the constructor attribute. */
__attribute__((constructor)) static void mdk_net_sigpipe_init(void) {
  signal(SIGPIPE, SIG_IGN);
}

/* netResolve : String -> Result String (List String) — getaddrinfo -> numeric IPs. */
long long mdk_net_resolve(long long host_cell) {
  const char *host = (const char *)host_cell + 24;
  struct addrinfo hints = {0}, *res, *ai;
  hints.ai_family = AF_UNSPEC;
  hints.ai_socktype = SOCK_STREAM;
  int gai = getaddrinfo(host, NULL, &hints, &res);
  if (gai != 0) return mdk_err(mdk_str_cstr(gai_strerror(gai)));
  long long acc = mdk_nil();
  char buf[INET6_ADDRSTRLEN];
  for (ai = res; ai; ai = ai->ai_next) {
    const char *s = NULL;
    if (ai->ai_family == AF_INET)
      s = inet_ntop(AF_INET, &((struct sockaddr_in *)ai->ai_addr)->sin_addr, buf, sizeof buf);
    else if (ai->ai_family == AF_INET6)
      s = inet_ntop(AF_INET6, &((struct sockaddr_in6 *)ai->ai_addr)->sin6_addr, buf, sizeof buf);
    if (s) acc = mdk_cons(mdk_str_cstr(s), acc);
  }
  freeaddrinfo(res);
  return mdk_ok(acc);
}

/* netTcpConnect : host -> port -> Result String Int (connected fd). */
long long mdk_net_tcp_connect(long long host_cell, long long port_tagged) {
  const char *host = (const char *)host_cell + 24;
  char port[16]; snprintf(port, sizeof port, "%d", MDK_NET_UNTAG(port_tagged));
  struct addrinfo hints = {0}, *res, *ai;
  hints.ai_family = AF_UNSPEC;
  hints.ai_socktype = SOCK_STREAM;
  int gai = getaddrinfo(host, port, &hints, &res);
  if (gai != 0) return mdk_err(mdk_str_cstr(gai_strerror(gai)));
  int fd = -1, last = 0;
  for (ai = res; ai; ai = ai->ai_next) {
    fd = socket(ai->ai_family, ai->ai_socktype, ai->ai_protocol);
    if (fd < 0) { last = errno; continue; }
    if (connect(fd, ai->ai_addr, ai->ai_addrlen) == 0) break;
    last = errno; close(fd); fd = -1;
  }
  freeaddrinfo(res);
  if (fd < 0) return mdk_err(mdk_str_cstr(strerror(last)));
#ifdef SO_NOSIGPIPE
  { int on = 1; setsockopt(fd, SOL_SOCKET, SO_NOSIGPIPE, &on, sizeof on); }
#endif
  return mdk_ok(MDK_NET_TAG(fd));
}

/* netTcpListen : bindAddr -> port (0=ephemeral) -> Result String Int (listening fd). */
long long mdk_net_tcp_listen(long long addr_cell, long long port_tagged) {
  const char *addr = (const char *)addr_cell + 24;
  char port[16]; snprintf(port, sizeof port, "%d", MDK_NET_UNTAG(port_tagged));
  struct addrinfo hints = {0}, *res;
  hints.ai_family = AF_UNSPEC; hints.ai_socktype = SOCK_STREAM; hints.ai_flags = AI_PASSIVE;
  int gai = getaddrinfo(addr[0] ? addr : NULL, port, &hints, &res);
  if (gai != 0) return mdk_err(mdk_str_cstr(gai_strerror(gai)));
  int fd = socket(res->ai_family, res->ai_socktype, res->ai_protocol);
  if (fd < 0) { int e = errno; freeaddrinfo(res); return mdk_err(mdk_str_cstr(strerror(e))); }
  { int on = 1; setsockopt(fd, SOL_SOCKET, SO_REUSEADDR, &on, sizeof on); }
  if (bind(fd, res->ai_addr, res->ai_addrlen) != 0 || listen(fd, 128) != 0) {
    int e = errno; close(fd); freeaddrinfo(res); return mdk_err(mdk_str_cstr(strerror(e)));
  }
  freeaddrinfo(res);
  return mdk_ok(MDK_NET_TAG(fd));
}

/* netListenPort : fd -> Result String Int (actual bound port; for port-0 ephemeral). */
long long mdk_net_listen_port(long long fd_tagged) {
  struct sockaddr_storage ss; socklen_t len = sizeof ss;
  if (getsockname(MDK_NET_UNTAG(fd_tagged), (struct sockaddr *)&ss, &len) != 0)
    return mdk_err(mdk_str_cstr(strerror(errno)));
  int port = (ss.ss_family == AF_INET6)
    ? ntohs(((struct sockaddr_in6 *)&ss)->sin6_port)
    : ntohs(((struct sockaddr_in  *)&ss)->sin_port);
  return mdk_ok(MDK_NET_TAG(port));
}

/* netTcpAccept : listening fd -> Result String Int (accepted connection fd; blocks). */
long long mdk_net_tcp_accept(long long lis_tagged) {
  int c = accept(MDK_NET_UNTAG(lis_tagged), NULL, NULL);
  if (c < 0) return mdk_err(mdk_str_cstr(strerror(errno)));
#ifdef SO_NOSIGPIPE
  { int on = 1; setsockopt(c, SOL_SOCKET, SO_NOSIGPIPE, &on, sizeof on); }
#endif
  return mdk_ok(MDK_NET_TAG(c));
}

/* netSend : fd -> Array Int -> Result String Int (count written).
 * Array cell = [len (raw), tagged byte...]; untag each byte to 0..255. */
long long mdk_net_send(long long fd_tagged, long long arr) {
  const long long *a = (const long long *)arr;
  long long n = a[0];
  unsigned char *buf = (unsigned char *)mdk_alloc(n ? n : 1);
  for (long long i = 0; i < n; i++) buf[i] = (unsigned char)((a[i + 1] >> 1) & 0xFF);
  int flags = 0;
#ifdef MSG_NOSIGNAL
  flags = MSG_NOSIGNAL;
#endif
  ssize_t w = send(MDK_NET_UNTAG(fd_tagged), buf, (size_t)n, flags);
  if (w < 0) return mdk_err(mdk_str_cstr(strerror(errno)));
  return mdk_ok(MDK_NET_TAG((long long)w));
}

/* netSendFrom : fd -> Array Int -> offset -> Result String Int.
 * Blocking netSend from a clamped offset, copying at most one chunk per call. */
#define MDK_SEND_CHUNK 65536
long long mdk_net_send_from(long long fd_tagged, long long arr, long long off_tagged) {
  const long long *a = (const long long *)arr;
  long long len = a[0];
  long long off = off_tagged >> 1;
  if (off < 0) off = 0;
  if (off > len) off = len;
  long long n = len - off;
  if (n > MDK_SEND_CHUNK) n = MDK_SEND_CHUNK;
  unsigned char *buf = (unsigned char *)mdk_alloc(n ? n : 1);
  for (long long i = 0; i < n; i++) buf[i] = (unsigned char)((a[off + i + 1] >> 1) & 0xFF);
  int flags = 0;
#ifdef MSG_NOSIGNAL
  flags = MSG_NOSIGNAL;
#endif
  ssize_t w = send(MDK_NET_UNTAG(fd_tagged), buf, (size_t)n, flags);
  if (w < 0) return mdk_err(mdk_str_cstr(strerror(errno)));
  return mdk_ok(MDK_NET_TAG((long long)w));
}

/* netRecv : fd -> maxBytes -> Result String (Array Int).  Empty Array = EOF/peer-closed.
 * Array cell = [len (raw), tagged byte...] matching mdk_read_file_bytes. */
long long mdk_net_recv(long long fd_tagged, long long max_tagged) {
  long long max = max_tagged >> 1;
  unsigned char *buf = (unsigned char *)mdk_alloc(max > 0 ? max : 1);
  ssize_t r = recv(MDK_NET_UNTAG(fd_tagged), buf, (size_t)(max > 0 ? max : 0), 0);
  if (r < 0) return mdk_err(mdk_str_cstr(strerror(errno)));
  long long *cell = (long long *)mdk_alloc(8 * (r + 1));
  cell[0] = (long long)r;
  for (ssize_t i = 0; i < r; i++) cell[i + 1] = (((long long)buf[i]) << 1) | 1;
  return mdk_ok((long long)cell);
}

/* netShutdown : fd -> how (0=read,1=write,2=both) -> Result String Unit. */
long long mdk_net_shutdown(long long fd_tagged, long long how_tagged) {
  int how = MDK_NET_UNTAG(how_tagged);
  int sw = how == 0 ? SHUT_RD : (how == 1 ? SHUT_WR : SHUT_RDWR);
  if (shutdown(MDK_NET_UNTAG(fd_tagged), sw) != 0 && errno != ENOTCONN)
    return mdk_err(mdk_str_cstr(strerror(errno)));
  return mdk_ok(1);  /* Ok () */
}

/* netClose : fd -> Result String Unit — close(2); idempotent-safe. */
long long mdk_net_close(long long fd_tagged) {
  int fd = MDK_NET_UNTAG(fd_tagged);
  if (fd < 0) return mdk_ok(1);
  if (close(fd) != 0 && errno != EBADF) return mdk_err(mdk_str_cstr(strerror(errno)));
  return mdk_ok(1);  /* Ok () */
}

/* netSetTimeout : fd -> milliseconds (0=blocking) -> Result String Unit.
 * Installs SO_RCVTIMEO + SO_SNDTIMEO so a hung peer surfaces as a Result Err. */
long long mdk_net_set_timeout(long long fd_tagged, long long ms_tagged) {
  long long ms = ms_tagged >> 1;
  int fd = MDK_NET_UNTAG(fd_tagged);
  struct timeval tv;
  tv.tv_sec = ms / 1000;
  tv.tv_usec = (ms % 1000) * 1000;
  if (setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof tv) != 0)
    return mdk_err(mdk_str_cstr(strerror(errno)));
  if (setsockopt(fd, SOL_SOCKET, SO_SNDTIMEO, &tv, sizeof tv) != 0)
    return mdk_err(mdk_str_cstr(strerror(errno)));
  return mdk_ok(1);  /* Ok () */
}

/* ── Readiness shims for the async runtime (ASYNC-RUNTIME-DESIGN.md §4.2) ─────
 * The scheduler in stdlib/async.mdk parks a task on a descriptor and makes ONE
 * poll(2) call when nothing is runnable.  These shims are exactly the syscalls
 * Medaka cannot make itself: poll, O_NONBLOCK, and would-block-aware
 * accept/recv/send.  Would-block is `Ok None`; `Ok (Some x)` carries the same
 * payload the blocking sibling returns; `Err` is real errno text.  All buffers
 * are GC-allocated like the blocking shims above.  POSIX only, so one code
 * path serves Linux and macOS. */

/* Opt-in SIGTERM readiness for pdsd. The handler may run on any thread; it
 * writes only to a nonblocking pipe and sets a sig_atomic_t. No allocator,
 * Medaka callback, or scheduler operation runs in signal context. The byte is
 * only a wakeup: the flag is the durable observation if writes coalesce or
 * the pipe is full. Install before publishing readiness. Other executables
 * retain POSIX's default SIGTERM disposition unless they call this extern. */
static volatile sig_atomic_t mdk_pds_term_seen = 0;
static int mdk_pds_term_write_fd = -1;
static int mdk_pds_term_read_fd = -1;

static void mdk_pds_term_handler(int signum) {
  (void)signum;
  int saved = errno;
  mdk_pds_term_seen = 1;
  unsigned char byte = 1;
  if (mdk_pds_term_write_fd >= 0)
    (void)write(mdk_pds_term_write_fd, &byte, 1);
  errno = saved;
}

/* pdsSignalStart : Unit -> Result String Int; called once after binding.
 * Both ends are nonblocking and close-on-exec; a failed setup leaves the
 * process's prior SIGTERM disposition untouched. */
long long mdk_pds_signal_start(long long unit) {
  (void)unit;
  if (mdk_pds_term_read_fd >= 0)
    return mdk_err(mdk_str_cstr("pdsSignalStart: already installed"));
  int ends[2];
  if (pipe(ends) != 0) return mdk_err(mdk_str_cstr(strerror(errno)));
  for (int i = 0; i < 2; i++) {
    int flags = fcntl(ends[i], F_GETFL, 0);
    int fdflags = fcntl(ends[i], F_GETFD, 0);
    if (flags < 0 || fdflags < 0 ||
        fcntl(ends[i], F_SETFL, flags | O_NONBLOCK) != 0 ||
        fcntl(ends[i], F_SETFD, fdflags | FD_CLOEXEC) != 0) {
      int err = errno;
      close(ends[0]); close(ends[1]);
      return mdk_err(mdk_str_cstr(strerror(err)));
    }
  }
  struct sigaction action = {0};
  action.sa_handler = mdk_pds_term_handler;
  sigemptyset(&action.sa_mask);
  mdk_pds_term_seen = 0;
  mdk_pds_term_write_fd = ends[1];
  if (sigaction(SIGTERM, &action, NULL) != 0) {
    int err = errno;
    mdk_pds_term_write_fd = -1;
    close(ends[0]); close(ends[1]);
    return mdk_err(mdk_str_cstr(strerror(err)));
  }
  mdk_pds_term_read_fd = ends[0];
  return mdk_ok(MDK_NET_TAG(ends[0]));
}

/* pdsSignalRequested : Unit -> Bool. No pipe drain is needed: one SIGTERM
 * ends admission permanently, and the pipe remains readable until exit. */
long long mdk_pds_signal_requested(long long unit) {
  (void)unit;
  return MDK_NET_TAG(mdk_pds_term_seen != 0);
}

/* ioPoll : Array Int -> Array Int -> Int -> Result String (Array Int)
 * fds and interests are parallel arrays (interest bit 1 = readable, bit 2 =
 * writable); timeout is milliseconds (-1 = wait forever).  Returns one
 * readiness word per fd: bit 1 readable, bit 2 writable.  An error or hangup
 * condition marks the fd readable AND writable so the parked task retries its
 * syscall and surfaces the error through the ordinary Result path. */
long long mdk_io_poll(long long fds_arr, long long ints_arr, long long timeout_tagged) {
  const long long *fds = (const long long *)fds_arr;
  const long long *ints = (const long long *)ints_arr;
  long long n = fds[0];
  if (ints[0] != n) return mdk_err(mdk_str_cstr("ioPoll: fds and interests differ in length"));
  int timeout = (int)(timeout_tagged >> 1);
  struct pollfd *pfds = (struct pollfd *)mdk_alloc(sizeof(struct pollfd) * (n ? n : 1));
  for (long long i = 0; i < n; i++) {
    long long interest = ints[i + 1] >> 1;
    pfds[i].fd = MDK_NET_UNTAG(fds[i + 1]);
    pfds[i].events = (short)(((interest & 1) ? POLLIN : 0) | ((interest & 2) ? POLLOUT : 0));
    pfds[i].revents = 0;
  }
  int rc = poll(pfds, (nfds_t)n, timeout);
  if (rc < 0 && errno != EINTR) return mdk_err(mdk_str_cstr(strerror(errno)));
  long long *cell = (long long *)mdk_alloc(8 * (n + 1));
  cell[0] = n;
  for (long long i = 0; i < n; i++) {
    long long ready = 0;
    if (rc > 0) {
      short re = pfds[i].revents;
      if (re & (POLLIN | POLLPRI)) ready |= 1;
      if (re & POLLOUT) ready |= 2;
      if (re & (POLLERR | POLLHUP | POLLNVAL)) ready |= 3;
    }
    cell[i + 1] = (ready << 1) | 1;
  }
  return mdk_ok((long long)cell);
}

/* netSetNonblock : fd -> Bool -> Result String Unit — fcntl O_NONBLOCK on/off. */
long long mdk_net_set_nonblock(long long fd_tagged, long long on_tagged) {
  int fd = MDK_NET_UNTAG(fd_tagged);
  int on = (int)(on_tagged >> 1);
  int flags = fcntl(fd, F_GETFL, 0);
  if (flags < 0) return mdk_err(mdk_str_cstr(strerror(errno)));
  flags = on ? (flags | O_NONBLOCK) : (flags & ~O_NONBLOCK);
  if (fcntl(fd, F_SETFL, flags) < 0) return mdk_err(mdk_str_cstr(strerror(errno)));
  return mdk_ok(1);  /* Ok () */
}

static int mdk_net_would_block(int e) {
  return e == EAGAIN || e == EWOULDBLOCK || e == EINPROGRESS || e == EINTR;
}

/* netConnectStart : host -> port -> Result String Int (a handshake under way)
 * O_NONBLOCK goes on BEFORE connect(2), so EINPROGRESS is the ordinary answer
 * and an immediate success (common on loopback) is the other; both hand back the
 * descriptor, and netConnectCheck below is what tells them apart.  Resolution is
 * still getaddrinfo and still blocks: only the handshake is deferred.
 * Unlike mdk_net_tcp_connect this does NOT walk the whole address list to
 * completion — a caller cannot park on a descriptor it was never handed, so the
 * first address whose connect either succeeds or starts is the one returned. */
long long mdk_net_connect_start(long long host_cell, long long port_tagged) {
  const char *host = (const char *)host_cell + 24;
  char port[16]; snprintf(port, sizeof port, "%d", MDK_NET_UNTAG(port_tagged));
  struct addrinfo hints = {0}, *res, *ai;
  hints.ai_family = AF_UNSPEC;
  hints.ai_socktype = SOCK_STREAM;
  int gai = getaddrinfo(host, port, &hints, &res);
  if (gai != 0) return mdk_err(mdk_str_cstr(gai_strerror(gai)));
  int fd = -1, last = 0;
  for (ai = res; ai; ai = ai->ai_next) {
    fd = socket(ai->ai_family, ai->ai_socktype, ai->ai_protocol);
    if (fd < 0) { last = errno; continue; }
    int flags = fcntl(fd, F_GETFL, 0);
    if (flags < 0 || fcntl(fd, F_SETFL, flags | O_NONBLOCK) < 0) {
      last = errno; close(fd); fd = -1; continue;
    }
    if (connect(fd, ai->ai_addr, ai->ai_addrlen) == 0) break;
    if (mdk_net_would_block(errno)) break;
    last = errno; close(fd); fd = -1;
  }
  freeaddrinfo(res);
  if (fd < 0) return mdk_err(mdk_str_cstr(strerror(last)));
#ifdef SO_NOSIGPIPE
  { int on = 1; setsockopt(fd, SOL_SOCKET, SO_NOSIGPIPE, &on, sizeof on); }
#endif
  return mdk_ok(MDK_NET_TAG(fd));
}

/* netConnectCheck : fd -> Result String (Option Unit) — None = still in flight.
 * SO_ERROR alone cannot answer this: it reads 0 both for a connected socket and
 * for one still in EINPROGRESS, so a woken task that trusted it would take an
 * unconnected descriptor for a connected one.  poll(2) with a zero timeout is
 * the discriminator — writability is what completing the handshake signals —
 * and SO_ERROR then says whether what completed was a connection or a refusal.
 * POLLERR/POLLHUP arrive with SO_ERROR set, so they need no arm of their own. */
long long mdk_net_connect_check(long long fd_tagged) {
  struct pollfd pfd;
  pfd.fd = MDK_NET_UNTAG(fd_tagged);
  pfd.events = POLLOUT;
  pfd.revents = 0;
  int rc = poll(&pfd, 1, 0);
  if (rc < 0) {
    if (mdk_net_would_block(errno)) return mdk_ok(mdk_none());
    return mdk_err(mdk_str_cstr(strerror(errno)));
  }
  if (rc == 0 || !(pfd.revents & (POLLOUT | POLLERR | POLLHUP | POLLNVAL)))
    return mdk_ok(mdk_none());
  int err = 0; socklen_t len = sizeof err;
  if (getsockopt(pfd.fd, SOL_SOCKET, SO_ERROR, &err, &len) != 0)
    return mdk_err(mdk_str_cstr(strerror(errno)));
  if (err != 0) return mdk_err(mdk_str_cstr(strerror(err)));
  return mdk_ok(mdk_some(1));  /* Ok (Some ()) */
}

/* netTryAccept : listening fd -> Result String (Option Int) — None = would-block. */
long long mdk_net_try_accept(long long lis_tagged) {
  int c = accept(MDK_NET_UNTAG(lis_tagged), NULL, NULL);
  if (c < 0) {
    if (mdk_net_would_block(errno)) return mdk_ok(mdk_none());
    return mdk_err(mdk_str_cstr(strerror(errno)));
  }
#ifdef SO_NOSIGPIPE
  { int on = 1; setsockopt(c, SOL_SOCKET, SO_NOSIGPIPE, &on, sizeof on); }
#endif
  return mdk_ok(mdk_some(MDK_NET_TAG(c)));
}

/* netTryRecv : fd -> maxBytes -> Result String (Option (Array Int))
 * None = would-block; Some [] = EOF (matches netRecv). */
long long mdk_net_try_recv(long long fd_tagged, long long max_tagged) {
  long long max = max_tagged >> 1;
  unsigned char *buf = (unsigned char *)mdk_alloc(max > 0 ? max : 1);
  ssize_t r = recv(MDK_NET_UNTAG(fd_tagged), buf, (size_t)(max > 0 ? max : 0), 0);
  if (r < 0) {
    if (mdk_net_would_block(errno)) return mdk_ok(mdk_none());
    return mdk_err(mdk_str_cstr(strerror(errno)));
  }
  long long *cell = (long long *)mdk_alloc(8 * (r + 1));
  cell[0] = (long long)r;
  for (ssize_t i = 0; i < r; i++) cell[i + 1] = (((long long)buf[i]) << 1) | 1;
  return mdk_ok(mdk_some((long long)cell));
}

/* netTryRecvBytes : fd -> maxBytes -> Result String (Option ByteBlock)
 * mdk_net_try_recv delivering a packed block instead of a boxed array: recv(2)
 * writes straight into a block's own payload, so no per-byte boxing loop runs.
 * The block recv writes into is the CEILING one, maxBytes long, because the
 * received size is not known until recv returns.  A short read is then copied
 * down into a block of exactly that size and the ceiling block dropped: the
 * returned value is reachable for as long as the caller holds it, so retaining
 * the ceiling would cost maxBytes of live memory per retained chunk however
 * few bytes arrived.  The copy is O(bytes received), the same order as the
 * recv that produced them.
 * None = would-block; Some (a zero-length block) = EOF (matches netTryRecv). */
long long mdk_net_try_recv_bytes(long long fd_tagged, long long max_tagged) {
  long long max = max_tagged >> 1;
  if (max < 0) max = 0;
  long long *cell = mdk_byteblock_alloc(max);
  ssize_t r = recv(MDK_NET_UNTAG(fd_tagged),
                   mdk_byteblock_bytes((long long)cell), (size_t)max, 0);
  if (r < 0) {
    if (mdk_net_would_block(errno)) return mdk_ok(mdk_none());
    return mdk_err(mdk_str_cstr(strerror(errno)));
  }
  if (r < max) {
    long long *fit = mdk_byteblock_alloc((long long)r);
    if (r > 0) memcpy(mdk_byteblock_bytes((long long)fit),
                      mdk_byteblock_bytes((long long)cell), (size_t)r);
    cell = fit;
  }
  return mdk_ok(mdk_some((long long)cell));
}

/* netTrySend : fd -> Array Int -> Result String (Option Int)
 * None = would-block; Some n = bytes written (may be short). */
long long mdk_net_try_send(long long fd_tagged, long long arr) {
  const long long *a = (const long long *)arr;
  long long n = a[0];
  unsigned char *buf = (unsigned char *)mdk_alloc(n ? n : 1);
  for (long long i = 0; i < n; i++) buf[i] = (unsigned char)((a[i + 1] >> 1) & 0xFF);
  int flags = 0;
#ifdef MSG_NOSIGNAL
  flags = MSG_NOSIGNAL;
#endif
  ssize_t w = send(MDK_NET_UNTAG(fd_tagged), buf, (size_t)n, flags);
  if (w < 0) {
    if (mdk_net_would_block(errno)) return mdk_ok(mdk_none());
    return mdk_err(mdk_str_cstr(strerror(errno)));
  }
  return mdk_ok(mdk_some(MDK_NET_TAG((long long)w)));
}

/* netTrySendFrom : fd -> Array Int -> offset -> Result String (Option Int)
 * `netTrySend` from an offset, copying at most MDK_SEND_CHUNK bytes per call:
 * a caller looping over a large payload pays for the bytes it sends, not for
 * the whole remainder on every retry.  None = would-block; Some n = bytes
 * written from `offset` (may be short, never more than the chunk). */
long long mdk_net_try_send_from(long long fd_tagged, long long arr, long long off_tagged) {
  const long long *a = (const long long *)arr;
  long long len = a[0];
  long long off = off_tagged >> 1;
  if (off < 0) off = 0;
  if (off > len) off = len;
  long long n = len - off;
  if (n > MDK_SEND_CHUNK) n = MDK_SEND_CHUNK;
  unsigned char *buf = (unsigned char *)mdk_alloc(n ? n : 1);
  for (long long i = 0; i < n; i++) buf[i] = (unsigned char)((a[off + i + 1] >> 1) & 0xFF);
  int flags = 0;
#ifdef MSG_NOSIGNAL
  flags = MSG_NOSIGNAL;
#endif
  ssize_t w = send(MDK_NET_UNTAG(fd_tagged), buf, (size_t)n, flags);
  if (w < 0) {
    if (mdk_net_would_block(errno)) return mdk_ok(mdk_none());
    return mdk_err(mdk_str_cstr(strerror(errno)));
  }
  return mdk_ok(mdk_some(MDK_NET_TAG((long long)w)));
}

/* The window [start, end) of a ByteBlock that netSendBytesFrom and
 * netTrySendBytesFrom send.  Unlike the clamping Array Int senders above, a
 * window outside the block is refused: returns 0 and sets *err to the Err
 * value; otherwise returns 1 and sets *n to the byte count, capped at
 * MDK_SEND_CHUNK.  send(2) reads the block's own payload, so nothing is
 * copied. */
static int mdk_net_send_window(const char *who, long long bb, long long start,
                               long long end, long long *n, long long *err) {
  long long len = mdk_byteblock_count(bb);
  if (start < 0 || end < start || end > len) {
    char msg[160];
    snprintf(msg, sizeof msg,
             "%s: window [%lld, %lld) is outside a block of %lld bytes",
             who, start, end, len);
    *err = mdk_err(mdk_str_cstr(msg));
    return 0;
  }
  *n = end - start;
  if (*n > MDK_SEND_CHUNK) *n = MDK_SEND_CHUNK;
  return 1;
}

/* netSendBytesFrom : fd -> ByteBlock -> start -> end -> Result String Int. */
long long mdk_net_send_bytes_from(long long fd_tagged, long long bb,
                                  long long start_tagged, long long end_tagged) {
  long long start = start_tagged >> 1, n = 0, err = 0;
  if (!mdk_net_send_window("netSendBytesFrom", bb, start, end_tagged >> 1, &n, &err))
    return err;
  int flags = 0;
#ifdef MSG_NOSIGNAL
  flags = MSG_NOSIGNAL;
#endif
  ssize_t w = send(MDK_NET_UNTAG(fd_tagged), mdk_byteblock_bytes(bb) + start,
                   (size_t)n, flags);
  if (w < 0) return mdk_err(mdk_str_cstr(strerror(errno)));
  return mdk_ok(MDK_NET_TAG((long long)w));
}

/* netTrySendBytesFrom : fd -> ByteBlock -> start -> end
 *   -> Result String (Option Int).  None = would-block. */
long long mdk_net_try_send_bytes_from(long long fd_tagged, long long bb,
                                      long long start_tagged, long long end_tagged) {
  long long start = start_tagged >> 1, n = 0, err = 0;
  if (!mdk_net_send_window("netTrySendBytesFrom", bb, start, end_tagged >> 1, &n, &err))
    return err;
  int flags = 0;
#ifdef MSG_NOSIGNAL
  flags = MSG_NOSIGNAL;
#endif
  ssize_t w = send(MDK_NET_UNTAG(fd_tagged), mdk_byteblock_bytes(bb) + start,
                   (size_t)n, flags);
  if (w < 0) {
    if (mdk_net_would_block(errno)) return mdk_ok(mdk_none());
    return mdk_err(mdk_str_cstr(strerror(errno)));
  }
  return mdk_ok(mdk_some(MDK_NET_TAG((long long)w)));
}

/* ---------------------------------------------------------------------------
 * Process entry.  The emitted IR's entry point is `mdk_program_main` (renamed
 * from `@main` in compiler/backend/llvm_emit.mdk); this runtime owns the real
 * C `main`.  We run the whole Medaka pipeline on a dedicated worker thread with
 * a 256 MB stack: Medaka's lexer/parser recurse deeply, and the Linux default
 * 8 MB thread stack overflows on large inputs (macOS previously baked a 512 MB
 * stack via the Mach-O-only `-Wl,-stack_size` link flag, which GNU ld rejects).
 * Self-provisioning the stack here removes the reliance on that link flag on
 * both platforms.
 *
 * The worker MUST be created via GC_pthread_create (GC_THREADS is defined above
 * <gc.h>) so Boehm registers the worker's stack as a GC root; a raw
 * pthread_create'd thread would be invisible to the collector and its live
 * objects would be reclaimed mid-run. */
extern int mdk_program_main(int argc, char **argv);

struct mdk_main_args {
  int argc;
  char **argv;
  int ret;
};

/* ---------------------------------------------------------------------------
 * P0-2: "no silent death" signal backstop.  The tree-walking interpreter and
 * deeply-recursive compiled programs can exhaust the 256 MB worker stack; the
 * kernel then delivers SIGSEGV/SIGBUS and, with no handler, the process dies
 * with a bare signal and ZERO output.  We install a SIGSEGV/SIGBUS handler on a
 * dedicated `sigaltstack` (so it can run even when the worker stack is fully
 * exhausted) that prints a clean, coded diagnostic and exits nonzero.
 *
 * Boehm coexistence: without incremental mode (we never call
 * GC_enable_incremental), Boehm does not keep a live SIGSEGV handler during
 * normal operation on the run path.  We nonetheless install AFTER GC_INIT (the
 * `__attribute__((constructor)) mdk_gc_init` runs before `main`) and capture the
 * previous handler via sigaction; for any fault that is NOT stack-overflow-shaped
 * we CHAIN to that previous handler (so a legitimate GC-owned fault, if one ever
 * exists, is still serviced), and only if there is none do we print a generic
 * message and exit — never a silent death.  Only signal-async-safe calls
 * (write/_exit) run in the handler; no allocation, no stdio. */
static char mdk_sigaltstack[256 * 1024];   /* alt stack for the fault handler */
static char *mdk_stack_lo = NULL;          /* worker stack low  address */
static char *mdk_stack_hi = NULL;          /* worker stack high address */
static struct sigaction mdk_old_segv;
static struct sigaction mdk_old_bus;

/* Is `addr` within (or just below the guard page of) the worker stack? */
static int mdk_addr_near_stack(void *addr) {
  if (!addr || !mdk_stack_lo || !mdk_stack_hi) return 0;
  char *a = (char *)addr;
  /* Allow a slack window below the mapped stack for the guard region. */
  return a >= (mdk_stack_lo - (1 << 20)) && a <= mdk_stack_hi;
}

static void mdk_chain_previous(int sig, siginfo_t *info, void *uctx) {
  struct sigaction *old = (sig == SIGBUS) ? &mdk_old_bus : &mdk_old_segv;
  if (old->sa_flags & SA_SIGINFO) {
    if (old->sa_sigaction) { old->sa_sigaction(sig, info, uctx); return; }
  } else if (old->sa_handler != SIG_DFL && old->sa_handler != SIG_IGN) {
    old->sa_handler(sig);
    return;
  }
  /* No previous handler: no silent death — print generic and exit nonzero.
     mdk_flush_run_stdout_on_abort is async-signal-safe (word reads + write(2)
     only, no allocation, no stdio) — see its definition near mdk_putstr.
     mdk_flush_build_stdout_on_fatal_signal is its build-binary counterpart
     (same discipline; see its definition near mdk_fwrite_str) — both are
     no-ops unless the corresponding engine actually populated their buffer, so
     calling both here is safe regardless of which engine is running. */
  mdk_flush_run_stdout_on_abort();
  mdk_flush_build_stdout_on_fatal_signal();
  static const char m[] =
    "runtime error [E-FATAL-SIGNAL]: fatal memory fault (segmentation fault)\n";
  write(2, m, sizeof(m) - 1);
  _exit(139);
}

static void mdk_fault_handler(int sig, siginfo_t *info, void *uctx) {
  if (mdk_addr_near_stack(info ? info->si_addr : NULL)) {
    mdk_flush_run_stdout_on_abort();
    mdk_flush_build_stdout_on_fatal_signal();
    static const char m[] =
      "runtime error [E-STACK-OVERFLOW]: stack overflow (recursion too deep)\n";
    write(2, m, sizeof(m) - 1);
    _exit(134);
  }
  mdk_chain_previous(sig, info, uctx);
}

/* Install the alt stack (per-thread) + the SIGSEGV/SIGBUS handlers.  Called on
 * the worker thread, after its stack bounds have been recorded. */
static void mdk_install_fault_handler(void) {
  stack_t ss;
  ss.ss_sp = mdk_sigaltstack;
  ss.ss_size = sizeof(mdk_sigaltstack);
  ss.ss_flags = 0;
  if (sigaltstack(&ss, NULL) != 0) return;  /* best-effort; skip if unavailable */

  struct sigaction sa;
  memset(&sa, 0, sizeof sa);
  sa.sa_sigaction = mdk_fault_handler;
  sa.sa_flags = SA_SIGINFO | SA_ONSTACK;
  sigemptyset(&sa.sa_mask);
  sigaction(SIGSEGV, &sa, &mdk_old_segv);
  sigaction(SIGBUS, &sa, &mdk_old_bus);
}

/* Record the running (worker) thread's stack bounds for the fault handler. */
static void mdk_record_stack_bounds(void) {
#ifdef __APPLE__
  void *hi = pthread_get_stackaddr_np(pthread_self());  /* high addr (top) */
  size_t sz = pthread_get_stacksize_np(pthread_self());
  mdk_stack_hi = (char *)hi;
  mdk_stack_lo = (char *)hi - sz;
#else
  pthread_attr_t at;
  if (pthread_getattr_np(pthread_self(), &at) == 0) {
    void *base;
    size_t sz;
    if (pthread_attr_getstack(&at, &base, &sz) == 0) {
      mdk_stack_lo = (char *)base;
      mdk_stack_hi = (char *)base + sz;
    }
    pthread_attr_destroy(&at);
  }
#endif
}

static void *mdk_main_thread(void *p) {
  struct mdk_main_args *a = (struct mdk_main_args *)p;
  mdk_record_stack_bounds();
  mdk_install_fault_handler();
  a->ret = mdk_program_main(a->argc, a->argv);
  return NULL;
}

int main(int argc, char **argv) {
  struct mdk_main_args a;
  a.argc = argc;
  a.argv = argv;
  a.ret = 0;

  pthread_attr_t attr;
  if (pthread_attr_init(&attr) != 0) {
    fprintf(stderr, "medaka: pthread_attr_init failed\n");
    return 1;
  }
  /* 256 MB: comfortably over the ~32 MB (-O2) / ~128 MB (-O0) measured need. */
  if (pthread_attr_setstacksize(&attr, (size_t)256 * 1024 * 1024) != 0) {
    fprintf(stderr, "medaka: pthread_attr_setstacksize failed\n");
    return 1;
  }

  pthread_t tid;
  int rc = GC_pthread_create(&tid, &attr, mdk_main_thread, &a);
  pthread_attr_destroy(&attr);
  if (rc != 0) {
    fprintf(stderr, "medaka: GC_pthread_create failed\n");
    return 1;
  }
  GC_pthread_join(tid, NULL);
  return a.ret;
}
