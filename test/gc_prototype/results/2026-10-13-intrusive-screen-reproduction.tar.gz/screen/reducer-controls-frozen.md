{
  "status": "passed synthetic independent protocol controls; no workloads/processes",
  "count": 51,
  "checks": [
    {
      "case": "both primary gains; all controls and RSS safe",
      "expected_advance": true,
      "observed_advance": true,
      "passed": true
    },
    {
      "case": "four of six gains insufficient ('tree', 262144)",
      "expected_advance": false,
      "observed_advance": false,
      "passed": true
    },
    {
      "case": "five of six gains sufficient ('tree', 262144)",
      "expected_advance": true,
      "observed_advance": true,
      "passed": true
    },
    {
      "case": "strict .95 equality fails primary ('tree', 262144)",
      "expected_advance": false,
      "observed_advance": false,
      "passed": true
    },
    {
      "case": "only one primary gaining cannot advance ('tree', 262144)",
      "expected_advance": false,
      "observed_advance": false,
      "passed": true
    },
    {
      "case": "four of six gains insufficient ('tree', 262136)",
      "expected_advance": false,
      "observed_advance": false,
      "passed": true
    },
    {
      "case": "five of six gains sufficient ('tree', 262136)",
      "expected_advance": true,
      "observed_advance": true,
      "passed": true
    },
    {
      "case": "strict .95 equality fails primary ('tree', 262136)",
      "expected_advance": false,
      "observed_advance": false,
      "passed": true
    },
    {
      "case": "only one primary gaining cannot advance ('tree', 262136)",
      "expected_advance": false,
      "observed_advance": false,
      "passed": true
    },
    {
      "case": "secondary repeatable regression rejects ('ephemeral', 262144)",
      "expected_advance": false,
      "observed_advance": false,
      "passed": true
    },
    {
      "case": "secondary repeatable regression rejects ('ephemeral', 262136)",
      "expected_advance": false,
      "observed_advance": false,
      "passed": true
    },
    {
      "case": "secondary repeatable regression rejects ('list', 262144)",
      "expected_advance": false,
      "observed_advance": false,
      "passed": true
    },
    {
      "case": "secondary repeatable regression rejects ('list', 262136)",
      "expected_advance": false,
      "observed_advance": false,
      "passed": true
    },
    {
      "case": "secondary repeatable regression rejects ('mutation', 262144)",
      "expected_advance": false,
      "observed_advance": false,
      "passed": true
    },
    {
      "case": "secondary repeatable regression rejects ('mutation', 262136)",
      "expected_advance": false,
      "observed_advance": false,
      "passed": true
    },
    {
      "case": "secondary repeatable regression rejects ('atomic', 262144)",
      "expected_advance": false,
      "observed_advance": false,
      "passed": true
    },
    {
      "case": "secondary repeatable regression rejects ('atomic', 262136)",
      "expected_advance": false,
      "observed_advance": false,
      "passed": true
    },
    {
      "case": "secondary repeatable regression rejects ('mixed', 262144)",
      "expected_advance": false,
      "observed_advance": false,
      "passed": true
    },
    {
      "case": "secondary repeatable regression rejects ('mixed', 262136)",
      "expected_advance": false,
      "observed_advance": false,
      "passed": true
    },
    {
      "case": "secondary repeatable regression rejects ('sizes', 262144)",
      "expected_advance": false,
      "observed_advance": false,
      "passed": true
    },
    {
      "case": "secondary repeatable regression rejects ('sizes', 262136)",
      "expected_advance": false,
      "observed_advance": false,
      "passed": true
    },
    {
      "case": "secondary repeatable regression rejects ('tree', 16777216)",
      "expected_advance": false,
      "observed_advance": false,
      "passed": true
    },
    {
      "case": "secondary repeatable regression rejects ('tree', 16777208)",
      "expected_advance": false,
      "observed_advance": false,
      "passed": true
    },
    {
      "case": "four secondary regressions remain inconclusive",
      "expected_advance": true,
      "observed_advance": true,
      "passed": true
    },
    {
      "case": "strict1.05 equality is not secondary regression",
      "expected_advance": true,
      "observed_advance": true,
      "passed": true
    },
    {
      "case": "paired median qualifies despite ratio-of-medians outlier",
      "expected_advance": true,
      "observed_advance": true,
      "passed": true
    },
    {
      "case": "material total RSS above110pct rejects ('ephemeral', 262144)",
      "expected_advance": false,
      "observed_advance": false,
      "passed": true
    },
    {
      "case": "material total RSS above110pct rejects ('ephemeral', 262136)",
      "expected_advance": false,
      "observed_advance": false,
      "passed": true
    },
    {
      "case": "material total RSS above110pct rejects ('list', 262144)",
      "expected_advance": false,
      "observed_advance": false,
      "passed": true
    },
    {
      "case": "material total RSS above110pct rejects ('list', 262136)",
      "expected_advance": false,
      "observed_advance": false,
      "passed": true
    },
    {
      "case": "material total RSS above110pct rejects ('tree', 262144)",
      "expected_advance": false,
      "observed_advance": false,
      "passed": true
    },
    {
      "case": "material total RSS above110pct rejects ('tree', 262136)",
      "expected_advance": false,
      "observed_advance": false,
      "passed": true
    },
    {
      "case": "material total RSS above110pct rejects ('mutation', 262144)",
      "expected_advance": false,
      "observed_advance": false,
      "passed": true
    },
    {
      "case": "material total RSS above110pct rejects ('mutation', 262136)",
      "expected_advance": false,
      "observed_advance": false,
      "passed": true
    },
    {
      "case": "material total RSS above110pct rejects ('atomic', 262144)",
      "expected_advance": false,
      "observed_advance": false,
      "passed": true
    },
    {
      "case": "material total RSS above110pct rejects ('atomic', 262136)",
      "expected_advance": false,
      "observed_advance": false,
      "passed": true
    },
    {
      "case": "material total RSS above110pct rejects ('mixed', 262144)",
      "expected_advance": false,
      "observed_advance": false,
      "passed": true
    },
    {
      "case": "material total RSS above110pct rejects ('mixed', 262136)",
      "expected_advance": false,
      "observed_advance": false,
      "passed": true
    },
    {
      "case": "material total RSS above110pct rejects ('sizes', 262144)",
      "expected_advance": false,
      "observed_advance": false,
      "passed": true
    },
    {
      "case": "material total RSS above110pct rejects ('sizes', 262136)",
      "expected_advance": false,
      "observed_advance": false,
      "passed": true
    },
    {
      "case": "material total RSS above110pct rejects ('tree', 16777216)",
      "expected_advance": false,
      "observed_advance": false,
      "passed": true
    },
    {
      "case": "material total RSS above110pct rejects ('tree', 16777208)",
      "expected_advance": false,
      "observed_advance": false,
      "passed": true
    },
    {
      "case": "strict110pct RSS equality does not reject",
      "expected_advance": true,
      "observed_advance": true,
      "passed": true
    },
    {
      "case": "baseline exactly twice floor is material",
      "expected_advance": false,
      "observed_advance": false,
      "passed": true
    },
    {
      "case": "below twice floor remains inconclusive without subtraction",
      "expected_advance": true,
      "observed_advance": true,
      "passed": true
    },
    {
      "case": "floor uses all-six median rather than maximum",
      "expected_advance": false,
      "observed_advance": false,
      "passed": true
    },
    {
      "case": "floor median differs from first/minimum",
      "expected_advance": true,
      "observed_advance": true,
      "passed": true
    },
    {
      "case": "unexplained logical copy change",
      "expected_assertion": true,
      "observed_assertion": true,
      "passed": true
    },
    {
      "case": "missing static head charge",
      "expected_assertion": true,
      "observed_assertion": true,
      "passed": true
    },
    {
      "case": "missing current accounting charge",
      "expected_assertion": true,
      "observed_assertion": true,
      "passed": true
    },
    {
      "case": "major-only queue cannot exceed baseline",
      "expected_assertion": true,
      "observed_assertion": true,
      "passed": true
    }
  ],
  "runner_sha256": "b44cdedb94e8f1f775a41b266bdd15d74ef16a97fb922e564cce4bc38cd6f6bc",
  "protocol_sha256": "67317a985fd26ea1035a7fe0fbdfecdac1e8dc26b880f133064c6a98f7c0386a",
  "fixture_sha256": "fc1be44e4b7be59358a50c9b67b4c13c88c4ba85735f78e43f8d3bfa4f3b8fa6",
  "interpretation": "Artificial deterministic times/RSS exercise frozen threshold boundaries and collection accounting guards; no performance estimates are drawn."
}
