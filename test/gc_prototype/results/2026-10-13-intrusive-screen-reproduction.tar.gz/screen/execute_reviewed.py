import hashlib
import json
from pathlib import Path
import subprocess
import sys

HERE=Path(__file__).resolve().parent
REPO=Path('/root/.codex/worktrees/f396/medaka')
expected={'run.py':'b44cdedb94e8f1f775a41b266bdd15d74ef16a97fb922e564cce4bc38cd6f6bc',
          'PROTOCOL.md':'67317a985fd26ea1035a7fe0fbdfecdac1e8dc26b880f133064c6a98f7c0386a',
          'reducer_controls.py':'fc1be44e4b7be59358a50c9b67b4c13c88c4ba85735f78e43f8d3bfa4f3b8fa6',
          'reducer-controls-frozen.md':'d6b7c11b350f853f79e67d608dfa249f7f8da9e2061fd4d1723b39df3b2177a8'}
for name,digest in expected.items():
    assert hashlib.sha256((HERE/name).read_bytes()).hexdigest()==digest,name
assert not (HERE/'execution-attempt.json').exists(),'preserve previous attempt'
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO,text=True).strip()
argv=[sys.executable,str(HERE/'run.py'),'--execute']
record={'workspace_head_before':head,'experiment_source_base':'85c364304684c44c544957c8ba2b180d15d736c5',
        'argv':argv,'reviewed_sha256':expected,'status':'running'}
(HERE/'execution-attempt.json').write_text(json.dumps(record,indent=2)+'\n')
with (HERE/'execution.stdout').open('w') as stdout,(HERE/'execution.stderr').open('w') as stderr:
    cp=subprocess.run(argv,cwd=REPO,stdout=stdout,stderr=stderr)
record.update(returncode=cp.returncode,status='completed' if cp.returncode==0 else 'failed',
              workspace_head_after=subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO,text=True).strip(),
              stdout=(HERE/'execution.stdout').read_text(),stderr=(HERE/'execution.stderr').read_text())
(HERE/'execution-attempt.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'returncode':cp.returncode,'stdout':record['stdout'],'stderr':record['stderr']}),flush=True)
sys.exit(cp.returncode)
