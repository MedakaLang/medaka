"""Frozen intrusive minor queue screen; no execution without --execute."""
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shlex
import shutil
import statistics
import subprocess

HERE=Path(__file__).resolve().parent
REPO=Path('/root/.codex/worktrees/f396/medaka')
FROZEN=Path('/tmp/medaka-intrusive-promotion-85')
OLD_TIMING=Path('/tmp/medaka-tree-direct-old-timing-85')
FULL=Path('/tmp/medaka-intrusive-full-correctness-85/execution.json')
QUALIFIED=FROZEN/'verification/run-5ce01f64/verification.json'
COUNT=5_000_000
PROFILES=('ephemeral','list','tree','mutation','atomic','mixed','sizes')
CELLS=[(p,c) for p in PROFILES for c in (262144,262136)]+[('tree',16777216),('tree',16777208)]
ARMS=('custom-baseline','custom-intrusive','boehm-historical-default','boehm-historical-fixed128','boehm-caller-default','boehm-caller-fixed128')
KEYS=('custom-baseline','custom-intrusive','boehm-historical','boehm-caller')
DEFINES={k:['USE_PREPARED','INLINE_ALLOC','INLINE_STORE']+(['USE_BOEHM','USE_INLINE'] if k=='boehm-historical' else ['USE_BOEHM','USE_CALLER_INLINE'] if k=='boehm-caller' else []) for k in KEYS}
VARIABLE={'elapsed_seconds','preparation_seconds','process_peak_rss_bytes','static_metadata_bytes','work_queue_bytes','accounted_bytes','peak_accounted_bytes'}
ENV={k:v for k,v in os.environ.items() if not k.startswith('GC_') and k not in ('ASAN_OPTIONS','UBSAN_OPTIONS')}
report={'status':'source-only; no execution','commands':[],'checks':[]}

def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def key(arm): return arm.rsplit('-',1)[0] if arm.startswith('boehm') else arm
def arm_env(arm):
    env=dict(ENV)
    if arm.endswith('fixed128'): env['GC_INITIAL_HEAP_SIZE']='134217728'
    return env
def preprocess_flags(flags):
    result=[];i=0
    while i<len(flags):
        flag=flags[i]
        if flag in ('-I','-isystem','-iquote','-include','-isysroot','--sysroot'):
            result.extend((flag,flags[i+1]));i+=2;continue
        if flag.startswith(('-I','-D','-U','--sysroot=')) or flag=='-pthread': result.append(flag)
        i+=1
    return result
def command(argv,env=ENV,diagnostic=False):
    cp=subprocess.run([str(x) for x in argv],cwd=REPO,env=env,text=True,capture_output=True,timeout=180)
    report['commands'].append({'argv':[str(x) for x in argv],'returncode':cp.returncode,'stdout':cp.stdout if not diagnostic else None,
                              'stderr':cp.stderr if not diagnostic else None,'GC_environment':{k:v for k,v in env.items() if k.startswith('GC_')}})
    assert cp.returncode==0,(argv,cp.returncode,cp.stderr)
    assert diagnostic or not cp.stderr,(argv,cp.stderr)
    return cp

def prepare():
    manifest=json.loads((FROZEN/'manifest.json').read_text())
    base=manifest['baseline_commit']
    for arm in ('baseline','candidate'):
        directory=HERE/arm
        directory.mkdir(exist_ok=True)
        for name in ('gc.c','gc.h','workload.c'):
            path=FROZEN/arm/name
            assert sha(path)==manifest['source_sha256'][arm][name]
            if arm=='baseline': assert path.read_bytes()==subprocess.check_output(['git','show',base+':test/gc_prototype/'+name],cwd=REPO)
            shutil.copyfile(path,directory/name)
    assert (HERE/'baseline/gc.h').read_bytes()==(HERE/'candidate/gc.h').read_bytes()
    assert (HERE/'baseline/workload.c').read_bytes()==(HERE/'candidate/workload.c').read_bytes()
    for evidence in (FULL,QUALIFIED):
        a=json.loads(evidence.read_text())
        if evidence==FULL: assert a['status']=='passed' and a['actual_runner_returncode']==0 and a['inputs_unchanged']
        else: assert len(a['runs'])==23 and all(r['returncode']==(86 if r['arm'].startswith('mutant-') else 0) for r in a['runs'])
    assert json.loads(QUALIFIED.read_text())['plan']['source_hashes']==manifest['source_sha256']
    assert json.loads(FULL.read_text())['prepared']['candidate_sha256']==manifest['source_sha256']['candidate']
    old=json.loads((OLD_TIMING/'preparation.json').read_text())
    config=old['boehm_config']
    assert config['boehm_linkage']=='static' and sha(config['boehm_archive'])==config['boehm_archive_sha256']
    for name,digest in old['adapter_sha256'].items():
        assert sha(OLD_TIMING/'build'/name)==digest
        shutil.copyfile(OLD_TIMING/'build'/name,HERE/name)
    helper=REPO/'test/gc_prototype/run.py'
    assert sha(helper)==json.loads(FULL.read_text())['prepared']['module_sha256']
    shutil.copyfile(helper,HERE/'original_run.py')
    runtime=subprocess.check_output(['git','show',base+':runtime/medaka_rt.c'],cwd=REPO)
    (HERE/'runtime').mkdir(exist_ok=True)
    (HERE/'runtime/medaka_rt.c').write_bytes(runtime)
    assert hashlib.sha256(runtime).hexdigest()==old['runtime_sha256']
    report.update(baseline_commit=base,count=COUNT,cells=CELLS,arms=ARMS,rounds=6,boehm_config=config,
                  source_sha256=manifest['source_sha256'],qualification_sha256={str(p):sha(p) for p in (FULL,QUALIFIED)},
                  adapter_sha256=old['adapter_sha256'],runtime_sha256=old['runtime_sha256'],helper_sha256=sha(helper),
                  acceptance={'primary_cells':[['tree',262144],['tree',262136]],'gain_median_strict':.95,'gain_5_of_6_strict':.95,
                              'regression_median_strict':1.05,'regression_5_of_6_strict':1.05,'RSS_median_strict':1.10,'RSS_floor_multiplier':2.0,
                              'interpretation':'screen only; held-out confirmation required for advancement'})
    schedule=[dict(round=r,profile=p,capacity=c,position=i,arm=ARMS[(r+i)%6]) for r in range(6) for p,c in CELLS for i in range(6)]
    assert len(schedule)==576 and len({(x['round'],x['profile'],x['capacity'],x['arm']) for x in schedule})==576
    for p,c in CELLS:
        for arm in ARMS: assert sorted(x['position'] for x in schedule if x['profile']==p and x['capacity']==c and x['arm']==arm)==list(range(6))
    report['schedule']=schedule
    prepare_diagnostic_sources()
    report['source_and_harness_full_text']={str(p.relative_to(HERE)):p.read_text() for p in
        [HERE/'run.py',HERE/'PROTOCOL.md',HERE/'launcher_floor.c',HERE/'original_run.py',HERE/'boehm_adapter.c',HERE/'boehm_caller.h',
         *[HERE/arm/name for arm in ('baseline','candidate') for name in ('gc.c','gc.h','workload.c')]]}
    report['candidate_patch_text']=(FROZEN/'intrusive-minor-queue.patch').read_text()
    report['candidate_patch_sha256']=sha(FROZEN/'intrusive-minor-queue.patch')

def peak_inserted():
    return '''
  if (bytes > stats.peak_accounted_bytes)
    fprintf(stderr, "GC_PEAK {\\\"nursery\\\":%zu,\\\"pool\\\":%zu,\\\"large\\\":%zu,\\\"descriptor\\\":%zu,\\\"work\\\":%zu,\\\"remembered\\\":%zu,\\\"roots\\\":%zu,\\\"static\\\":%zu,\\\"extra\\\":%zu,\\\"peak\\\":%zu,\\\"minor_count\\\":%" PRIu64 ",\\\"major_count\\\":%" PRIu64 ",\\\"allocations\\\":%" PRIu64 "}\\n",
      gc_fast.capacity, stats.pool_reserved_bytes, stats.large_reserved_bytes, stats.descriptor_bytes,
      stats.work_queue_bytes, stats.remembered_queue_bytes, stats.root_bytes, static_metadata_bytes(),
      extra, bytes, stats.minor_count, stats.major_count, stats.allocations);
'''

def prepare_diagnostic_sources():
    for arm in ('custom-baseline','custom-intrusive'):
        source=HERE/('baseline' if arm=='custom-baseline' else 'candidate')
        directory=HERE/'diagnostics'/arm;directory.mkdir(parents=True,exist_ok=True)
        text=(source/'gc.c').read_text();anchor='  size_t bytes = accounted_bytes() + extra;'
        assert text.count(anchor)==1
        (directory/'gc.c').write_text(text.replace(anchor,anchor+peak_inserted()))
        shutil.copyfile(source/'gc.h',directory/'gc.h')

def peak_events(stderr,row):
    events=[]
    for line in stderr.splitlines():
        assert line.startswith('GC_PEAK '),line
        event=json.loads(line[len('GC_PEAK '):])
        assert event['peak']==sum(event[k] for k in ('nursery','pool','large','descriptor','work','remembered','roots','static','extra'))
        events.append(event)
    assert events and max(x['peak'] for x in events)==row['peak_accounted_bytes']
    assert all(a['peak']<b['peak'] for a,b in zip(events,events[1:]))
    return events

def identities(row,arm,profile,count,capacity):
    assert row['profile']==profile and row['count']==count
    assert row['checksum']==count*(count-1)//2
    assert row['allocations']==count+(profile=='mutation')
    assert row['elapsed_seconds']>0 and row['process_peak_rss_bytes']>0
    if arm.startswith('boehm'):
        assert row['exact_live_bytes'] is None and row['boehm_free_space_divisor']==1
        assert row['boehm_version_packed']==524808 and row['inline_available']==1
        return
    assert row['nursery_capacity_bytes']==capacity
    assert row['nursery_allocations']+row['direct_old_allocations']==row['allocations']
    assert row['nursery_payload_bytes']+row['direct_old_payload_bytes']==row['payload_bytes']
    assert row['allocation_header_bytes']==8*row['allocations']
    assert row['old_total_allocated_bytes']-row['reclaimed_bytes']==row['old_live_bytes']
    assert row['exact_live_payload_bytes']+8*row['old_object_count']==row['old_live_bytes']
    assert row['pool_allocations']-row['pool_releases']==row['pool_count']
    assert row['pool_reserved_bytes']>=row['old_slot_bytes']
    total=sum(row[k] for k in ('nursery_capacity_bytes','pool_reserved_bytes','large_reserved_bytes','descriptor_bytes','work_queue_bytes','remembered_queue_bytes','root_bytes','static_metadata_bytes'))
    assert row['accounted_bytes']==total and row['peak_accounted_bytes']>=total

def pair(base,cand):
    assert {k:v for k,v in base.items() if k not in VARIABLE}=={k:v for k,v in cand.items() if k not in VARIABLE}
    assert cand['static_metadata_bytes']-base['static_metadata_bytes']==8
    assert cand['work_queue_bytes']<=base['work_queue_bytes']
    assert cand['accounted_bytes']-base['accounted_bytes']==8+cand['work_queue_bytes']-base['work_queue_bytes']

def summary(rows,floors):
    cells=[]
    for profile,capacity in CELLS:
        grouped={a:[x for x in rows if x['profile']==profile and x['capacity']==capacity and x['arm']==a] for a in ARMS}
        byarm={a:dict(times=[x['row']['elapsed_seconds'] for x in xs],rss=[x['row']['process_peak_rss_bytes'] for x in xs],
                      time_median=statistics.median(x['row']['elapsed_seconds'] for x in xs),
                      rss_median=statistics.median(x['row']['process_peak_rss_bytes'] for x in xs)) for a,xs in grouped.items()}
        for a in ARMS:
            assert len(grouped[a])==6
            byarm[a]['time_range']=[min(byarm[a]['times']),max(byarm[a]['times'])]
            byarm[a]['rss_range']=[min(byarm[a]['rss']),max(byarm[a]['rss'])]
            memory_keys=('boehm_heap_bytes','boehm_heap_minus_free_bytes','boehm_total_allocated_bytes') if a.startswith('boehm') else ('accounted_bytes','peak_accounted_bytes','work_queue_bytes','static_metadata_bytes')
            byarm[a]['raw_memory_samples']={k:[x['row'][k] for x in grouped[a]] for k in memory_keys}
            byarm[a]['memory_medians']={k:statistics.median(v) for k,v in byarm[a]['raw_memory_samples'].items()}
            byarm[a]['collection_schedules']=[{k:x['row'].get(k) for k in ('minor_count','major_count','promoted_count','copied_bytes')} for x in grouped[a]]
        custom={a:{x['round']:x['row'] for x in grouped[a]} for a in ('custom-baseline','custom-intrusive')}
        ratios=[custom['custom-intrusive'][r]['elapsed_seconds']/custom['custom-baseline'][r]['elapsed_seconds'] for r in range(6)]
        floor=[x['rss_bytes'] for x in floors if x['profile']==profile and x['capacity']==capacity]
        assert len(floor)==6
        median=statistics.median(ratios)
        rssratio=byarm['custom-intrusive']['rss_median']/byarm['custom-baseline']['rss_median']
        above=byarm['custom-baseline']['rss_median']>=2*statistics.median(floor)
        paired={a:[custom['custom-intrusive'][r]['elapsed_seconds']/next(x['row']['elapsed_seconds'] for x in grouped[a] if x['round']==r) for r in range(6)] for a in ARMS if a!='custom-intrusive'}
        cells.append(dict(profile=profile,capacity=capacity,arms=byarm,paired_candidate_time_ratios=paired,
                          paired_custom_time_ratio_median=median,paired_custom_gain_count=sum(x<.95 for x in ratios),
                          paired_custom_regression_count=sum(x>1.05 for x in ratios),
                          candidate_baseline_ratio_of_time_medians=byarm['custom-intrusive']['time_median']/byarm['custom-baseline']['time_median'],
                          strongest_observed_Boehm=min((a for a in ARMS if a.startswith('boehm')),key=lambda a:byarm[a]['time_median']),
                          primary=(profile,capacity) in [('tree',262144),('tree',262136)],
                          primary_gain=median<.95 and sum(x<.95 for x in ratios)>=5,
                          repeatable_regression=median>1.05 and sum(x>1.05 for x in ratios)>=5,
                          total_RSS_ratio=rssratio,launcher_floor_rss=floor,RSS_materially_above_floor=above,
                          RSS_ratio_kind='ratio of median total process high-water RSS; never subtract floor',
                          RSS_regression=above and rssratio>1.10,RSS_interpretation='total RSS; no subtraction' if above else 'floor limited/inconclusive'))
    advance=all(x['primary_gain'] for x in cells if x['primary']) and not any(x['repeatable_regression'] for x in cells if not x['primary']) and not any(x['RSS_regression'] for x in cells)
    return {'cells':cells,'screen_advance':advance,'next_step':'held-out confirmation required; no default-selection authority' if advance else 'screen does not advance'}

def execute():
    compiler=Path(shutil.which('clang')).resolve()
    ENV['CC']=str(compiler)
    report['compiler_version']=command([compiler,'--version']).stdout
    spec=importlib.util.spec_from_file_location('unchanged_build_helper',HERE/'original_run.py')
    helper=importlib.util.module_from_spec(spec);spec.loader.exec_module(helper)
    helper.run=lambda argv,**kwargs:command(argv,kwargs.get('env',ENV))
    helper.boehm_config=lambda:report['boehm_config']
    paths=set(HERE.glob('*.py'))|set(HERE.glob('*.md'))|{HERE/'launcher_floor.c',compiler,Path(report['boehm_config']['boehm_archive']),FULL,QUALIFIED,FROZEN/'manifest.json',HERE/'runtime/medaka_rt.c'}
    paths.update(HERE/arm/name for arm in ('baseline','candidate') for name in ('gc.c','gc.h','workload.c'))
    paths.update((HERE/'boehm_adapter.c',HERE/'boehm_caller.h'))
    paths.update(HERE/'diagnostics'/arm/name for arm in ('custom-baseline','custom-intrusive') for name in ('gc.c','gc.h'))
    directories={k:HERE/'build'/k for k in KEYS}
    for k,d in directories.items():
        d.mkdir(parents=True,exist_ok=True)
        for name in ('boehm_adapter.c','boehm_caller.h'): shutil.copyfile(HERE/name,d/name);paths.add(d/name)
        source=HERE/('candidate' if k=='custom-intrusive' else 'baseline')
        for unit in (source/'gc.c',source/'workload.c',*([d/'boehm_adapter.c'] if k.startswith('boehm') else [])):
            flags=['-std=c11','-O2','-g','-Wall','-Wextra','-Werror','-I',str(d),*['-D'+x for x in DEFINES[k]]]
            if k.startswith('boehm'): flags+=['-DGC_THREADS','-pthread',*preprocess_flags(report['boehm_config']['flags'])]
            deps=command([compiler,*flags,'-M','-MT','deps',unit]).stdout
            for name in shlex.split(deps.replace('\\\n',' ').partition(':')[2]):
                path=Path(name.replace('$$','$'));paths.add((path if path.is_absolute() else REPO/path).resolve())
    deps=command([compiler,'-std=c11','-O2','-Wall','-Wextra','-Werror','-M','-MT','deps',HERE/'launcher_floor.c']).stdout
    for name in shlex.split(deps.replace('\\\n',' ').partition(':')[2]):
        path=Path(name.replace('$$','$'));paths.add((path if path.is_absolute() else REPO/path).resolve())
    for arm in ('custom-baseline','custom-intrusive'):
        deps=command([compiler,'-std=c11','-O2','-g','-Wall','-Wextra','-Werror',*['-D'+x for x in DEFINES[arm]],
                      '-M','-MT','deps',HERE/'diagnostics'/arm/'gc.c']).stdout
        for name in shlex.split(deps.replace('\\\n',' ').partition(':')[2]):
            path=Path(name.replace('$$','$'));paths.add((path if path.is_absolute() else REPO/path).resolve())
    frozen=lambda:{str(p):sha(p) for p in sorted(paths)}
    report['input_hashes_before']=frozen()
    oldcc=os.environ.get('CC');os.environ['CC']=str(compiler)
    binaries={}
    try:
        for k,d in directories.items():
            helper.HERE=HERE/('candidate' if k=='custom-intrusive' else 'baseline')
            binaries[k]=helper.build(d,k,DEFINES[k],boehm=k.startswith('boehm'))
    finally:
        if oldcc is None: os.environ.pop('CC',None)
        else: os.environ['CC']=oldcc
    report['build_commands']=helper.BUILD_COMMANDS
    floor=HERE/'build/launcher-floor'
    command([compiler,'-std=c11','-O2','-Wall','-Wextra','-Werror',HERE/'launcher_floor.c','-o',floor])
    binaries['launcher-floor']=floor
    for arm in ('custom-baseline','custom-intrusive'):
        d=HERE/'diagnostics'/arm
        source=HERE/('baseline' if arm=='custom-baseline' else 'candidate')
        binary=d/'workload'
        command([compiler,'-std=c11','-O2','-g','-Wall','-Wextra','-Werror',*['-D'+x for x in DEFINES[arm]],d/'gc.c',source/'workload.c','-o',binary])
        binaries['diagnostic-'+arm]=binary
    report['binary_hashes_before']={str(p):sha(p) for p in binaries.values()}
    assert frozen()==report['input_hashes_before']
    def row(arm,profile,count,capacity):
        result=json.loads(command([binaries[key(arm)],profile,str(count),str(capacity)],arm_env(arm)).stdout)
        identities(result,arm,profile,count,capacity);return result
    smoke=[]
    for profile in PROFILES:
        for arm in ARMS: smoke.append(dict(profile=profile,arm=arm,row=row(arm,profile,1024,240)))
        pair(smoke[-6]['row'],smoke[-5]['row'])
    report['smoke']=smoke
    for arm in ('custom-baseline','custom-intrusive'):
        cp=command([binaries['diagnostic-'+arm],'tree','1024','240'],diagnostic=True)
        result=json.loads(cp.stdout);identities(result,arm,'tree',1024,240)
        events=peak_events(cp.stderr,result)
        report['checks'].append(dict(kind='diagnostic-sanity-smoke',arm=arm,row=result,peak_event_count=len(events)))
    rows=[];floors=[]
    with (HERE/'results.jsonl').open('w') as output:
        for item in report['schedule']:
            if item['position']==0:
                rss=json.loads(command([floor]).stdout)['launcher_floor_rss_bytes']
                assert rss>0
                floors.append(dict(round=item['round'],profile=item['profile'],capacity=item['capacity'],rss_bytes=rss))
            result=row(item['arm'],item['profile'],COUNT,item['capacity'])
            record=dict(item,row=result,command=[str(binaries[key(item['arm'])]),item['profile'],str(COUNT),str(item['capacity'])],GC_environment={k:v for k,v in arm_env(item['arm']).items() if k.startswith('GC_')})
            rows.append(record);output.write(json.dumps(record)+'\n');output.flush()
            paired={x['arm']:x['row'] for x in rows if x['round']==item['round'] and x['profile']==item['profile'] and x['capacity']==item['capacity'] and x['arm'].startswith('custom')}
            if len(paired)==2: pair(paired['custom-baseline'],paired['custom-intrusive'])
            same=[x['row'] for x in rows if x['round']==item['round'] and x['profile']==item['profile'] and x['capacity']==item['capacity']]
            assert len({(x['allocations'],x['payload_bytes'],x['checksum']) for x in same})==1
    assert len(rows)==576
    report['launcher_floors']=floors
    report['summary']=summary(rows,floors)
    report['diagnostics']=diagnostics(binaries,rows)
    report['input_hashes_after']=frozen()
    report['binary_hashes_after']={str(p):sha(p) for p in binaries.values()}
    assert report['input_hashes_after']==report['input_hashes_before']
    assert report['binary_hashes_after']==report['binary_hashes_before']
    report['status']='completed screen; no default-selection authority'

def diagnostics(binaries,rows):
    receipt=[]
    for arm in ('custom-baseline','custom-intrusive'):
        source=HERE/('baseline' if arm=='custom-baseline' else 'candidate')
        directory=HERE/'diagnostics'/arm;directory.mkdir(parents=True,exist_ok=True)
        binary=binaries['diagnostic-'+arm]
        for profile,capacity in CELLS:
            cp=command([binary,profile,str(COUNT),str(capacity)],diagnostic=True)
            result=json.loads(cp.stdout);identities(result,arm,profile,COUNT,capacity)
            reference=next(x['row'] for x in rows if x['arm']==arm and x['profile']==profile and x['capacity']==capacity)
            assert {k:v for k,v in result.items() if k not in {'elapsed_seconds','preparation_seconds','process_peak_rss_bytes'}}=={k:v for k,v in reference.items() if k not in {'elapsed_seconds','preparation_seconds','process_peak_rss_bytes'}}
            events=peak_events(cp.stderr,result)
            log=directory/(profile+'-'+str(capacity)+'.peaks.log');log.write_text(cp.stderr)
            receipt.append(dict(arm=arm,profile=profile,capacity=capacity,row=result,event_count=len(events),final_peak_event=events[-1],peak_log_sha256=sha(log),source_sha256=sha(directory/'gc.c'),binary_sha256=sha(binary)))
    return receipt

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--execute',action='store_true');args=parser.parse_args()
    try:
        assert not (HERE/'results.jsonl').exists(),'preserve existing matrix; no resume or overwrite'
        prepare()
        if args.execute:
            report['status']='running; partial evidence not accepted';execute()
    except BaseException as error:
        report['status']='failed/partial; not accepted';report['error']=repr(error);raise
    finally:
        (HERE/('audit.json' if args.execute else 'preparation.json')).write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({'status':report['status'],'timed_rows':576 if args.execute else 0}))

if __name__=='__main__': main()
