# Intrusive minor queue screening packet

Source preparation only. Execution requires independent review and the parent's
explicit serialized CPU handoff. No repository source or default policy changes.

Baseline: exact 85c364304684c44c544957c8ba2b180d15d736c5. Candidate gc.c:
ffdc7cec188abec33fc9b9b147c4477b93097242f1555f980aee09724b7cfa0e.
Header and workload are byte-identical to 85. Only the minor pending-work queue
changes: copy the full payload, then borrow nursery field zero; pop before child
scan. Atomic objects still enqueue. Major and remembered queues and allocator
policy remain. The new static head costs 8 bytes.

Qualification: the full unchanged prototype runner passed all 10 backend
selftests and smokes, sanitizer/API/pool/adversarial/LLVM contracts and existing
negative controls. Independent fixtures passed 18 positives and 5 named safe
mutants, including the 17-object ledger (-504 bytes after minor, +8 after major).
LSan is disabled under ptrace; address and UB instrumentation remain active.
Qualification source hashes are frozen.

## Fixed matrix and comparator

All seven existing profiles use 5,000,000 inputs, matching the established whole
initialization and root-pair matrices: ephemeral, list, tree, mutation, atomic,
mixed and sizes. Each runs at 262144 and 262136 bytes. Additional tree cells run
at 16777216 and 16777208 bytes. No workload changes or added timed phase clocks.

Six rounds per cell, six arms per round, 576 timed fresh processes total. Every
arm visits every ordinal position once. Cell order is fixed; rotate arms by
round modulo six. No result-dependent skips, counts, repeats or added cells.
42 small smokes and 2 diagnostic sanity smokes precede timing. 96 independent
launcher floor probes accompany the matrix. 32 untimed diagnostics follow it,
using the same profiles, counts, capacities and collection phases.

Arms: custom baseline, custom intrusive, historical Boehm default/fixed 128 MiB,
and caller-inline Boehm default/fixed 128 MiB. Four timed binaries; each Boehm
binary serves both initial-heap cohorts. All use prepared layouts, inline
allocation and inline stores. Custom sources differ only in gc.c. Historical
Boehm uses USE_INLINE; caller Boehm uses USE_CALLER_INLINE; both use USE_BOEHM.
The exact 85 production adapter retains version/size guards, traced uncollectable
freelist heads, static libgc, GC_THREADS and pthread. Internal divisor is 1.
Clear all inherited GC_* variables; only fixed-128 cohorts set
GC_INITIAL_HEAP_SIZE=134217728. This is an initial size, not a maximum. Boehm
ignores nursery capacity; capacity labels pair its controls with custom cells.

Clang -O2 -g -std=c11 -Wall -Wextra -Werror; separate translation units, no LTO.
Sources, adapter, helper, compiler executable, static archive and actual
transitive headers are hashed before build, after build and after the matrix.
Binaries are hashed before/after. Keep commands, outputs, GC environment and
provenance. A failed oracle, stderr, timeout or input drift invalidates partial
evidence; no restart in this directory.

## Measurement and accounting

Use existing elapsed_seconds only: workload construction, checksum traversal,
final GC and root cleanup. It excludes process/CLI startup, heap initialization,
layout preparation and heap destruction. RSS is total process high-water,
including the launcher floor and allocator overhead; it is not exact live bytes.

Check all row identities. Compare every deterministic custom counter exactly
except static metadata, work queue, current accounted and peak accounted bytes.
Keep these four memory fields unchanged in raw output. Current difference:
candidate accounted minus baseline accounted equals 8 plus candidate work bytes
minus baseline work bytes.

An independently compiled minimal getrusage process records launcher/exec RSS
floor once per cell per round, immediately before its six arms. It performs no GC
or workload. Keep all six floor receipts per cell. Never subtract the floor from
RSS or time. A cell is materially above the floor only when baseline RSS median
is at least twice its floor RSS median. Lower cells are inconclusive for RSS;
retain their raw total RSS and exact collector accounting.

Untimed diagnostics emit component sums at each new accounted peak from copied
collector sources. They add no GC or workload phase and no global collector
bookkeeping. Each receipt independently sums nursery, pools, large objects,
descriptors, major queue, remembered queue, roots, static storage and transient
old-plus-new allocation storage. The maximum receipt must equal the reported
peak. Diagnostic rows must equal timed deterministic rows, including all four
memory fields. Preserve raw peak logs/hashes and final events explaining paired
peak differences. Diagnostic IO costs affect no measured time or RSS claim.

## Predeclared screening rules

Advance only if BOTH 256 KiB tree cells have median paired candidate/baseline
time ratio < .95 AND at least 5 of 6 paired ratios < .95. Reject for repeatable
regression in ANY other cell: median paired ratio > 1.05 AND at least 5 of 6
paired ratios > 1.05. Controls comprise all 12 non-tree 256 KiB cells and both
16 MiB tree cells.

In any materially-above-floor cell, reject if candidate total RSS median divided
by baseline total RSS median > 1.10. Lower RSS cells are inconclusive, preventing
a broad memory approval claim. No subtraction or RSS normalization.

Keep all six arm medians/ranges and all paired ratios visible. Identify the
strongest observed Boehm median per cell and retain every Boehm cohort. The
16 MiB tree cells are secondary controls. A screen advance requires independent
held-out confirmation and authorizes no implementation or default selection.
This synthetic matrix provides no application or production-collector speedup
claim.
