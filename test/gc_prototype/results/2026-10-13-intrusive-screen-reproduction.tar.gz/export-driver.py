import gzip
import hashlib
import io
import json
from pathlib import Path
import shutil
import tarfile

ROOT=Path('/root/.codex/worktrees/f396/medaka')
OUT=Path(__file__).resolve().parent
SCREEN=Path('/tmp/medaka-intrusive-screen-85')
FROZEN=Path('/tmp/medaka-intrusive-promotion-85')
FULL=Path('/tmp/medaka-intrusive-full-correctness-85')
RESULTS=ROOT/'test/gc_prototype/results'
PREFIX='2026-10-13-intrusive-screen'
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
audit=json.loads((SCREEN/'audit.json').read_text())
assert audit['status']=='completed screen; no default-selection authority'
assert audit['summary']['screen_advance'] is False
members={}
def member(name,path):
    data=path.read_bytes()
    if name in members: assert members[name][0]==data
    else: members[name]=(data,path)
for path in SCREEN.rglob('*'):
    if path.is_file() and path.name not in ('audit.json','results.jsonl'):
        member('screen/'+str(path.relative_to(SCREEN)),path)
for arm in ('baseline','candidate'):
    for path in (FROZEN/arm).glob('*'): member('collector/'+arm+'/'+path.name,path)
for name in ('manifest.json','intrusive-minor-queue.patch','validation-plan.md'):
    member('collector/'+name,FROZEN/name)
for name in ('fixture.c','run.py'):
    member('independent-fixture/'+name,FROZEN/'verification'/name)
member('independent-fixture/verification.json',FROZEN/'verification/run-5ce01f64/verification.json')
for path in FULL.rglob('*'):
    if path.is_file(): member('full-correctness/'+str(path.relative_to(FULL)),path)
for path in (Path('/tmp/pool-review-intrusive-audit.py'),Path('/tmp/pool-review-intrusive-audit.json')):
    member('independent-artifact/'+path.name,path)
compiler='/usr/lib/llvm-19/bin/clang'
for name,digest in audit['input_hashes_before'].items():
    path=Path(name)
    assert sha(path)==digest
    if name==compiler: continue
    if not any(path==original for _,original in members.values()):
        member('input-snapshots/'+name.lstrip('/'),path)
member('export-driver.py',Path(__file__))
archive=OUT/(PREFIX+'-reproduction.tar.gz')
with archive.open('wb') as raw:
    with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0) as zipped:
        with tarfile.open(fileobj=zipped,mode='w',format=tarfile.GNU_FORMAT) as tar:
            for name,(data,path) in sorted(members.items()):
                entry=tarfile.TarInfo(name);entry.size=len(data);entry.mtime=0
                entry.uid=entry.gid=0;entry.uname=entry.gname=''
                entry.mode=0o755 if path.stat().st_mode & 0o111 else 0o644
                tar.addfile(entry,io.BytesIO(data))
with tarfile.open(archive,'r:gz') as tar:
    for name,(data,_) in members.items(): assert tar.extractfile(name).read()==data
copies={PREFIX+'-results.jsonl':SCREEN/'results.jsonl',PREFIX+'-audit.json':SCREEN/'audit.json',
        PREFIX+'-independent-audit.json':Path('/tmp/pool-review-intrusive-audit.json')}
manifest={'status':'completed rejected screen; independently audited; exported without changing original raw evidence',
          'historical_protocol_annotation':'Source preparation only remains verbatim in frozen protocol. Actual execution completed exit0 at workspace e2ef41974; collector source base is exact85. This annotation changes no historical source evidence.',
          'rows':576,'floor_receipts':96,'peak_ledger_runs':32,'peak_events':134704,
          'independent_fixture_counts':{'positive':18,'named_safe_mutants':5},
          'full_correctness':'unchanged runner passed all10backends,prepared/pool/adversarial/LLVM contracts; memory+UB active,LSan disabled under ptrace',
          'frozen_decision':audit['summary'],'compiler_external_reference':{'path':compiler,'sha256':audit['input_hashes_before'][compiler],'version':audit['compiler_version'],'redistributed':False},
          'limits':'Source/build/proof reconstruction bundle, not a complete host replay image; no installation, default-selection, held-out confirmation, or application speedup claim.',
          'durable_files':{},'archive_members':{name:{'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data),'original_path':str(path)} for name,(data,path) in sorted(members.items())}}
for name,path in copies.items():
    shutil.copyfile(path,OUT/name)
    manifest['durable_files'][name]={'sha256':sha(path),'bytes':path.stat().st_size,'original_path':str(path),'copy':'byte-for-byte'}
manifest['durable_files'][archive.name]={'sha256':sha(archive),'bytes':archive.stat().st_size,'format':'deterministic gzip/tar; every decoded member verified byte-for-byte'}
(OUT/(PREFIX+'-export.json')).write_text(json.dumps(manifest,indent=2)+'\n')
for path in OUT.glob(PREFIX+'-*'):
    assert not (RESULTS/path.name).exists(),path.name
    shutil.copyfile(path,RESULTS/path.name)
    assert sha(path)==sha(RESULTS/path.name)
print(json.dumps({'files':{p.name:{'bytes':p.stat().st_size,'sha256':sha(p)} for p in RESULTS.glob(PREFIX+'-*')},'archived_members':len(members)}))
