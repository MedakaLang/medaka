#!/usr/bin/env python3
"""Build/run independent intrusive-promotion fixtures; --execute is mandatory."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
HERE = Path(__file__).resolve().parent
MANIFEST = ROOT / "manifest.json"
FIXTURE = HERE / "fixture.c"
POSITIVE_CASES = ("alias", "chain", "payload", "raw-copy", "lifecycle",
                  "forwarded-alias", "root-control", "barrier-control", "ledger")
COUNTER_KEYS = (
    "allocations", "payload_bytes", "allocation_header_bytes", "nursery_header_bytes",
    "old_header_bytes", "nursery_capacity_bytes", "minor_count", "major_count",
    "copied_bytes", "copied_payload_bytes", "promoted_count", "reclaimed_bytes",
    "old_live_bytes", "peak_old_bytes", "nursery_used_bytes", "old_total_allocated_bytes",
    "peak_root_bytes", "exact_live_bytes", "nursery_allocations", "nursery_payload_bytes",
    "direct_old_allocations", "direct_old_payload_bytes", "old_slot_bytes",
    "pool_reserved_bytes", "peak_pool_reserved_bytes", "pool_count", "pool_allocations",
    "pool_releases", "pooled_allocations", "pool_reused_slots", "pool_padding_bytes",
    "large_reserved_bytes", "large_metadata_bytes", "large_object_count", "descriptor_bytes",
    "descriptor_count", "remembered_queue_bytes", "exact_live_payload_bytes", "root_bytes",
    "old_object_count",
)


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def source_set() -> dict[str, dict[str, str]]:
    manifest = json.loads(MANIFEST.read_text())
    got = {}
    for arm in ("baseline", "candidate"):
        got[arm] = {}
        for name, expected in manifest["source_sha256"][arm].items():
            path = ROOT / arm / name
            actual = sha(path.read_bytes())
            if actual != expected:
                raise SystemExit(f"frozen input drift: {path}: {actual} != {expected}")
            got[arm][name] = actual
    return got


def replace_once(source: str, old: str, new: str, label: str) -> str:
    n = source.count(old)
    if n != 1:
        raise RuntimeError(f"mutation {label}: wanted one source anchor, found {n}")
    return source.replace(old, new, 1)


def mutation_sources(candidate: str) -> dict[str, tuple[str, str]]:
    delayed_anchor = "    promotion_todo = next; scan_promote(header(to));"
    delayed = replace_once(candidate, delayed_anchor,
                           "    scan_promote(header(to)); promotion_todo = next;",
                           "delayed-pop")
    forwarding = replace_once(candidate,
        "  if (from->info & FORWARDED) return from->info & ~(uintptr_t)7;",
        "  if (from->info & FORWARDED) return word;", "forwarded-return")
    copy_before_borrow = replace_once(candidate,
        "  Header *to = new_old(from->info, from);\n"
        "  from->info = payload(to) | FORWARDED;\n"
        "  /* The complete old payload is copied before borrowing nursery field zero. */\n"
        "  ((Word *)word)[0] = promotion_todo; promotion_todo = word;",
        "  /* Deliberately borrow field zero before the full copy. */\n"
        "  ((Word *)word)[0] = promotion_todo; promotion_todo = word;\n"
        "  Header *to = new_old(from->info, from);\n"
        "  from->info = payload(to) | FORWARDED;", "copy-before-borrow")
    return {
        "delayed-pop": (delayed, "chain"),
        "forwarded-return": (forwarding, "forwarded-alias"),
        "copy-before-borrow": (copy_before_borrow, "raw-copy"),
    }


def build(cc: str, gc_text: str, arm_dir: Path, output: Path,
         define: str | None = None) -> dict:
    arm_dir.mkdir(parents=True, exist_ok=True)
    gc_copy = arm_dir / "gc.c"
    gc_copy.write_text(gc_text)
    exe = arm_dir / "fixture"
    command = [cc, "-std=c11", "-O1", "-g", "-fno-omit-frame-pointer",
               "-fsanitize=address,undefined", "-fno-sanitize-recover=all",
               "-I", str(ROOT / "candidate"), str(FIXTURE), str(gc_copy), "-o", str(exe)]
    if define:
        command.insert(1, f"-D{define}")
    attempts = []
    cp = subprocess.run(command, text=True, stdout=subprocess.PIPE,
                        stderr=subprocess.PIPE, timeout=60)
    attempts.append({"command": command, "returncode": cp.returncode,
                     "stdout": cp.stdout, "stderr": cp.stderr})
    if cp.returncode and ("libclang_rt.asan" in cp.stderr
                          or "libclang_rt.ubsan" in cp.stderr):
        fallback = [cc, "-fno-sanitize-link-runtime", "-Wl,--no-as-needed",
                    "-lasan", "-lubsan", "-Wl,--as-needed", *command[1:]]
        cp = subprocess.run(fallback, text=True, stdout=subprocess.PIPE,
                            stderr=subprocess.PIPE, timeout=60)
        attempts.append({"command": fallback, "returncode": cp.returncode,
                         "stdout": cp.stdout, "stderr": cp.stderr})
    if cp.returncode:
        raise RuntimeError(f"build failed ({cp.returncode}): {' '.join(attempts[-1]['command'])}\n{cp.stderr}")
    return {"command": command, "binary": str(exe), "binary_sha256": sha(exe.read_bytes()),
            "gc_source_sha256": sha(gc_copy.read_bytes()), "stderr": cp.stderr,
            "build_attempts": attempts}


def run_case(exe: Path, case: str, expected_status: int = 0,
             expected_marker: str | None = None) -> dict:
    env = os.environ.copy()
    env.pop("ASAN_OPTIONS", None)
    env["ASAN_OPTIONS"] = "detect_leaks=0:abort_on_error=1"
    env["UBSAN_OPTIONS"] = "halt_on_error=1:print_stacktrace=1"
    command = [str(exe), case]
    started = time.monotonic_ns()
    try:
        cp = subprocess.run(command, text=True, stdout=subprocess.PIPE,
                            stderr=subprocess.PIPE, env=env, timeout=8)
    except subprocess.TimeoutExpired as exc:
        raise RuntimeError(f"fixture timeout: {command}: {exc}") from exc
    elapsed = time.monotonic_ns() - started
    if cp.returncode != expected_status:
        raise RuntimeError(f"fixture return {cp.returncode}, wanted {expected_status}: {command}\n"
                           f"stdout={cp.stdout}\nstderr={cp.stderr}")
    if expected_marker:
        if cp.stderr.strip() != f"FIXTURE_FAIL {expected_marker}":
            raise RuntimeError(f"mutant did not fail only at oracle {expected_marker!r}: "
                               f"stdout={cp.stdout!r} stderr={cp.stderr!r}")
        if any(s in cp.stderr for s in ("AddressSanitizer", "UndefinedBehaviorSanitizer", "runtime error:")):
            raise RuntimeError(f"sanitizer failure is not an accepted mutation oracle: {cp.stderr}")
    elif cp.stderr:
        raise RuntimeError(f"positive fixture wrote stderr: {command}\n{cp.stderr}")
    return {"command": command, "returncode": cp.returncode,
            "stdout": cp.stdout, "stderr": cp.stderr,
            "elapsed_ns": elapsed, "stdout_sha256": sha(cp.stdout.encode()),
            "stderr_sha256": sha(cp.stderr.encode())}


def snapshots(stdout: str) -> dict[str, dict]:
    found = {}
    for line in stdout.splitlines():
        if not line.startswith('{'):
            continue
        row = json.loads(line)
        found[row["stage"]] = row
    return found


def ledger_checks(base: dict, cand: dict) -> None:
    if set(base) != {"after-minor", "after-major"} or set(cand) != set(base):
        raise RuntimeError(f"missing ledger snapshots: baseline={set(base)} candidate={set(cand)}")
    for stage in base:
        for key in COUNTER_KEYS:
            if base[stage].get(key) != cand[stage].get(key):
                raise RuntimeError(f"ledger counter mismatch {stage}.{key}: "
                                   f"{base[stage].get(key)} != {cand[stage].get(key)}")
        if cand[stage]["static_metadata_bytes"] - base[stage]["static_metadata_bytes"] != 8:
            raise RuntimeError(f"ledger static metadata delta is not +8 at {stage}")
        if cand[stage]["accounted_bytes"] - base[stage]["accounted_bytes"] != (
                8 + cand[stage]["work_queue_bytes"] - base[stage]["work_queue_bytes"]):
            raise RuntimeError(f"ledger accounted identity failed at {stage}")
    minor_b, minor_c = base["after-minor"], cand["after-minor"]
    major_b, major_c = base["after-major"], cand["after-major"]
    if minor_b["work_queue_bytes"] != 64 * 8 or minor_c["work_queue_bytes"] != 0:
        raise RuntimeError("ledger minor work queue capacities differ from 64-vs-0 expected")
    if minor_c["accounted_bytes"] - minor_b["accounted_bytes"] != -504:
        raise RuntimeError("ledger after-minor accounted delta is not -504")
    if minor_c["peak_accounted_bytes"] - minor_b["peak_accounted_bytes"] != -504:
        raise RuntimeError("ledger after-minor peak-accounted delta is not -504")
    if major_b["work_queue_bytes"] != 64 * 8 or major_c["work_queue_bytes"] != 64 * 8:
        raise RuntimeError("ledger major work queue capacities are not 64 in both arms")
    if major_c["accounted_bytes"] - major_b["accounted_bytes"] != 8:
        raise RuntimeError("ledger after-major accounted delta is not +8")
    if major_c["peak_accounted_bytes"] - major_b["peak_accounted_bytes"] != 8:
        raise RuntimeError("ledger after-major peak-accounted delta is not +8")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--execute", action="store_true", help="compile and run sanitizer fixtures")
    parser.add_argument("--output", type=Path, default=HERE / "out")
    args = parser.parse_args()
    inputs = source_set()
    fixture_hash = sha(FIXTURE.read_bytes())
    candidate_text = (ROOT / "candidate/gc.c").read_text()
    mutations = mutation_sources(candidate_text)
    plan = {"source_hashes": inputs, "fixture_sha256": fixture_hash,
            "runner_sha256": sha(Path(__file__).read_bytes()),
            "compiler": shutil.which("clang"), "positive_cases": POSITIVE_CASES,
            "sanitizer_policy": {"ASAN_OPTIONS": "detect_leaks=0:abort_on_error=1",
                                 "UBSAN_OPTIONS": "halt_on_error=1:print_stacktrace=1"},
            "mutations": {name: {"gc_source_sha256": sha(text.encode()), "case": case}
                          for name, (text, case) in mutations.items()},
            "ledger_invariants": ["all deterministic logical counters match",
                "minor work queue baseline512/candidate0; accounted and peak delta -504",
                "major work queue both512; accounted and peak delta +8", "static metadata delta +8"]}
    if not args.execute:
        print(json.dumps({"prepared": True, "execution_performed": False, **plan}, indent=2))
        return 0
    if args.output.exists() and any(args.output.iterdir()):
        raise SystemExit(f"refusing nonempty output directory: {args.output}")
    args.output.mkdir(parents=True, exist_ok=True)
    cc = shutil.which("clang")
    if not cc:
        raise SystemExit("clang not found")
    records = {"plan": plan, "execution_performed": True, "clang": cc, "builds": {}, "runs": []}
    for arm in ("baseline", "candidate"):
        gc_text = (ROOT / arm / "gc.c").read_text()
        built = build(cc, gc_text, args.output / arm, args.output)
        records["builds"][arm] = built
        for case in POSITIVE_CASES:
            records["runs"].append({"arm": arm, **run_case(Path(built["binary"]), case)})
    base_ledger = snapshots(next(r["stdout"] for r in records["runs"]
                                 if r["arm"] == "baseline" and r["command"][1] == "ledger"))
    cand_ledger = snapshots(next(r["stdout"] for r in records["runs"]
                                 if r["arm"] == "candidate" and r["command"][1] == "ledger"))
    ledger_checks(base_ledger, cand_ledger)
    records["ledger_snapshots"] = {"baseline": base_ledger, "candidate": cand_ledger}

    mutated = mutation_sources(candidate_text)
    expected = {
        "delayed-pop": "chain-grandchild-not-scanned",
        "forwarded-return": "forwarded-alias-root-stale",
        "copy-before-borrow": "borrowed-copy-payload-corrupt",
    }
    for name, (text, case) in mutated.items():
        built = build(cc, text, args.output / f"mutant-{name}", args.output)
        records["builds"][f"mutant-{name}"] = built
        records["runs"].append({"arm": f"mutant-{name}", **run_case(
            Path(built["binary"]), case, 86, expected[name])})
    for name, macro, case, marker in (
            ("roots", "GC_MUTATE_ROOTS", "root-control", "root-slot-not-relocated"),
            ("barrier", "GC_MUTATE_BARRIER", "barrier-control", "old-to-young-edge-not-remembered")):
        built = build(cc, candidate_text, args.output / f"mutant-{name}", args.output, macro)
        records["builds"][f"mutant-{name}"] = built
        records["runs"].append({"arm": f"mutant-{name}", **run_case(
            Path(built["binary"]), case, 86, marker)})
    final_inputs = source_set()
    if final_inputs != inputs or sha(FIXTURE.read_bytes()) != fixture_hash:
        raise RuntimeError("frozen source/fixture changed during execution")
    output = args.output / "verification.json"
    output.write_text(json.dumps(records, sort_keys=True, indent=2) + "\n")
    print(output)
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as exc:
        print(f"verification runner error: {exc}", file=sys.stderr)
        raise
