#define _POSIX_C_SOURCE 200809L
#include "gc.h"
#include <inttypes.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static uintptr_t nursery_base;
static size_t nursery_capacity;

static _Noreturn void fail(const char *name) {
  fprintf(stderr, "FIXTURE_FAIL %s\n", name);
  fflush(stderr);
  _Exit(86);
}
#define NEED(c, name) do { if (!(c)) fail(name); } while (0)

static int in_full_nursery(Word word) {
  return word && !(word & 1) && word >= nursery_base
      && word - nursery_base < nursery_capacity;
}
static Word checked_edge(Word owner, size_t index, const char *name) {
  Word child = load(owner, index);
  if (in_full_nursery(child)) fail(name);
  if (!child || (child & 1)) fail("expected-relocated-pointer");
  return child;
}
static void checked_root(Word word, const char *name) {
  if (in_full_nursery(word)) fail(name);
  if (!word || (word & 1)) fail("expected-relocated-root");
}
static GcLayout layout(size_t words, uint64_t mask) {
  return prepare_layout(words, mask);
}
static Word fresh(GcLayout l) { return allocate_prepared(l); }
static void start_heap(size_t bytes) {
  heap_init(bytes);
  nursery_base = (uintptr_t)gc_fast.nursery;
  nursery_capacity = gc_fast.capacity;
}
static void finish_heap(const char *name) {
  NEED(stats.root_bytes == 0, "unbalanced-fixture-roots");
  heap_destroy();
  printf("FIXTURE_OK %s\n", name);
}
static void print_snapshot(const char *stage) {
  printf("{\"stage\":\"%s\",", stage);
  print_stats();
  puts("}");
}

static void case_alias_cycles(void) {
  start_heap(4096);
  GcLayout self_layout = layout(1, UINT64_C(1));
  GcLayout node_layout = layout(3, UINT64_C(6));
  Word self = fresh(self_layout);
  ((Word *)self)[0] = self;

  Word leaf = fresh(node_layout), left = fresh(node_layout);
  Word right = fresh(node_layout), diamond = fresh(node_layout);
  ((Word *)leaf)[0] = integer(104);
  ((Word *)left)[0] = integer(102);
  ((Word *)right)[0] = integer(103);
  ((Word *)diamond)[0] = integer(101);
  store_prepared(node_layout, left, 1, leaf);
  store_prepared(node_layout, right, 1, leaf);
  store_prepared(node_layout, diamond, 1, left);
  store_prepared(node_layout, diamond, 2, right);

  Word cycle_a = fresh(node_layout), cycle_b = fresh(node_layout);
  ((Word *)cycle_a)[0] = integer(105);
  ((Word *)cycle_b)[0] = integer(106);
  store_prepared(node_layout, cycle_a, 1, cycle_b);
  store_prepared(node_layout, cycle_b, 1, cycle_a);

  Word alias_a = self, alias_b = self;
  Root ra, rb, rd, rc;
  root_push(&ra, &alias_a); root_push(&rb, &alias_b);
  root_push(&rd, &diamond); root_push(&rc, &cycle_a);
  minor_collect();
  checked_root(alias_a, "alias-root-a-not-relocated");
  checked_root(alias_b, "alias-root-b-not-relocated");
  checked_root(diamond, "diamond-root-not-relocated");
  checked_root(cycle_a, "cycle-root-not-relocated");
  NEED(alias_a == alias_b, "aliased-roots-diverged");
  NEED(checked_edge(alias_a, 0, "self-cycle-edge-stale") == alias_a,
       "one-word-self-cycle-broken");

  Word moved_left = checked_edge(diamond, 1, "diamond-left-stale");
  Word moved_right = checked_edge(diamond, 2, "diamond-right-stale");
  NEED(moved_left != moved_right, "diamond-children-aliased");
  NEED(unbox(load(diamond, 0)) == 101, "diamond-root-data-corrupt");
  NEED(unbox(load(moved_left, 0)) == 102, "diamond-left-data-corrupt");
  NEED(unbox(load(moved_right, 0)) == 103, "diamond-right-data-corrupt");
  NEED(checked_edge(moved_left, 1, "diamond-left-leaf-stale")
       == checked_edge(moved_right, 1, "diamond-right-leaf-stale"),
       "diamond-sharing-lost");
  Word moved_cycle_b = checked_edge(cycle_a, 1, "multi-cycle-forward-stale");
  NEED(unbox(load(moved_cycle_b, 0)) == 106, "multi-cycle-data-corrupt");
  NEED(checked_edge(moved_cycle_b, 1, "multi-cycle-back-stale") == cycle_a,
       "multiword-cycle-broken");
  NEED(stats.promoted_count == 7, "alias-cycle-promotion-count");
  NEED(stats.old_object_count == 7, "alias-cycle-old-object-count");
  root_pop(&rc); root_pop(&rd); root_pop(&rb); root_pop(&ra);
  finish_heap("alias-cycles");
}

static void case_chain(void) {
  start_heap(4096);
  GcLayout l = layout(3, UINT64_C(6));
  Word owner = fresh(l); ((Word *)owner)[0] = integer(201);
  Root ro; root_push(&ro, &owner);
  minor_collect();
  checked_root(owner, "remembered-owner-root-not-relocated");

  Word a = fresh(l), b = fresh(l), c = fresh(l);
  ((Word *)a)[0] = integer(202); ((Word *)b)[0] = integer(203);
  ((Word *)c)[0] = integer(204);
  store_prepared(l, a, 1, b); store_prepared(l, b, 1, c);
  store_prepared(l, owner, 1, a);
  NEED(stats.remembered_queue_bytes > 0, "old-owner-not-remembered");
  minor_collect();

  checked_root(owner, "remembered-owner-root-not-relocated");
  Word moved_a = checked_edge(owner, 1, "remembered-owner-edge-not-relocated");
  NEED(unbox(load(moved_a, 0)) == 202, "chain-level-one-data-corrupt");
  Word moved_b = checked_edge(moved_a, 1, "chain-child-not-scanned");
  NEED(unbox(load(moved_b, 0)) == 203, "chain-level-two-data-corrupt");
  Word moved_c = checked_edge(moved_b, 1, "chain-grandchild-not-scanned");
  NEED(unbox(load(moved_c, 0)) == 204, "chain-level-three-data-corrupt");
  NEED(stats.promoted_count == 4, "remembered-chain-promotion-count");
  root_pop(&ro);
  finish_heap("remembered-chain");
}

static void case_payload(void) {
  start_heap(4096);
  GcLayout atomic_one = layout(1, 0);
  GcLayout raw_three = layout(3, 0);
  GcLayout bit63 = layout(70, UINT64_C(1) << 63);
  Word atom = fresh(atomic_one);
  ((Word *)atom)[0] = UINT64_C(0x02030405060708a0);
  Word raw = fresh(raw_three), raw_odd = fresh(raw_three);
  ((Word *)raw)[0] = UINT64_C(0x1020304050607080);
  ((Word *)raw)[1] = 0;
  ((Word *)raw)[2] = UINT64_C(0xfedcba9876543210);
  ((Word *)raw_odd)[0] = integer(777);
  ((Word *)raw_odd)[1] = UINT64_C(0x123456789abcdef0);
  ((Word *)raw_odd)[2] = 0;
  Word wide = fresh(bit63), child = fresh(atomic_one);
  ((Word *)child)[0] = UINT64_C(0x8877665544332210);
  Word raw_words[70];
  for (size_t i = 0; i < 70; ++i) {
    raw_words[i] = UINT64_C(0xa001000000000000) + (Word)i * 0x101;
    ((Word *)wide)[i] = raw_words[i];
  }
  store_prepared(bit63, wide, 63, child);
  Word atom_root = atom, raw_root = raw, odd_root = raw_odd, wide_root = wide;
  Root ra, rr, ro, rw; root_push(&ra, &atom_root); root_push(&rr, &raw_root);
  root_push(&ro, &odd_root); root_push(&rw, &wide_root);
  minor_collect();
  checked_root(atom_root, "atomic-root-not-relocated");
  checked_root(raw_root, "raw-root-not-relocated");
  checked_root(odd_root, "odd-raw-root-not-relocated");
  checked_root(wide_root, "bit63-root-not-relocated");
  NEED(((Word *)atom_root)[0] == UINT64_C(0x02030405060708a0),
       "atomic-one-word-payload-corrupt");
  NEED(((Word *)raw_root)[0] == UINT64_C(0x1020304050607080)
       && ((Word *)raw_root)[1] == 0
       && ((Word *)raw_root)[2] == UINT64_C(0xfedcba9876543210),
       "raw-field-zero-payload-corrupt");
  NEED(((Word *)odd_root)[0] == integer(777)
       && ((Word *)odd_root)[1] == UINT64_C(0x123456789abcdef0)
       && ((Word *)odd_root)[2] == 0, "raw-odd-field-zero-payload-corrupt");
  Word moved_child = checked_edge(wide_root, 63, "bit63-child-not-relocated");
  NEED(((Word *)moved_child)[0] == UINT64_C(0x8877665544332210),
       "bit63-child-payload-corrupt");
  for (size_t i = 0; i < 70; ++i)
    if (i != 63) NEED(((Word *)wide_root)[i] == raw_words[i],
                      i < 64 ? "bit63-neighbor-payload-corrupt"
                             : "tail-after-bit63-payload-corrupt");
  root_pop(&rw); root_pop(&ro); root_pop(&rr); root_pop(&ra);
  finish_heap("payload");
}

static void case_raw_copy(void) {
  start_heap(256);
  GcLayout raw = layout(3, 0);
  Word object = fresh(raw);
  ((Word *)object)[0] = UINT64_C(0xe0d0c0b0a0908070);
  ((Word *)object)[1] = 0;
  ((Word *)object)[2] = UINT64_C(0x0102030405060708);
  Word expected[3] = {((Word *)object)[0], ((Word *)object)[1],
                      ((Word *)object)[2]};
  Root root; root_push(&root, &object);
  minor_collect();
  checked_root(object, "raw-copy-root-not-relocated");
  for (size_t i = 0; i < 3; ++i)
    if (((Word *)object)[i] != expected[i]) fail("borrowed-copy-payload-corrupt");
  root_pop(&root);
  finish_heap("raw-copy");
}

static void case_forwarded_alias(void) {
  start_heap(256);
  GcLayout atomic = layout(1, 0);
  Word object = fresh(atomic);
  ((Word *)object)[0] = UINT64_C(0xa1b2c3d4e5f60780);
  Word first = object, second = object;
  Root rfirst, rsecond;
  root_push(&rfirst, &first); root_push(&rsecond, &second);
  minor_collect();
  checked_root(first, "forwarded-alias-root-stale");
  checked_root(second, "forwarded-alias-root-stale");
  NEED(first == second, "forwarded-alias-diverged");
  NEED(((Word *)first)[0] == UINT64_C(0xa1b2c3d4e5f60780),
       "forwarded-alias-payload-corrupt");
  root_pop(&rsecond); root_pop(&rfirst);
  finish_heap("forwarded-alias");
}

static void case_root_mutation(void) {
  start_heap(256);
  GcLayout l = layout(3, UINT64_C(6));
  Word object = fresh(l); ((Word *)object)[0] = integer(301);
  Root root; root_push(&root, &object);
  minor_collect();
  checked_root(object, "root-slot-not-relocated");
  NEED(unbox(load(object, 0)) == 301, "root-control-data-corrupt");
  root_pop(&root);
  finish_heap("root-control");
}

static void case_barrier_mutation(void) {
  start_heap(512);
  GcLayout l = layout(3, UINT64_C(6));
  Word owner = fresh(l); ((Word *)owner)[0] = integer(311);
  Root root; root_push(&root, &owner); minor_collect();
  checked_root(owner, "barrier-owner-root-not-relocated");
  Word child = fresh(l); ((Word *)child)[0] = integer(312);
  store_prepared(l, owner, 1, child);
  minor_collect();
  checked_root(owner, "barrier-owner-root-not-relocated");
  Word moved = checked_edge(owner, 1, "old-to-young-edge-not-remembered");
  NEED(unbox(load(moved, 0)) == 312, "barrier-control-data-corrupt");
  root_pop(&root);
  finish_heap("barrier-control");
}

static void case_lifecycle(void) {
  uintptr_t before;
  start_heap(32);
  before = gc_heap_epoch;
  GcLayout l = layout(3, UINT64_C(6));
  Word a = fresh(l); ((Word *)a)[0] = integer(401);
  Root ra; root_push(&ra, &a);
  /* The second exact-capacity object forces a minor and must reload a. */
  Word b = fresh(l); ((Word *)b)[0] = integer(402);
  Root rb; root_push(&rb, &b);
  checked_root(a, "tiny-capacity-first-root-stale");
  NEED(in_full_nursery(b), "tiny-capacity-second-not-young-before-minor");
  store_prepared(l, a, 1, b);
  minor_collect();
  checked_root(a, "tiny-capacity-first-root-stale");
  Word moved_b = checked_edge(a, 1, "tiny-capacity-old-to-young-edge-stale");
  NEED(unbox(load(a, 0)) == 401 && unbox(load(moved_b, 0)) == 402,
       "tiny-capacity-content-corrupt");
  major_collect();
  checked_root(a, "major-after-minor-root-stale");
  moved_b = checked_edge(a, 1, "major-after-minor-edge-stale");
  NEED(unbox(load(a, 0)) == 401 && unbox(load(moved_b, 0)) == 402,
       "major-after-minor-content-corrupt");
  root_pop(&rb); root_pop(&ra);
  heap_destroy();
  NEED(gc_fast.nursery == NULL, "destroy-left-nursery");
  start_heap(64);
  NEED(gc_heap_epoch == before + 1, "heap-epoch-did-not-advance");
  l = layout(1, 0);
  Word fresh_after = fresh(l); ((Word *)fresh_after)[0] = UINT64_C(0xfaceb00c);
  Root rf; root_push(&rf, &fresh_after); minor_collect();
  checked_root(fresh_after, "reinitialized-heap-root-stale");
  NEED(((Word *)fresh_after)[0] == UINT64_C(0xfaceb00c),
       "reinitialized-heap-payload-corrupt");
  root_pop(&rf);
  finish_heap("lifecycle");

  start_heap(32);
  GcLayout direct = layout(4, 0); /* 8-byte header + 32-byte payload. */
  Word old = fresh(direct);
  NEED(!in_full_nursery(old), "direct-old-placed-in-nursery");
  NEED(stats.direct_old_allocations == 1 && stats.nursery_allocations == 0,
       "direct-old-birth-accounting-changed");
  for (size_t i = 0; i < 4; ++i)
    NEED(((Word *)old)[i] == 0, "direct-old-not-zeroed");
  Root ro; root_push(&ro, &old); major_collect();
  checked_root(old, "direct-old-root-invalid");
  root_pop(&ro);
  finish_heap("direct-old");
}

static void case_ledger(void) {
  start_heap(512);
  GcLayout atomic = layout(1, 0); /* Sole descriptor, interned before accounting. */
  Word slots[17] = {0}; Root roots[17];
  for (size_t i = 0; i < 17; ++i) root_push(&roots[i], &slots[i]);
  for (size_t i = 0; i < 17; ++i) {
    slots[i] = fresh(atomic);
    ((Word *)slots[i])[0] = integer(500 + i);
  }
  minor_collect();
  for (size_t i = 0; i < 17; ++i) {
    checked_root(slots[i], "ledger-root-stale");
    NEED(unbox(load(slots[i], 0)) == 500 + i, "ledger-payload-corrupt");
  }
  NEED(stats.promoted_count == 17 && stats.copied_payload_bytes == 17 * sizeof(Word),
       "ledger-promotion-identity");
  print_snapshot("after-minor");
  major_collect();
  NEED(stats.old_object_count == 17, "ledger-major-dropped-rooted-objects");
  print_snapshot("after-major");
  for (size_t i = 17; i-- > 0;) root_pop(&roots[i]);
  finish_heap("ledger");
}

static void case_all(void) {
  case_alias_cycles(); case_chain(); case_payload(); case_raw_copy();
  case_forwarded_alias(); case_lifecycle(); case_ledger();
}
int main(int argc, char **argv) {
  if (argc != 2) fail("usage-case-required");
  if (!strcmp(argv[1], "all")) case_all();
  else if (!strcmp(argv[1], "alias")) case_alias_cycles();
  else if (!strcmp(argv[1], "chain")) case_chain();
  else if (!strcmp(argv[1], "payload")) case_payload();
  else if (!strcmp(argv[1], "raw-copy")) case_raw_copy();
  else if (!strcmp(argv[1], "forwarded-alias")) case_forwarded_alias();
  else if (!strcmp(argv[1], "root-control")) case_root_mutation();
  else if (!strcmp(argv[1], "barrier-control")) case_barrier_mutation();
  else if (!strcmp(argv[1], "lifecycle")) case_lifecycle();
  else if (!strcmp(argv[1], "ledger")) case_ledger();
  else fail("unknown-case");
  return 0;
}
