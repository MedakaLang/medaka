"""Independent offline audit of frozen intrusive screen; no runner imports."""
import hashlib
import json
from pathlib import Path
import statistics

D=Path('/tmp/medaka-intrusive-screen-85')
A=json.loads((D/'audit.json').read_text())
R=[json.loads(x) for x in (D/'results.jsonl').read_text().splitlines()]
ARMS=('custom-baseline','custom-intrusive','boehm-historical-default','boehm-historical-fixed128','boehm-caller-default','boehm-caller-fixed128')
CELLS=[(p,n) for p in ('ephemeral','list','tree','mutation','atomic','mixed','sizes') for n in (262144,262136)]+[('tree',16777216),('tree',16777208)]
N=5000000
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert sha(D/'run.py')=='b44cdedb94e8f1f775a41b266bdd15d74ef16a97fb922e564cce4bc38cd6f6bc'
assert sha(D/'PROTOCOL.md')=='67317a985fd26ea1035a7fe0fbdfecdac1e8dc26b880f133064c6a98f7c0386a'
assert len(R)==576 and len({(r['round'],r['profile'],r['capacity'],r['arm']) for r in R})==576
expected=[dict(round=q,profile=p,capacity=n,position=i,arm=ARMS[(q+i)%6]) for q in range(6) for p,n in CELLS for i in range(6)]
assert [{k:r[k] for k in ('round','profile','capacity','position','arm')} for r in R]==expected==A['schedule']
assert A['input_hashes_before']==A['input_hashes_after'] and A['binary_hashes_before']==A['binary_hashes_after']
for field in ('input_hashes_before','binary_hashes_before'):
    for path,digest in A[field].items():assert sha(path)==digest,(path,'input drift')
for path,text in A['source_and_harness_full_text'].items():assert (D/path).read_text()==text
assert hashlib.sha256(A['candidate_patch_text'].encode()).hexdigest()==A['candidate_patch_sha256']
assert sha(A['boehm_config']['boehm_archive'])==A['boehm_config']['boehm_archive_sha256']
assert A['boehm_config']['boehm_linkage']=='static'
assert A['source_sha256']['candidate']['gc.c']=='ffdc7cec188abec33fc9b9b147c4477b93097242f1555f980aee09724b7cfa0e'
for name in ('gc.h','workload.c'):assert A['source_sha256']['candidate'][name]==A['source_sha256']['baseline'][name]
timed=[(i,x) for i,x in enumerate(A['commands']) if len(x['argv'])==4 and x['argv'][2]==str(N) and '/build/' in x['argv'][0]]
assert len(timed)==576
floors=A['launcher_floors'];assert len(floors)==96
assert len({(x['round'],x['profile'],x['capacity']) for x in floors})==96
floor_by={(x['round'],x['profile'],x['capacity']):x for x in floors}
sizes=(2,3,7,16,63,64,65,127)
live_sizes=[sizes[(61*j-1)%8] for j in range(1,N//61+1) if (61*j-1)%8 not in (3,7)]+[16,127]
live_bytes={'list':N*32,'tree':N*32,'ephemeral':(N%256)*32,'mutation':65*32,'atomic':32,'mixed':((N+63)//64)*32,'sizes':sum((w+1)*8 for w in live_sizes)}
live_count={'list':N,'tree':N,'ephemeral':N%256,'mutation':65,'atomic':1,'mixed':(N+63)//64,'sizes':len(live_sizes)}
component=('nursery_capacity_bytes','pool_reserved_bytes','large_reserved_bytes','descriptor_bytes','work_queue_bytes','remembered_queue_bytes','root_bytes','static_metadata_bytes')
for r,(index,command) in zip(R,timed):
    x=r['row'];p=r['profile'];cap=r['capacity'];arm=r['arm']
    assert command['returncode']==0 and command['stderr']=='' and command['argv']==r['command'] and json.loads(command['stdout'])==x
    env={'GC_INITIAL_HEAP_SIZE':'134217728'} if arm.endswith('fixed128') else {}
    assert command['GC_environment']==r['GC_environment']==env
    if r['position']==0:
        floor_command=A['commands'][index-1]
        assert floor_command['argv']==[str(D/'build/launcher-floor')] and floor_command['returncode']==0 and floor_command['stderr']==''
        assert json.loads(floor_command['stdout'])['launcher_floor_rss_bytes']==floor_by[(r['round'],p,cap)]['rss_bytes']>0
    assert x['profile']==p and x['count']==N and x['checksum']==N*(N-1)//2
    requests=N+(p=='mutation');payload=(N//8)*sum(sizes)*8 if p=='sizes' else requests*24
    assert x['allocations']==requests and x['payload_bytes']==payload
    assert x['elapsed_seconds']>0 and x['process_peak_rss_bytes']>0
    if arm.startswith('boehm'):
        assert x['exact_live_bytes'] is None and x['boehm_free_space_divisor']==1 and x['inline_available']==1 and x['boehm_version_packed']==524808
        assert x['boehm_heap_minus_free_bytes']==x['boehm_heap_bytes']-x['boehm_free_bytes']
        continue
    assert x['nursery_capacity_bytes']==cap and x['nursery_used_bytes']==0 and x['root_bytes']==0
    assert x['allocation_header_bytes']==requests*8
    assert x['nursery_allocations']+x['direct_old_allocations']==requests
    assert x['nursery_payload_bytes']+x['direct_old_payload_bytes']==payload
    assert x['old_live_bytes']==x['exact_live_bytes']==live_bytes[p] and x['old_object_count']==live_count[p]
    assert x['exact_live_payload_bytes']+8*x['old_object_count']==x['old_live_bytes']
    assert x['old_total_allocated_bytes']-x['reclaimed_bytes']==x['old_live_bytes']
    assert x['pool_allocations']-x['pool_releases']==x['pool_count'] and x['pool_reserved_bytes']>=x['old_slot_bytes']
    assert x['accounted_bytes']==sum(x[k] for k in component) and x['peak_accounted_bytes']>=x['accounted_bytes']

variable={'elapsed_seconds','preparation_seconds','process_peak_rss_bytes','static_metadata_bytes','work_queue_bytes','accounted_bytes','peak_accounted_bytes'}
for p,n in CELLS:
    for q in range(6):
        b=next(x['row'] for x in R if (x['profile'],x['capacity'],x['round'],x['arm'])==(p,n,q,'custom-baseline'))
        c=next(x['row'] for x in R if (x['profile'],x['capacity'],x['round'],x['arm'])==(p,n,q,'custom-intrusive'))
        assert {k:v for k,v in b.items() if k not in variable}=={k:v for k,v in c.items() if k not in variable}
        assert c['static_metadata_bytes']==b['static_metadata_bytes']+8 and c['work_queue_bytes']<=b['work_queue_bytes']
        assert c['accounted_bytes']-b['accounted_bytes']==8+c['work_queue_bytes']-b['work_queue_bytes']

events_by={};ledgers=[];total_events=0
assert len(A['diagnostics'])==32
for receipt in A['diagnostics']:
    arm,p,n=receipt['arm'],receipt['profile'],receipt['capacity']
    log=D/'diagnostics'/arm/(p+'-'+str(n)+'.peaks.log')
    assert sha(log)==receipt['peak_log_sha256']
    assert sha(D/'diagnostics'/arm/'gc.c')==receipt['source_sha256'] and sha(D/'diagnostics'/arm/'workload')==receipt['binary_sha256']
    events=[]
    for line in log.read_text().splitlines():
        assert line.startswith('GC_PEAK ')
        e=json.loads(line[len('GC_PEAK '):]);assert e['peak']==sum(e[k] for k in ('nursery','pool','large','descriptor','work','remembered','roots','static','extra'))
        assert e['nursery']==n and e['static']==(992 if arm=='custom-baseline' else 1000)
        events.append(e)
    assert len(events)==receipt['event_count'] and events[-1]==receipt['final_peak_event']
    assert all(a['peak']<b['peak'] for a,b in zip(events,events[1:]))
    assert events[-1]['peak']==max(e['peak'] for e in events)==receipt['row']['peak_accounted_bytes']
    samples=[x['row'] for x in R if (x['arm'],x['profile'],x['capacity'])==(arm,p,n)]
    for sample in samples:
        assert {k:v for k,v in sample.items() if k not in ('elapsed_seconds','preparation_seconds','process_peak_rss_bytes')}=={k:v for k,v in receipt['row'].items() if k not in ('elapsed_seconds','preparation_seconds','process_peak_rss_bytes')}
    total_events+=len(events);events_by[(arm,p,n)]=events[-1]
    ledgers.append(dict(arm=arm,profile=p,capacity=n,event_count=len(events),final_peak_event=events[-1],log_sha256=sha(log)))
assert len(events_by)==32

cells=[];decisions=[]
for p,n in CELLS:
    groups={a:[x for x in R if (x['profile'],x['capacity'],x['arm'])==(p,n,a)] for a in ARMS}
    arms={}
    for a,g in groups.items():
        assert len(g)==6 and {x['round'] for x in g}==set(range(6)) and {x['position'] for x in g}==set(range(6))
        t=[x['row']['elapsed_seconds'] for x in g];rss=[x['row']['process_peak_rss_bytes'] for x in g]
        memory=('boehm_heap_bytes','boehm_heap_minus_free_bytes','boehm_total_allocated_bytes') if a.startswith('boehm') else ('accounted_bytes','peak_accounted_bytes','work_queue_bytes','static_metadata_bytes')
        raw={k:[x['row'][k] for x in g] for k in memory}
        arms[a]=dict(times=t,rss=rss,time_median=statistics.median(t),rss_median=statistics.median(rss),time_range=[min(t),max(t)],rss_range=[min(rss),max(rss)],raw_memory_samples=raw,memory_medians={k:statistics.median(v) for k,v in raw.items()},collection_schedules=[{k:x['row'].get(k) for k in ('minor_count','major_count','promoted_count','copied_bytes')} for x in g])
    byround={a:{x['round']:x['row'] for x in g} for a,g in groups.items()}
    paired={a:[byround['custom-intrusive'][q]['elapsed_seconds']/byround[a][q]['elapsed_seconds'] for q in range(6)] for a in ARMS if a!='custom-intrusive'}
    ratios=paired['custom-baseline'];median=statistics.median(ratios);floor=[x['rss_bytes'] for x in floors if (x['profile'],x['capacity'])==(p,n)]
    assert len(floor)==6
    above=arms['custom-baseline']['rss_median']>=2*statistics.median(floor)
    rssratio=arms['custom-intrusive']['rss_median']/arms['custom-baseline']['rss_median']
    primary=(p,n) in (('tree',262144),('tree',262136))
    gain=median<.95 and sum(x<.95 for x in ratios)>=5
    regression=median>1.05 and sum(x>1.05 for x in ratios)>=5
    best=min(ARMS[2:],key=lambda a:arms[a]['time_median'])
    cells.append(dict(profile=p,capacity=n,arms=arms,paired_candidate_time_ratios=paired,paired_custom_time_ratio_median=median,paired_custom_gain_count=sum(x<.95 for x in ratios),paired_custom_regression_count=sum(x>1.05 for x in ratios),candidate_baseline_ratio_of_time_medians=arms['custom-intrusive']['time_median']/arms['custom-baseline']['time_median'],strongest_observed_Boehm=best,primary=primary,primary_gain=gain,repeatable_regression=regression,total_RSS_ratio=rssratio,launcher_floor_rss=floor,RSS_materially_above_floor=above,RSS_ratio_kind='ratio of median total process high-water RSS; never subtract floor',RSS_regression=above and rssratio>1.10,RSS_interpretation='total RSS; no subtraction' if above else 'floor limited/inconclusive'))
    b=events_by[('custom-baseline',p,n)];c=events_by[('custom-intrusive',p,n)]
    decisions.append(dict(profile=p,capacity=n,primary=primary,primary_gain=gain,paired_ratio_median=median,gain_count=sum(x<.95 for x in ratios),regression_count=sum(x>1.05 for x in ratios),regression=regression,RSS_materially_above_floor=above,RSS_reject=above and rssratio>1.10,floor_median_bytes=statistics.median(floor),baseline_median_ms=arms['custom-baseline']['time_median']*1000,candidate_median_ms=arms['custom-intrusive']['time_median']*1000,fastest_boehm=best,fastest_boehm_median_ms=arms[best]['time_median']*1000,candidate_fastest_boehm_ratio=arms['custom-intrusive']['time_median']/arms[best]['time_median'],peak_delta_bytes=c['peak']-b['peak'],final_peak_components_baseline=b,final_peak_components_candidate=c))
advance=all(c['primary_gain'] for c in cells if c['primary']) and not any(c['repeatable_regression'] for c in cells if not c['primary']) and not any(c['RSS_regression'] for c in cells)
summary=dict(cells=cells,screen_advance=advance,next_step='held-out confirmation required; no default-selection authority' if advance else 'screen does not advance')
assert summary==A['summary'],'independent summary disagreement'
report=dict(status='passed independent offline audit; candidate does not advance',raw_sha256=sha(D/'results.jsonl'),audit_sha256=sha(D/'audit.json'),runner_sha256=sha(D/'run.py'),protocol_sha256=sha(D/'PROTOCOL.md'),rows=576,custom_paired_rows=96,input_files=138,binaries=7,launcher_floors=96,peak_ledgers=32,peak_events=total_events,source_drift=False,all_summaries_and_decisions_exact_match=True,screen_advance=advance,decisions=decisions,peak_ledger_receipts=ledgers,summary=summary,limits=['Boehm lacks custom collector counters; those stay unavailable.','RSS is total high-water without floor subtraction; ten cells are floor-limited, not approved memory gains.','Logical copied volume is unchanged, while intrusive links add nursery reads/writes. This experiment removes minor array-queue traffic, not physical copying or the major queue.','No implementation/default/held-out selection follows from this failed primary screen.'])
Path('/tmp/pool-review-intrusive-audit.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k not in ('summary','peak_ledger_receipts','decisions')},indent=2))
print(json.dumps([{k:v for k,v in x.items() if not k.startswith('final_peak_components')} for x in decisions],indent=2))
