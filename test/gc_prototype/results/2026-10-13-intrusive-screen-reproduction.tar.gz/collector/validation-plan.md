# Intrusive minor queue: frozen source and planned validation

Sources are exact85c364304 copies except candidate gc.c; gc.h and workload.c
are byte-identical. No code has been built or executed. Preparation helper:
/tmp/medaka-intrusive-promotion-85-prepare.py. Patch and exact source hashes:
intrusive-minor-queue.patch and manifest.json in this directory.

The mutator API and young allocation schedule are unchanged. An object copies
its entire logical payload to old storage before its nursery field0 becomes a
work link. Its forwarding header supplies the old destination. Each pop removes
the head before scanning, preserving the original LIFO scan order even when
children prepend more work. Atomic objects still enter the list. The list is
empty at collection entry, before nursery poison/reset, and at heap teardown.

## Independent fixture controls (source preparation only)

1. Sharing and cycles: distinct root records alias one object, a diamond, a
   one-word traced self-cycle, and a multiword cycle. Check roots/child aliases,
   unique promoted count, and nursery-range exclusion before following edges.
   One-word objects cover the smallest borrowed-link slot. Build each complete
   nursery graph without an intervening allocation slow path (or root/reload
   every temporary), so the fixture does not manufacture stale values itself.
2. Pop ordering: a rooted old owner remembers a three-level nursery chain. Its
   descendants have no separate roots when collection starts. After collection,
   before dereferencing each traced edge, reject nonzero-even values in the
   entire nursery capacity range. is_young is insufficient after used resets.
3. Full payload preservation: one-word atomic data, odd/zero raw field0, traced
   field0, bitmap bit63, and atomic/raw payload tails beyond word64. Atomic
   bytes may include arbitrary even patterns: write their raw buffer directly
   with the registered atomic layout instead of abusing the traced-store API.
   Check raw bytes exactly and check traced edge relocation/range first.
4. Boundaries and lifecycle: tiny capacity cases, repeated minor collections,
   minor followed by major, heap_destroy/init epoch changes, old→young mutation,
   and unchanged direct-old birth/zeroing. Every ordinary root/store/allocator
   fixture remains applicable without adapting its public API contract.

## Safe failure mutations in independent copied sources

- Delayed pop: move promotion_todo=next after scan_promote. The three-level
  chain loses newly enqueued descendant scans. Require the exact stale-edge
  nursery-range diagnostic before dereferencing the child, not a crash.
- Copy after borrowing: write the nursery link before new_old's unchanged full
  copy. Use an atomic raw field0 byte pattern control; require exact byte-mismatch
  diagnostic, never interpret corrupted raw bytes as pointers.
- Forwarded return: on the already-FORWARDED branch return the original nursery
  word instead of the old destination. Use acyclic aliased roots; require exact
  relocated-alias/range diagnostic before any graph dereference. Do not literally
  omit forwarding-header publication: the intrusive drain decodes its destination
  from that header, so omission causes invalid accesses before this oracle.
- Existing roots/barrier suppression: safe pointer-equality/range checks before
  stale dereference, with exact named oracle markers. Arbitrary nonzero status,
  sanitizer errors and timeouts never count as a successfully detected mutant.

No broken variants or mutation defines are added to the candidate source.

## Accounting and deterministic counter comparison

All allocation, collection, promotion, logical copy, reclaim, pool, descriptor,
root and remembered counters remain equal for the same inputs. Work queue bytes
can decrease because only major marking now grows that queue. New static storage
is exactly sizeof(Word)=8. At any matched snapshot:

    accounted_candidate - accounted_baseline
        = 8 + work_queue_bytes_candidate - work_queue_bytes_baseline

Accounted peaks are not discarded: compare an event ledger using static+8,
major-only work growth, and the existing old+new queue-array growth overlap.
Logical copied_bytes/copy_payload_bytes intentionally exclude physical link
writes, just as their baseline definitions excluded work-array writes.

A small exact ledger fixture can root17 one-word atomic nursery objects, intern
their sole layout before measurement, and collect once. Both arms promote17
objects into the same pool with identical roots/descriptors/payload totals.
Baseline work capacity becomes64 (512 bytes); candidate remains0. After this
minor, accounted and peak-accounted differences are -504 bytes. On a following
major, both retained queues reach64: current accounted and peak differences
become +8. Neither arm receives an extra cleanup collection. Charge any diagnostic
peak instrumentation separately; none is present in this minimal candidate.

After the parent releases CPU: independent positive ASan/UBSan fixtures,
safe named mutation controls, existing full correctness matrix, then a matched
baseline/candidate benchmark only after independent review and timing handoff.
No performance claim follows from a source-level queue change alone.
