# Retained-tree direct-old diagnostic protocol

Status: SOURCE ONLY. Independent packet review and explicit CPU release are
required before any build or execution. No source or fixture changes.

The direct-old correctness evidence is accepted: shared gc.c/gc.h/workload.c and
fixtures match /tmp/medaka-tree-direct-old-85/manifest.json; the independent runner
passed 159 checks. Both timing custom arms compile the same validated source;
TREE_DIRECT_OLD is the only candidate define. Its checked out-of-line allocator
validates the descriptor and fully zeroes every birth. A negative result cannot
rule out specialized old birth, initialization fusion or chunk retention.
The route also changes mature-object placement and allocation order. Results
therefore combine those effects with the checked old-birth call and zeroing;
they do not isolate physical copying cost.

## Frozen experiment

One retained tree of 5,000,000 three-word nodes per fresh process. Capacities:
262144, 262136, 16777216 and 16777208 bytes (256 KiB and 16 MiB, aligned/minus 8).
Six arms:

| Arm | Defines beyond common prepared caller controls | GC environment |
| --- | --- | --- |
| custom baseline | none | all inherited GC_* removed |
| custom direct-old | TREE_DIRECT_OLD | all inherited GC_* removed |
| Boehm historical default | USE_BOEHM, USE_INLINE | default initial heap |
| Boehm historical fixed128 | USE_BOEHM, USE_INLINE | GC_INITIAL_HEAP_SIZE=134217728 |
| Boehm caller default | USE_BOEHM, USE_CALLER_INLINE | default initial heap |
| Boehm caller fixed128 | USE_BOEHM, USE_CALLER_INLINE | GC_INITIAL_HEAP_SIZE=134217728 |

Common defines are USE_PREPARED, INLINE_ALLOC and INLINE_STORE. Clang -O2, separate
translation units, no LTO; match the validated build command. Boehm uses the exact
85c runtime allocator extraction and static libgc, GC_THREADS/pthread and divisor 1.
Its root registration stays a no-op; existing reachability hints remain. Both
Boehm allocators preserve the production version/size guards and traced
uncollectable freelist-head storage. Boehm ignores nursery capacity: the four
capacity labels are pairing controls, not four Boehm nursery policies. Each
Boehm allocator uses one identical binary for its default/fixed initial-heap arms;
four distinct binaries implement the six arms. Pacing remains the validated 85c
collector, without the allocation-pressure variant.

Six cyclic rounds. Within each capacity, round r starts at arm r and wraps through
all six arms. Thus every arm occupies every ordinal position once per capacity.
Capacity order stays the listed order each round. This gives exactly
6 rounds × 4 capacities × 6 arms = 144 timed rows, run sequentially. No warmup or
repetition is chosen from preliminary results. Six short correctness smoke runs
(one per arm, tree 4096/capacity 240) occur before the timed matrix and are saved
separately. No timing comparisons are made from those smoke runs.

## Measurement and oracles

Use only the existing workload's elapsed_seconds: retained-tree construction,
checksum traversal and final GC. It excludes heap initialization and layout
preparation. Preserve all validation, zeroing, root updates, barriers, final GC and
volatile checksum observation. Existing instrumentation does not separately time
construction/final GC; report the combined time only. Do not add collection phases.

Every row must pass checksum N*(N-1)/2 and allocation/payload counts. Custom rows
also satisfy every accepted route/storage identity. Baseline: N nursery births,
N promotions, 32N copied logical bytes. Candidate: N direct-old births, no nursery
births/promotions/copies. Both retain 32N logical bytes and 24N payload bytes,
N objects, ceil(N/512) pools, zero reclaimed/reused slots, and the validated exact
root peak. Validate actual descriptor/layout/root/pool end-state equality across
the paired custom rows. Queue/peak-accounted differences are preserved and must
be explained from real allocation/collection events, never normalized away.

Boehm rows must preserve N allocations, 24N payload bytes, checksum, divisor 1,
inline version availability and null exact_live_bytes. Heap-minus-free is a
conservative accounting signal. RSS is process high-water, including launcher
floor/allocator overhead; it is not exact collector live bytes.

Record raw rows, round/ordinal/capacity/arm, exact command/environment, build
commands, source and binary hashes. Pin compiler executable/version, static libgc
archive, adapter, all compiled source inputs and transitive headers discovered
with the matching preprocessor flags BEFORE builds/matrix and verify unchanged
AFTERWARD. Hash linked binaries before/after as well. Preserve library configuration
and dependency paths. Any failed oracle, stderr, timeout or input drift stops the
matrix and marks the partial evidence invalid; do not continue through failures.

## Reduction

Per capacity/arm report six raw times, median and range, raw RSS with median/range,
and custom minor/major/copy schedules. The unchanged Boehm output has no exact
automatic-collection schedule counters; those remain unavailable. Per round
report direct-old/baseline time and RSS
ratios; summarize median ratio and full paired min/max range. Also report direct-old
against each Boehm arm and identify the fastest observed Boehm median for context.
Keep all four capacities visible. There is no selection, held-out validation,
advancement criterion or compiler speedup claim. This is one bounded birth-route
diagnostic, not a changed production allocation policy.
