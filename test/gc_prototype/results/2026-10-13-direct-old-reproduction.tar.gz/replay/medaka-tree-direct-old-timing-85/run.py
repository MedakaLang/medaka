#!/usr/bin/env python3
"""Source-frozen retained-tree diagnostic. Execution needs review + CPU handoff."""
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import platform
import shlex
import shutil
import statistics
import subprocess

HERE = Path(__file__).resolve().parent
VALIDATED = Path('/tmp/medaka-tree-direct-old-85')
REPO = Path('/root/.codex/worktrees/f396/medaka')
BUILD = HERE / 'build'
COUNT = 5_000_000
CAPACITIES = (262144, 262136, 16777216, 16777208)
ARMS = ('custom-baseline', 'custom-direct-old', 'boehm-historical-default',
        'boehm-historical-fixed128', 'boehm-caller-default', 'boehm-caller-fixed128')
DEFINES = {
    'custom-baseline': ('USE_PREPARED', 'INLINE_ALLOC', 'INLINE_STORE'),
    'custom-direct-old': ('USE_PREPARED', 'INLINE_ALLOC', 'INLINE_STORE', 'TREE_DIRECT_OLD'),
    'boehm-historical': ('USE_PREPARED', 'INLINE_ALLOC', 'INLINE_STORE', 'USE_BOEHM', 'USE_INLINE'),
    'boehm-caller': ('USE_PREPARED', 'INLINE_ALLOC', 'INLINE_STORE', 'USE_BOEHM', 'USE_CALLER_INLINE'),
}
ENV = {key: value for key, value in os.environ.items()
       if not key.startswith('GC_') and key not in ('ASAN_OPTIONS', 'UBSAN_OPTIONS')}
report = {'status': 'source preparation only', 'mode': 'diagnostic, no selection/held-out/advancement claim',
          'commands': [], 'checks': [], 'count': COUNT, 'capacities': list(CAPACITIES), 'rounds': 6,
          'arms': list(ARMS), 'measurement': 'existing elapsed_seconds includes construction, checksum traversal and final GC; excludes heap/layout setup'}


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def command(args, *, env=ENV, timeout=180):
    result = subprocess.run([str(arg) for arg in args], cwd=REPO, env=env,
                            text=True, capture_output=True, timeout=timeout)
    report['commands'].append({'command': [str(arg) for arg in args], 'returncode': result.returncode,
                               'stdout': result.stdout, 'stderr': result.stderr})
    assert result.returncode == 0 and not result.stderr, (args, result.returncode, result.stderr)
    return result.stdout


def key_for(arm):
    return arm.rsplit('-', 1)[0] if arm.startswith('boehm') else arm


def env_for(arm):
    result = dict(ENV)
    if arm.endswith('-fixed128'):
        result['GC_INITIAL_HEAP_SIZE'] = '134217728'
    return result


def prepare():
    verification = json.loads((VALIDATED / 'independent-verification.json').read_text())
    assert verification['status'] == 'passed'
    manifest = json.loads((VALIDATED / 'manifest.json').read_text())
    for name, expected in verification['frozen_source_sha256'].items():
        assert digest(VALIDATED / 'source' / name) == expected
    for name, expected in verification['fixture_sha256'].items():
        assert digest(VALIDATED / name) == expected
    assert digest(VALIDATED / 'validate_independent.py') == verification['runner_sha256']
    assert digest(VALIDATED / 'manifest.json') == verification['manifest_sha256']
    BUILD.mkdir(exist_ok=True)
    shutil.copytree(VALIDATED / 'source', BUILD / 'source', dirs_exist_ok=True)
    for name, expected in verification['adapter_sha256'].items():
        path = VALIDATED / 'independent-build' / name
        assert digest(path) == expected
        shutil.copyfile(path, BUILD / name)
    module_path = VALIDATED / 'validate_independent.py'
    spec = importlib.util.spec_from_file_location('direct_old_correctness', module_path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    module.BUILD, module.ENV, module.report = BUILD, ENV, report
    report['boehm_config'] = verification['boehm_config']
    report['baseline_commit'] = manifest['baseline_commit']
    report['validated_source_sha256'] = verification['frozen_source_sha256']
    report['validated_fixture_sha256'] = verification['fixture_sha256']
    report['adapter_sha256'] = verification['adapter_sha256']
    report['runtime_sha256'] = verification['runtime_sha256']
    report['validation_sha256'] = digest(VALIDATED / 'independent-verification.json')
    report['boehm_observed_contract'] = next(
        {key: x['row'][key] for key in ('boehm_version_packed', 'inline_available')}
        for x in verification['checks'] if x['kind'] == 'workload' and x['arm'] == 'boehm')
    report['schedule'] = [{'round': r, 'capacity': capacity, 'position': position, 'arm': ARMS[(r + position) % 6]}
                          for r in range(6) for capacity in CAPACITIES for position in range(6)]
    report['build_defines'] = {key: list(value) for key, value in DEFINES.items()}
    report['platform'] = platform.platform()
    return module


def compile_flags(key):
    flags = ['-std=c11', '-O2', '-g', '-Wall', '-Wextra', '-Werror',
             '-I', str(BUILD), '-I', str(BUILD / 'source'), *['-D' + x for x in DEFINES[key]]]
    if key.startswith('boehm'):
        flags += ['-DGC_THREADS', '-pthread']
        # pkg-config compile flags needed for dependency discovery; link inputs
        # remain exactly the validated configuration in the build helper.
        source_flags = report['boehm_config']['flags']
        i = 0
        while i < len(source_flags):
            flag = source_flags[i]
            if flag in ('-I', '-isystem', '-iquote', '-include', '-isysroot', '--sysroot'):
                flags += [flag, source_flags[i + 1]]; i += 2; continue
            if flag.startswith(('-I', '-D', '-U', '--sysroot=')) or flag == '-pthread':
                flags.append(flag)
            i += 1
    return flags


def dependencies(compiler):
    paths = set()
    for key in DEFINES:
        units = [BUILD / 'source/gc.c', BUILD / 'source/workload.c']
        if key.startswith('boehm'):
            units.append(BUILD / 'boehm_adapter.c')
        for index, unit in enumerate(units):
            output = command([compiler, *compile_flags(key), '-M', '-MT', 'dependencies', unit])
            (BUILD / f'{key}-{index}.d').write_text(output)
            words = shlex.split(output.replace('\\\n', ' ').partition(':')[2])
            for name in words:
                path = Path(name.replace('$$', '$'))
                if not path.is_absolute():
                    path = REPO / path
                paths.add(path.resolve())
    return paths


def hashes(paths):
    return {str(path): digest(path) for path in sorted(set(paths))}


def build(compiler, key):
    # Same flags, translation units and link inputs as the accepted validation;
    # the absolute compiler path authenticates the executable used by each build.
    args = [compiler, '-std=c11', '-O2', '-g', '-Wall', '-Wextra', '-Werror',
            '-I', str(BUILD), '-I', str(BUILD / 'source'), *['-D' + x for x in DEFINES[key]],
            BUILD / 'source/gc.c', BUILD / 'source/workload.c']
    if key.startswith('boehm'):
        args += ['-DGC_THREADS', '-pthread', BUILD / 'boehm_adapter.c', *report['boehm_config']['flags']]
    binary = BUILD / key
    command([*args, '-o', binary])
    return binary


def check(row, arm, count, module):
    assert row['profile'] == 'tree' and row['count'] == count
    assert row['checksum'] == count * (count - 1) // 2
    assert row['allocations'] == count and row['payload_bytes'] == 24 * count
    assert row['elapsed_seconds'] > 0 and row['process_peak_rss_bytes'] > 0
    if arm.startswith('boehm'):
        assert row['exact_live_bytes'] is None and row['boehm_free_space_divisor'] == 1
        for key, expected in report['boehm_observed_contract'].items():
            assert row[key] == expected
        return
    module.identities(row)
    if arm == 'custom-direct-old':
        module.tree(row, count)
    else:
        expected = {'nursery_allocations': count, 'nursery_payload_bytes': 24 * count,
                    'direct_old_allocations': 0, 'direct_old_payload_bytes': 0,
                    'promoted_count': count, 'copied_bytes': 32 * count, 'copied_payload_bytes': 24 * count,
                    'old_total_allocated_bytes': 32 * count, 'old_live_bytes': 32 * count,
                    'exact_live_payload_bytes': 24 * count, 'old_object_count': count,
                    'reclaimed_bytes': 0, 'pooled_allocations': count, 'old_slot_bytes': 32 * count,
                    'pool_count': (count + 511) // 512, 'pool_allocations': (count + 511) // 512,
                    'pool_releases': 0, 'pool_reused_slots': 0, 'large_object_count': 0,
                    'large_reserved_bytes': 0, 'peak_old_bytes': 32 * count,
                    'peak_root_bytes': (2 + 2 * count.bit_length()) * 16}
        for key, expected_value in expected.items():
            assert row[key] == expected_value, (arm, key, row[key], expected_value)
        assert row['pool_reserved_bytes'] == ((count + 511) // 512) * (16384 + 48)
        assert row['peak_pool_reserved_bytes'] == row['pool_reserved_bytes']


def pair_check(a, b):
    keys = ('allocations', 'payload_bytes', 'checksum', 'allocation_header_bytes', 'old_total_allocated_bytes',
            'old_live_bytes', 'exact_live_payload_bytes', 'old_object_count', 'old_slot_bytes', 'peak_old_bytes',
            'pool_reserved_bytes', 'peak_pool_reserved_bytes', 'pool_count', 'pool_allocations', 'pool_releases',
            'pool_reused_slots', 'root_bytes', 'peak_root_bytes', 'descriptor_bytes', 'descriptor_count',
            'descriptor_bytes_after_prepare', 'layout_manifest_bytes')
    for key in keys:
        assert a[key] == b[key], (key, a[key], b[key])


def run_row(binary, arm, count, capacity, module):
    result = json.loads(command([binary, 'tree', str(count), str(capacity)], env=env_for(arm)))
    if arm.startswith('custom'):
        assert result['nursery_capacity_bytes'] == capacity, ('scheduled capacity mismatch', arm, capacity, result['nursery_capacity_bytes'])
    check(result, arm, count, module)
    return result


def reduce(rows):
    output = []
    for capacity in CAPACITIES:
        by_arm = {arm: [x for x in rows if x['capacity'] == capacity and x['arm'] == arm] for arm in ARMS}
        statistics_by_arm = {}
        for arm, samples in by_arm.items():
            assert len(samples) == 6
            times = [x['row']['elapsed_seconds'] for x in samples]
            rss = [x['row']['process_peak_rss_bytes'] for x in samples]
            statistics_by_arm[arm] = {'seconds': times, 'seconds_median': statistics.median(times),
                                      'seconds_range': [min(times), max(times)], 'rss_bytes': rss,
                                      'rss_median_bytes': statistics.median(rss), 'rss_range_bytes': [min(rss), max(rss)],
                                      'collection_schedules': [{k: x['row'].get(k) for k in
                                                               ('minor_count', 'major_count', 'copied_bytes', 'promoted_count')}
                                                              for x in samples]}
        paired = {}
        direct = {x['round']: x['row'] for x in by_arm['custom-direct-old']}
        for arm in ARMS:
            if arm == 'custom-direct-old':
                continue
            control = {x['round']: x['row'] for x in by_arm[arm]}
            ratios = [direct[r]['elapsed_seconds'] / control[r]['elapsed_seconds'] for r in range(6)]
            rss_ratios = [direct[r]['process_peak_rss_bytes'] / control[r]['process_peak_rss_bytes'] for r in range(6)]
            paired[arm] = {'direct_old_time_ratios': ratios, 'median_ratio': statistics.median(ratios),
                           'paired_range': [min(ratios), max(ratios)], 'direct_old_rss_ratios': rss_ratios,
                           'rss_median_ratio': statistics.median(rss_ratios), 'rss_paired_range': [min(rss_ratios), max(rss_ratios)]}
        fastest = min((arm for arm in ARMS if arm.startswith('boehm')),
                      key=lambda arm: statistics_by_arm[arm]['seconds_median'])
        output.append({'capacity': capacity, 'arms': statistics_by_arm, 'paired_direct_old': paired,
                       'fastest_observed_boehm_median_arm': fastest})
    return output


def execute(module):
    compiler = Path(shutil.which('clang')).resolve()
    report['compiler'] = command([compiler, '--version'])
    report['compiler_executable'] = str(compiler)
    paths = dependencies(compiler)
    paths.update((compiler, Path(report['boehm_config']['boehm_archive']), Path(__file__), HERE / 'PROTOCOL.md',
                  VALIDATED / 'manifest.json', VALIDATED / 'validate_independent.py',
                  VALIDATED / 'independent-verification.json', BUILD / 'boehm_adapter.c', BUILD / 'boehm_caller.h'))
    paths.update(VALIDATED / 'source' / name for name in ('gc.c', 'gc.h', 'workload.c'))
    paths.update(VALIDATED / name for name in ('direct_old_contract.c', 'same_heap_phases.c'))
    paths.update(VALIDATED / 'independent-build' / name for name in ('boehm_adapter.c', 'boehm_caller.h'))
    runtime_path = VALIDATED / 'independent-build/runtime/medaka_rt.c'
    assert digest(runtime_path) == report['runtime_sha256']
    paths.add(runtime_path)
    report['input_hashes_before'] = hashes(paths)
    assert report['input_hashes_before'][str(Path(report['boehm_config']['boehm_archive']))] == report['boehm_config']['boehm_archive_sha256']
    binaries = {key: build(compiler, key) for key in DEFINES}
    report['binary_hashes_before'] = hashes(binaries.values())
    assert hashes(paths) == report['input_hashes_before'], 'input drift during build'
    smoke = []
    for arm in ARMS:
        smoke.append({'arm': arm, 'row': run_row(binaries[key_for(arm)], arm, 4096, 240, module)})
    pair_check(smoke[0]['row'], smoke[1]['row'])
    (HERE / 'smoke.json').write_text(json.dumps(smoke, indent=2) + '\n')
    rows = []
    with (HERE / 'results.jsonl').open('w') as raw:
        for scheduled in report['schedule']:
            arm, capacity = scheduled['arm'], scheduled['capacity']
            row = run_row(binaries[key_for(arm)], arm, COUNT, capacity, module)
            record = dict(scheduled, row=row, command=[str(binaries[key_for(arm)]), 'tree', str(COUNT), str(capacity)],
                          gc_environment={key: value for key, value in env_for(arm).items() if key.startswith('GC_')})
            rows.append(record); raw.write(json.dumps(record) + '\n'); raw.flush()
            same = [x for x in rows if x['round'] == scheduled['round'] and x['capacity'] == capacity]
            custom = {x['arm']: x['row'] for x in same if x['arm'].startswith('custom')}
            if len(custom) == 2:
                pair_check(custom['custom-baseline'], custom['custom-direct-old'])
    assert len(rows) == 144
    report['input_hashes_after'] = hashes(paths)
    report['binary_hashes_after'] = hashes(binaries.values())
    assert report['input_hashes_after'] == report['input_hashes_before'], 'input drift invalidates timing evidence'
    assert report['binary_hashes_after'] == report['binary_hashes_before'], 'binary drift invalidates timing evidence'
    report['summary'] = reduce(rows)
    report['status'] = 'completed diagnostic; no selection/held-out claim'


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--execute', action='store_true', help='only after independent review and explicit CPU handoff')
    args = parser.parse_args()
    try:
        module = prepare()
        if args.execute:
            assert not (HERE / 'results.jsonl').exists(), 'preserve previous raw evidence; use a new reviewed packet directory'
            report['status'] = 'running; partial evidence is not accepted'
            execute(module)
    except BaseException as error:
        report['status'] = 'failed/partial; not accepted evidence'
        report['error'] = repr(error)
        raise
    finally:
        (HERE / ('audit.json' if args.execute else 'preparation.json')).write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({'status': report['status'], 'root': str(HERE), 'timed_rows': 144 if args.execute else 0}))


if __name__ == '__main__':
    main()
