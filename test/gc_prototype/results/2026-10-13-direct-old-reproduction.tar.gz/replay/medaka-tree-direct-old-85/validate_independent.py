#!/usr/bin/env python3
"""Frozen direct-old diagnostic validation; no performance comparisons."""
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import platform
import resource
import shutil
import subprocess
import sys

HERE = Path(__file__).resolve().parent
REPO = Path('/root/.codex/worktrees/f396/medaka')
BUILD = HERE / 'independent-build'
PREPARED = ('USE_PREPARED', 'INLINE_ALLOC', 'INLINE_STORE')
CAPACITIES = (240, 262136, 262144)
TREE_COUNTS = (1, 3, 63, 64, 127, 4096)
OTHER_PROFILES = ('ephemeral', 'list', 'mutation', 'atomic', 'mixed', 'sizes')
report = {'mode': 'correctness only; single executions, no timing analysis', 'commands': [], 'checks': []}
resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
ENV = {key: value for key, value in os.environ.items() if not key.startswith('GC_')}
ENV.update(ASAN_OPTIONS='detect_leaks=0:halt_on_error=1', UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def process(args, *, expected=0, diagnostic=None, empty_stderr=True):
    result = subprocess.run([str(arg) for arg in args], text=True, capture_output=True,
                            timeout=120, env=ENV, cwd=REPO)
    row = {'command': [str(arg) for arg in args], 'returncode': result.returncode,
           'stdout': result.stdout, 'stderr': result.stderr, 'expected_diagnostic': diagnostic}
    report['commands'].append(row)
    if diagnostic:
        good = result.returncode != 0 and not result.stdout and diagnostic in result.stderr
        good = good and 'Sanitizer' not in result.stderr and 'runtime error:' not in result.stderr
    else:
        good = result.returncode == expected and (not empty_stderr or not result.stderr)
    if not good:
        raise RuntimeError('incorrect graded result: ' + str(row))
    return result


def prepare():
    manifest = json.loads((HERE / 'manifest.json').read_text())
    for group in manifest['files'].values():
        for file in group.values():
            assert digest(Path(file['path'])) == file['sha256'], file['path']
    for fixture in manifest['fixtures'].values():
        assert digest(Path(fixture['path'])) == fixture['sha256'], fixture['path']
    assert digest(HERE / 'tree-direct-old.patch') == manifest['patch_sha256']
    BUILD.mkdir(exist_ok=True)
    shutil.copytree(HERE / 'source', BUILD / 'source', dirs_exist_ok=True)
    for name in manifest['fixtures']:
        shutil.copyfile(HERE / name, BUILD / name)
    driver_path = REPO / 'test/gc_prototype/run.py'
    spec = importlib.util.spec_from_file_location('prototype_driver', driver_path)
    driver = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(driver)
    # Extract the exact production allocator from the pinned baseline runtime.
    runtime = subprocess.check_output(['git', 'show', manifest['baseline_commit'] + ':runtime/medaka_rt.c'],
                                      cwd=REPO)
    (BUILD / 'runtime').mkdir(exist_ok=True)
    (BUILD / 'runtime/medaka_rt.c').write_bytes(runtime)
    driver.REPO = BUILD
    _, inline_hash = driver.adapter(BUILD)
    report['manifest_sha256'] = digest(HERE / 'manifest.json')
    report['frozen_source_sha256'] = {name: digest(HERE / 'source' / name) for name in ('gc.c', 'gc.h', 'workload.c')}
    report['fixture_sha256'] = {name: digest(HERE / name) for name in manifest['fixtures']}
    report['runner_sha256'] = digest(Path(__file__))
    report['adapter_driver_sha256'] = digest(driver_path)
    report['runtime_sha256'] = digest(BUILD / 'runtime/medaka_rt.c')
    report['inline_allocator_sha256'] = inline_hash
    report['adapter_sha256'] = {name: digest(BUILD / name) for name in ('boehm_adapter.c', 'boehm_caller.h')}
    report['baseline_commit'] = manifest['baseline_commit']
    report['platform'] = platform.platform()
    report['environment'] = {'inherited_GC_variables': 'all removed', 'sanitizers': ENV['ASAN_OPTIONS'],
                             'boehm_free_space_divisor': 1, 'threads': 'GC_THREADS, pthread; unchanged comparator'}
    return driver


def build(name, fixture, defines=(), *, sanitized=False, boehm=False):
    args = ['clang', '-std=c11', '-O2', '-g', '-Wall', '-Wextra', '-Werror',
            '-I', str(BUILD), '-I', str(BUILD / 'source'), *['-D' + item for item in defines]]
    if sanitized:
        args += ['-fsanitize=address,undefined', '-fno-omit-frame-pointer']
    args += [str(BUILD / 'source/gc.c'), str(BUILD / fixture)]
    if boehm:
        args += ['-DGC_THREADS', '-pthread', str(BUILD / 'boehm_adapter.c'), *report['boehm_config']['flags']]
    binary = BUILD / name
    args += ['-o', str(binary)]
    p = subprocess.run(args, text=True, capture_output=True, timeout=120, env=ENV)
    record = {'command': args[:], 'returncode': p.returncode, 'stdout': p.stdout, 'stderr': p.stderr,
              'expected_diagnostic': None, 'build': name}
    report['commands'].append(record)
    if p.returncode and sanitized and sys.platform.startswith('linux') and 'libclang_rt' in p.stderr:
        record['sanitizer_runtime_fallback'] = 'clang instrumentation with installed GCC ASan/UBSan libraries'
        args += ['-fno-sanitize-link-runtime', '-lasan', '-lubsan']
        process(args)
    elif p.returncode or p.stderr:
        raise RuntimeError('build failed: ' + str(record))
    return binary


def contract(binary, case, diagnostic=None):
    p = process([binary, case], diagnostic=diagnostic)
    if diagnostic is None:
        assert p.stdout == 'direct-old contract passed\n', (case, p.stdout)
    report['checks'].append({'kind': 'contract', 'binary': str(binary), 'case': case, 'diagnostic': diagnostic})


def identities(row):
    assert row['nursery_allocations'] + row['direct_old_allocations'] == row['allocations']
    assert row['nursery_payload_bytes'] + row['direct_old_payload_bytes'] == row['payload_bytes']
    assert row['allocation_header_bytes'] == row['allocations'] * 8
    assert row['old_total_allocated_bytes'] - row['reclaimed_bytes'] == row['old_live_bytes']
    assert row['exact_live_payload_bytes'] + row['old_object_count'] * 8 == row['old_live_bytes']
    assert row['pool_allocations'] - row['pool_releases'] == row['pool_count']
    accounted = (row['nursery_capacity_bytes'] + row['pool_reserved_bytes'] + row['large_reserved_bytes'] +
                 row['descriptor_bytes'] + row['work_queue_bytes'] + row['remembered_queue_bytes'] +
                 row['root_bytes'] + row['static_metadata_bytes'])
    assert row['accounted_bytes'] == accounted
    assert row['peak_accounted_bytes'] >= accounted


def workload(binary, profile, count, capacity, arm):
    p = process([binary, profile, str(count), str(capacity)])
    row = json.loads(p.stdout)
    assert row['profile'] == profile and row['count'] == count
    assert row['checksum'] == count * (count - 1) // 2
    requests = count + (1 if profile == 'mutation' else 0)
    assert row['allocations'] == requests and row['payload_bytes'] >= requests * 8
    if 'boehm' not in arm:
        identities(row)
    report['checks'].append({'kind': 'workload', 'arm': arm, 'capacity': capacity, 'row': row,
                             'timing_fields': 'ungraded incidental workload instrumentation'})
    return row


def tree(row, count):
    expected = {'allocations': count, 'payload_bytes': 24 * count, 'allocation_header_bytes': 8 * count,
                'direct_old_allocations': count, 'direct_old_payload_bytes': 24 * count,
                'nursery_allocations': 0, 'nursery_payload_bytes': 0, 'promoted_count': 0,
                'copied_bytes': 0, 'copied_payload_bytes': 0, 'old_total_allocated_bytes': 32 * count,
                'old_live_bytes': 32 * count, 'exact_live_payload_bytes': 24 * count,
                'old_object_count': count, 'reclaimed_bytes': 0, 'pooled_allocations': count,
                'old_slot_bytes': 32 * count, 'large_object_count': 0, 'large_reserved_bytes': 0,
                'pool_allocations': (count + 511) // 512, 'pool_count': (count + 511) // 512,
                'pool_releases': 0, 'pool_reused_slots': 0, 'peak_old_bytes': 32 * count,
                'pool_reserved_bytes': ((count + 511) // 512) * (16384 + 6 * 8),
                'peak_root_bytes': (2 + 2 * count.bit_length()) * 16}
    for key, value in expected.items():
        assert row[key] == value, (count, key, row[key], value)
    assert row['minor_count'] == row['major_count']
    assert row['peak_pool_reserved_bytes'] == row['pool_reserved_bytes']


def phases(binary, capacity, arm):
    p = process([binary, '4096', '4096', str(capacity)])
    rows = [json.loads(line) for line in p.stdout.splitlines()]
    expected_phases = ('ephemeral-before', 'retained-tree', 'ephemeral-after-drop', 'final-drain')
    assert [row['phase'] for row in rows] == list(expected_phases)
    for i, row in enumerate(rows):
        assert row['checksum'] == (0 if i == 3 else 4096 * 4095 // 2)
        if 'boehm' not in arm:
            identities(dict(row, nursery_capacity_bytes=capacity))
    assert rows[0]['allocations'] == 4096 and rows[1]['allocations'] == 8192
    assert rows[2]['allocations'] == 12288 and rows[3]['allocations'] == 12288
    report['checks'].append({'kind': 'same-heap-phases', 'arm': arm, 'capacity': capacity, 'rows': rows})


def execute(driver):
    report['compiler'] = process(['clang', '--version']).stdout.splitlines()[0]
    report['boehm_config'] = driver.boehm_config()
    assert report['boehm_config']['boehm_linkage'] == 'static', 'matching static Boehm archive required'
    for suffix, sanitized in [('', False), ('-sanitized', True)]:
        normal = build('contract' + suffix, 'direct_old_contract.c', sanitized=sanitized)
        for case in ('all', 'barrier', 'reload'):
            contract(normal, case)
        for case, expression in [('words', '.words == layout.words'), ('mask', '.mask == layout.mask'),
                                 ('epoch', 'layout.epoch == gc_heap_epoch')]:
            contract(normal, case, expression)
        for name, define, case, diagnostic in [
            ('missing-barrier', 'GC_MUTATE_BARRIER', 'barrier', 'direct-old assertion: mixed birth barrier relocation'),
            ('stale-prereload', 'GC_MUTATE_DIRECT_PRERELOAD', 'reload', 'direct-old assertion: postallocation root reload')]:
            mutant = build(name + suffix, 'direct_old_contract.c', [define], sanitized=sanitized)
            contract(mutant, case, diagnostic)
    arms = {'baseline': (PREPARED, False), 'candidate': ((*PREPARED, 'TREE_DIRECT_OLD'), False),
            'boehm': ((*PREPARED, 'USE_BOEHM', 'USE_CALLER_INLINE'), True),
            'boehm-guard': ((*PREPARED, 'USE_BOEHM', 'USE_CALLER_INLINE', 'TREE_DIRECT_OLD'), True)}
    binaries = {name: build('workload-' + name, 'source/workload.c', defines, boehm=boehm)
                for name, (defines, boehm) in arms.items()}
    for file in ('gc.c', 'workload.c'):
        common = ['clang', '-E', '-P', '-I', str(BUILD), '-I', str(BUILD / 'source'), '-DGC_THREADS',
                  *['-D' + x for x in arms['boehm'][0]], str(BUILD / 'source' / file)]
        plain = process(common).stdout
        flagged = process([*common[:-1], '-DTREE_DIRECT_OLD', common[-1]]).stdout
        assert plain == flagged, ('Boehm guard changed preprocessed source', file)
        report['checks'].append({'kind': 'boehm-guard-source', 'file': file,
                                'preprocessed_sha256': hashlib.sha256(plain.encode()).hexdigest()})
    for capacity in CAPACITIES:
        for count in TREE_COUNTS:
            baseline = workload(binaries['baseline'], 'tree', count, capacity, 'baseline')
            candidate = workload(binaries['candidate'], 'tree', count, capacity, 'candidate')
            tree(candidate, count)
            equal = ('allocations', 'payload_bytes', 'checksum', 'allocation_header_bytes',
                     'old_total_allocated_bytes', 'old_live_bytes', 'exact_live_payload_bytes',
                     'old_object_count', 'old_slot_bytes', 'peak_old_bytes', 'peak_pool_reserved_bytes',
                     'pool_reserved_bytes', 'pool_count', 'pool_allocations', 'pool_releases',
                     'pool_reused_slots', 'root_bytes', 'peak_root_bytes', 'descriptor_bytes',
                     'descriptor_count', 'descriptor_bytes_after_prepare', 'layout_manifest_bytes')
            for key in equal:
                assert baseline[key] == candidate[key], (capacity, count, key, baseline[key], candidate[key])
            report['checks'].append({'kind': 'tree-storage-event-difference', 'capacity': capacity, 'count': count,
                                     'queue_bytes_baseline': baseline['work_queue_bytes'],
                                     'queue_bytes_candidate': candidate['work_queue_bytes'],
                                     'peak_accounted_baseline': baseline['peak_accounted_bytes'],
                                     'peak_accounted_candidate': candidate['peak_accounted_bytes']})
            for name in ('boehm', 'boehm-guard'):
                row = workload(binaries[name], 'tree', count, capacity, name)
                assert row['payload_bytes'] == 24 * count and row['exact_live_bytes'] is None
                assert row['boehm_free_space_divisor'] == 1
        for profile in OTHER_PROFILES:
            baseline = workload(binaries['baseline'], profile, 4096, capacity, 'baseline')
            candidate = workload(binaries['candidate'], profile, 4096, capacity, 'candidate')
            ignored = {'elapsed_seconds', 'preparation_seconds', 'process_peak_rss_bytes'}
            a = {key: value for key, value in baseline.items() if key not in ignored}
            b = {key: value for key, value in candidate.items() if key not in ignored}
            assert a == b, ('non-tree deterministic counter mismatch', profile, capacity, a, b)
    sanitized_tree = build('workload-candidate-sanitized', 'source/workload.c', arms['candidate'][0], sanitized=True)
    for capacity in CAPACITIES:
        row = workload(sanitized_tree, 'tree', 4096, capacity, 'candidate-sanitized')
        tree(row, 4096)
    for name, (defines, boehm) in arms.items():
        binary = build('phases-' + name, 'same_heap_phases.c', defines, boehm=boehm)
        for capacity in CAPACITIES:
            phases(binary, capacity, name)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--prepare-only', action='store_true')
    args = parser.parse_args()
    try:
        driver = prepare()
        if args.prepare_only:
            report['status'] = 'prepared only; no compiler or workload processes executed'
        else:
            execute(driver)
            report['status'] = 'passed'
            # Frozen source/fixture hashes are checked again after executions.
            for name, expected in report['frozen_source_sha256'].items():
                assert digest(HERE / 'source' / name) == expected
            for name, expected in report['fixture_sha256'].items():
                assert digest(HERE / name) == expected
    finally:
        (HERE / ('independent-preparation.json' if args.prepare_only else 'independent-verification.json')).write_text(
            json.dumps(report, indent=2) + '\n')
    print(json.dumps({'status': report['status'], 'graded_checks': len(report['checks']),
                      'commands': len(report['commands']), 'root': str(HERE)}))


if __name__ == '__main__':
    main()
