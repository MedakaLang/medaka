#define main prototype_workload_main
#include "source/workload.c"
#undef main

#define REQUIRE(c, name) do { if (!(c)) { fprintf(stderr, "direct-old phase assertion: %s\n", name); abort(); } } while (0)

static void row(const char *phase, uint64_t checksum) {
  printf("{\"phase\":\"%s\",\"checksum\":%" PRIu64 ",", phase, checksum);
  print_stats(); printf("}\n");
}
int main(int argc, char **argv) {
  REQUIRE(argc == 4, "usage TREE_COUNT EPHEMERAL_COUNT CAPACITY");
  size_t count = strtoull(argv[1], NULL, 10), ephemeral = strtoull(argv[2], NULL, 10);
  size_t capacity = strtoull(argv[3], NULL, 10);
  REQUIRE(count > 0 && count < UINT64_C(1000000000) && ephemeral > 0
          && ephemeral < UINT64_C(1000000000) && ephemeral % 256 == 0 && capacity >= 240
          && capacity <= SIZE_MAX / 4, "bounded fixture parameters");
  heap_init(capacity); prepare_workload();
  Word retained = 0; Root rr; root_push(&rr, &retained);
  uint64_t ephemeral_expected = (uint64_t)ephemeral * (ephemeral - 1) / 2;
  uint64_t checksum = workload("ephemeral", ephemeral);
  REQUIRE(checksum == ephemeral_expected, "first ephemeral checksum");
#ifndef USE_BOEHM
  REQUIRE(stats.old_object_count == 0 && stats.old_live_bytes == 0, "first ephemeral drains old objects");
#endif
  row("ephemeral-before", checksum);
  Stats before_tree = stats;
  uint64_t id = 0; retained = tree(count, &id);
  uint64_t tree_expected = (uint64_t)count * (count - 1) / 2;
  REQUIRE(id == count && sum_tree(retained) == tree_expected, "tree constructor content");
  /* Identical retained-tree boundary collection in every arm. */
  major_collect();
  REQUIRE(sum_tree(retained) == tree_expected, "tree content after final collection");
  REQUIRE(stats.allocations - before_tree.allocations == count
          && stats.payload_bytes - before_tree.payload_bytes == 24 * count, "tree allocation partition");
#ifndef USE_BOEHM
  REQUIRE(stats.old_object_count == count && stats.old_live_bytes == 32 * count
          && stats.old_live_payload_bytes == 24 * count, "tree exact retained bytes");
  REQUIRE(stats.old_total_allocated_bytes - before_tree.old_total_allocated_bytes == 32 * count,
          "tree old allocation ledger");
#ifdef TREE_DIRECT_OLD
  REQUIRE(stats.direct_old_allocations - before_tree.direct_old_allocations == count
          && stats.nursery_allocations == before_tree.nursery_allocations, "tree forced old route");
  REQUIRE(stats.promoted_count == before_tree.promoted_count && stats.copied_bytes == before_tree.copied_bytes
          && stats.copied_payload_bytes == before_tree.copied_payload_bytes, "tree avoids evacuation");
#else
  REQUIRE(stats.nursery_allocations - before_tree.nursery_allocations == count
          && stats.direct_old_allocations == before_tree.direct_old_allocations, "tree ordinary nursery route");
  REQUIRE(stats.promoted_count - before_tree.promoted_count == count
          && stats.copied_bytes - before_tree.copied_bytes == 32 * count
          && stats.copied_payload_bytes - before_tree.copied_payload_bytes == 24 * count,
          "tree ordinary evacuation ledger");
#endif
#endif
  row("retained-tree", tree_expected);
  retained = 0;
  /* No cleanup collection at drop: both arms use the same next workload schedule. */
  Stats before_ephemeral = stats;
  checksum = workload("ephemeral", ephemeral);
  REQUIRE(checksum == ephemeral_expected, "postdrop ephemeral checksum");
  REQUIRE(stats.allocations - before_ephemeral.allocations == ephemeral, "postdrop allocation count");
#ifndef USE_BOEHM
  REQUIRE(stats.nursery_allocations - before_ephemeral.nursery_allocations == ephemeral
          && stats.direct_old_allocations == before_ephemeral.direct_old_allocations,
          "postdrop ephemeral remains generic nursery");
  REQUIRE(stats.old_object_count == 0 && stats.old_live_bytes == 0 && stats.pool_reserved_bytes == 0,
          "same schedule reclaims dropped tree and ephemeral objects");
#endif
  row("ephemeral-after-drop", checksum);
  root_pop(&rr); major_collect();
#ifndef USE_BOEHM
  REQUIRE(stats.root_bytes == 0 && stats.old_object_count == 0 && stats.old_live_bytes == 0
          && stats.pool_reserved_bytes == 0 && stats.large_reserved_bytes == 0, "complete final drain");
#endif
  row("final-drain", 0);
  heap_destroy(); return 0;
}
