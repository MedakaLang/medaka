#include "source/gc.h"
#include <stdio.h>
#include <stdlib.h>

#define REQUIRE(c, name) do { if (!(c)) { fprintf(stderr, "direct-old assertion: %s\n", name); abort(); } } while (0)

static GcLayout cell, atom;
static void setup(void) {
  heap_init(128); cell = prepare_layout(3, 6); atom = prepare_layout(3, 0);
}
static void zero(Word object, size_t words) {
  for (size_t i = 0; i < words; ++i) REQUIRE(load(object, i) == 0, "zero allocation contract");
}
static void ledger(void) {
  REQUIRE(stats.nursery_allocations + stats.direct_old_allocations == stats.allocations,
          "allocation route partition");
  REQUIRE(stats.nursery_payload_bytes + stats.direct_old_payload_bytes == stats.payload_bytes,
          "payload route partition");
  REQUIRE(stats.allocation_header_bytes == stats.allocations * old_header_size(), "header accounting");
  REQUIRE(stats.old_total_allocated_bytes - stats.reclaimed_bytes == stats.old_live_bytes,
          "old allocation reclamation ledger");
  REQUIRE(stats.old_live_payload_bytes + stats.old_object_count * old_header_size() == stats.old_live_bytes,
          "old payload header partition");
  REQUIRE(stats.pool_allocations - stats.pool_releases == stats.pool_count, "pool lifetime ledger");
}
static void finish(void) {
  major_collect(); ledger();
  REQUIRE(stats.root_bytes == 0 && stats.old_object_count == 0 && stats.old_live_bytes == 0,
          "balanced roots and complete reclamation");
  REQUIRE(stats.pool_reserved_bytes == 0 && stats.large_reserved_bytes == 0, "complete storage drain");
  heap_destroy();
}
static void barrier(void) {
  setup(); Word parent = 0, child = 0; Root rp, rc;
  root_push(&rp, &parent); root_push(&rc, &child);
  parent = allocate_prepared_direct_old(cell); zero(parent, 3);
  REQUIRE(!is_young(parent), "small cell born old");
  child = allocate_prepared(atom); zero(child, 3);
  REQUIRE(is_young(child), "generic allocation remains young");
  store_prepared(atom, child, 0, integer(17));
  store_prepared(cell, parent, 0, integer(11));
  store_prepared(cell, parent, 1, child); store_prepared(cell, parent, 2, child);
  Word before = child;
  minor_collect();
  REQUIRE(child != before, "generic child root relocation");
  /* Compare pointer bits before touching a possibly stale child payload. */
  REQUIRE(load(parent, 1) == child && load(parent, 2) == child, "mixed birth barrier relocation");
  REQUIRE(load(load(parent, 1), 0) == integer(17), "mixed birth child content");
  REQUIRE(stats.allocations == 2 && stats.direct_old_allocations == 1 && stats.nursery_allocations == 1,
          "mixed birth exact allocation counts");
  REQUIRE(stats.promoted_count == 1 && stats.copied_bytes == 32 && stats.copied_payload_bytes == 24,
          "shared young child evacuated once");
  child = 0; major_collect();
  REQUIRE(stats.old_object_count == 2 && load(load(parent, 2), 0) == integer(17),
          "old parent retains child without child root");
  parent = 0; root_pop(&rc); root_pop(&rp); finish();
}
static void dirty_reuse(void) {
  setup(); Word anchor = 0, object = 0; Root ra, ro;
  root_push(&ra, &anchor); root_push(&ro, &object);
  anchor = allocate_prepared_direct_old(atom); object = allocate_prepared_direct_old(atom);
  for (size_t i = 0; i < 3; ++i) store_prepared(atom, object, i, integer(71 + i));
  object = 0; major_collect();
  uint64_t reused = stats.pool_reused_slots;
  object = allocate_prepared_direct_old(atom);
  REQUIRE(stats.pool_reused_slots > reused, "dirty old slot actually reused"); zero(object, 3);
  anchor = object = 0; root_pop(&ro); root_pop(&ra); finish();
}
static void reload(void) {
  setup(); Word child = 0, chain = 0, result = 0; Root rc, rh, rr;
  root_push(&rc, &child); root_push(&rh, &chain); root_push(&rr, &result);
  child = allocate_prepared(atom); store_prepared(atom, child, 0, integer(109));
  REQUIRE(is_young(child), "reload source initially young");
  for (size_t i = 0; i < 16; ++i) {
    Word node = allocate_prepared_direct_old(cell);
    store_prepared(cell, node, 0, integer(i)); store_prepared(cell, node, 1, chain); chain = node;
  }
  REQUIRE(stats.old_live_bytes == gc_fast.old_limit && stats.old_live_bytes == 512,
          "major threshold reached before diagnostic allocation");
  Word captured = child; uint64_t majors = stats.major_count;
  result = allocate_prepared_direct_old(cell); zero(result, 3);
  REQUIRE(stats.major_count == majors + 1 && child != captured, "old allocation collects and reloads root");
#ifdef GC_MUTATE_DIRECT_PRERELOAD
  store_prepared(cell, result, 1, captured);
#else
  store_prepared(cell, result, 1, child);
#endif
  REQUIRE(load(result, 1) == child, "postallocation root reload");
  REQUIRE(load(load(result, 1), 0) == integer(109), "reloaded child content");
  REQUIRE(stats.direct_old_allocations == 17 && stats.nursery_allocations == 1
          && stats.promoted_count == 1 && stats.old_object_count == 18, "threshold allocation ledger");
  child = chain = result = 0; root_pop(&rr); root_pop(&rh); root_pop(&rc); finish();
}
static void rejected(const char *kind) {
  setup(); GcLayout layout = cell;
  if (strcmp(kind, "words") == 0) layout.words++;
  else if (strcmp(kind, "mask") == 0) layout.mask = 2;
  else if (strcmp(kind, "epoch") == 0) { heap_destroy(); setup(); }
  else REQUIRE(0, "unknown rejection case");
  (void)allocate_prepared_direct_old(layout);
  REQUIRE(0, "invalid layout accepted");
}
int main(int argc, char **argv) {
  REQUIRE(argc == 2, "usage all or barrier or reload or invalid case");
  if (strcmp(argv[1], "all") == 0) { barrier(); dirty_reuse(); reload(); }
  else if (strcmp(argv[1], "barrier") == 0) barrier();
  else if (strcmp(argv[1], "reload") == 0) reload();
  else rejected(argv[1]);
  puts("direct-old contract passed"); return 0;
}
