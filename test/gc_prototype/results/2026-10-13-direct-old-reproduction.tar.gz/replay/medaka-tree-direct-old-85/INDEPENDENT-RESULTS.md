# Independent direct-old correctness accepted

Frozen sources and fixtures were unchanged before/after execution. The runner
completed159graded checks with163recorded commands. No performance values were
graded or summarized: elapsed/RSS fields are incidental single-run output from
the existing immutable workload.

Reproduce: python3 /tmp/medaka-tree-direct-old-85/validate_independent.py
Full commands, provenance, stdout/stderr and outcomes:
/tmp/medaka-tree-direct-old-85/independent-verification.json

- Normal and ASan+UBSan all/barrier/reload cases passed. Invalid registered-layout
  words/mask and expired epoch were rejected at the named assertions.
- Missing-barrier and stale-prereload controls failed the exact pointer-bit
  invariants before stale dereference, normally and under sanitizers. All negative
  outcomes were intentionalSIGABRT with the expected diagnostic, without sanitizer
  reports. LeakSanitizer was disabled for sandbox ptrace; instrumentation used
  installed GCC ASan/UBSan libraries because this clang lacks its runtime archive.
- Tree1/3/63/64/127/4096 passed at240/262136/262144, across custom flag-off,
  TREE_DIRECT_OLD, static Boehm caller and Boehm withTREE_DIRECT_OLD defined.
  Candidate4096trees also passed sanitizers at all three capacities.
- All deterministic counters matched for six non-tree workloads at all three
  capacities; mutation intentionally requestsCOUNT+1 including its mature anchor.
- The same heap/epoch E→tree→drop(noextraGC)→E→final-drain schedule passed across
  all four arms at every capacity. Postdrop custom allocation/promotion/copied/
  minor/major/reclaimed deltas matched between baseline and candidate exactly.
- Boehm-preprocessedgc.c/workload.c were byte-identical withTREE_DIRECT_OLD
  toggled. Its heap-minus-free statistics were not treated as exact live bytes.

Across all18tree cells, baseline/candidate root/descriptor/layout/pool storage,
work queue bytes and peak-accounted bytes matched exactly. No growth/event
exception was needed. For4096nodes, both used8pools, peakRoot448B and512Bwork
queue. At240B nursery, baseline had592minors/7majors and candidate8/8; at262136
and262144 each had1/1. Baseline copied131072logical bytes, candidate0. Both
retained131072logical object bytes; zero-copy here is a route assertion, not a
speed claim.

Sourcegc.c SHA3613302e65f73c4a566b5e5d7283ca94e8db333575f339c79df2fd068792f1d6.
Runner SHA49e5ccc0b03c0a011e6200932fab434f8bc24a0d18ff9982c1755bb3ea4e5cb1.
Pinned85runtime extraction and static libgc8.2.8 hashes are in the JSON.
All processes finished; CPU slot was released immediately upon completion.
