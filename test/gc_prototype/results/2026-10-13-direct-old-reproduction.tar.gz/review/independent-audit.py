"""Independent offline audit; no workload execution or runner imports."""
import hashlib
import json
from pathlib import Path
import statistics

D=Path('/tmp/medaka-tree-direct-old-timing-85')
A=json.loads((D/'audit.json').read_text())
R=[json.loads(line) for line in (D/'results.jsonl').read_text().splitlines()]
ARMS=('custom-baseline','custom-direct-old','boehm-historical-default','boehm-historical-fixed128','boehm-caller-default','boehm-caller-fixed128')
CAPS=(262144,262136,16777216,16777208)
N=5000000
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
assert len(R)==144
assert len({(r['round'],r['capacity'],r['arm']) for r in R})==144
expected=[dict(round=q,capacity=n,position=p,arm=ARMS[(q+p)%6]) for q in range(6) for n in CAPS for p in range(6)]
assert [{key:r[key] for key in ('round','capacity','position','arm')} for r in R]==expected==A['schedule']
assert A['input_hashes_before']==A['input_hashes_after']
assert A['binary_hashes_before']==A['binary_hashes_after']
for key in ('input_hashes_before','binary_hashes_before'):
    for path,digest in A[key].items():assert sha(path)==digest,(path,'drift')
assert A['boehm_config']['boehm_linkage']=='static'
assert sha(A['boehm_config']['boehm_archive'])==A['boehm_config']['boehm_archive_sha256']
assert str(Path(A['compiler_executable']).resolve()) in A['input_hashes_before']
for name,digest in A['validated_source_sha256'].items():
    assert sha(D/'build/source'/name)==digest
assert A['build_defines']['custom-direct-old']==A['build_defines']['custom-baseline']+['TREE_DIRECT_OLD']
timed=[x for x in A['commands'] if len(x['command'])==4 and x['command'][1:3]==['tree',str(N)]]
assert len(timed)==144
for r,cmd in zip(R,timed):
    x=r['row'];assert cmd['returncode']==0 and cmd['stderr']==''
    assert cmd['command']==r['command'] and json.loads(cmd['stdout'])==x
    assert r['gc_environment']==({'GC_INITIAL_HEAP_SIZE':'134217728'} if r['arm'].endswith('fixed128') else {})
    assert x['profile']=='tree' and x['count']==N
    assert x['checksum']==N*(N-1)//2 and x['allocations']==N and x['payload_bytes']==N*24
    assert x['elapsed_seconds']>0 and x['process_peak_rss_bytes']>0
    if r['arm'].startswith('boehm'):
        assert x['exact_live_bytes'] is None and x['boehm_free_space_divisor']==1
        assert x['boehm_version_packed']==524808 and x['inline_available']==1
        assert x['boehm_heap_minus_free_bytes']==x['boehm_heap_bytes']-x['boehm_free_bytes']
        continue
    direct=r['arm']=='custom-direct-old'
    values=dict(allocation_header_bytes=N*8,nursery_header_bytes=8,old_header_bytes=8,
        nursery_capacity_bytes=r['capacity'],nursery_used_bytes=0,old_total_allocated_bytes=N*32,
        old_live_bytes=N*32,exact_live_bytes=N*32,exact_live_payload_bytes=N*24,
        old_object_count=N,old_slot_bytes=N*32,peak_old_bytes=N*32,reclaimed_bytes=0,
        pool_count=(N+511)//512,pool_allocations=(N+511)//512,pool_releases=0,
        pool_reused_slots=0,pooled_allocations=N,pool_reserved_bytes=((N+511)//512)*(16384+48),
        peak_pool_reserved_bytes=((N+511)//512)*(16384+48),pool_padding_bytes=0,
        large_reserved_bytes=0,large_metadata_bytes=0,large_object_count=0,
        root_bytes=0,peak_root_bytes=(2+2*N.bit_length())*16,
        nursery_allocations=0 if direct else N,nursery_payload_bytes=0 if direct else N*24,
        direct_old_allocations=N if direct else 0,direct_old_payload_bytes=N*24 if direct else 0,
        promoted_count=0 if direct else N,copied_bytes=0 if direct else N*32,
        copied_payload_bytes=0 if direct else N*24)
    for key,value in values.items():assert x[key]==value,(r['arm'],r['capacity'],key,x[key],value)
    assert x['nursery_allocations']+x['direct_old_allocations']==N
    assert x['old_total_allocated_bytes']-x['reclaimed_bytes']==x['old_live_bytes']
    assert x['accounted_bytes']==sum(x[key] for key in ('nursery_capacity_bytes','pool_reserved_bytes','large_reserved_bytes','descriptor_bytes','work_queue_bytes','remembered_queue_bytes','root_bytes','static_metadata_bytes'))
    assert x['peak_accounted_bytes']>=x['accounted_bytes']
    if direct:assert x['minor_count']==x['major_count']

reduced=[];concrete=[]
for cap in CAPS:
    gs={arm:[r for r in R if r['capacity']==cap and r['arm']==arm] for arm in ARMS}
    group_stats={}
    for arm,g in gs.items():
        assert len(g)==6 and {r['round'] for r in g}==set(range(6)) and {r['position'] for r in g}==set(range(6))
        t=[r['row']['elapsed_seconds'] for r in g];rss=[r['row']['process_peak_rss_bytes'] for r in g]
        group_stats[arm]=dict(seconds=t,seconds_median=statistics.median(t),seconds_range=[min(t),max(t)],
            rss_bytes=rss,rss_median_bytes=statistics.median(rss),rss_range_bytes=[min(rss),max(rss)],
            collection_schedules=[{k:r['row'].get(k) for k in ('minor_count','major_count','copied_bytes','promoted_count')} for r in g])
    direct={r['round']:r['row'] for r in gs['custom-direct-old']};baseline={r['round']:r['row'] for r in gs['custom-baseline']}
    keys=('allocations','payload_bytes','checksum','allocation_header_bytes','old_total_allocated_bytes','old_live_bytes','exact_live_payload_bytes','old_object_count','old_slot_bytes','peak_old_bytes','pool_reserved_bytes','peak_pool_reserved_bytes','pool_count','pool_allocations','pool_releases','pool_reused_slots','root_bytes','peak_root_bytes','descriptor_bytes','descriptor_count','descriptor_bytes_after_prepare','layout_manifest_bytes','static_metadata_bytes')
    for q in range(6):
        for key in keys:assert direct[q][key]==baseline[q][key],(cap,q,key)
    paired={}
    for arm in ARMS:
        if arm=='custom-direct-old':continue
        controls={r['round']:r['row'] for r in gs[arm]}
        t=[direct[q]['elapsed_seconds']/controls[q]['elapsed_seconds'] for q in range(6)]
        rss=[direct[q]['process_peak_rss_bytes']/controls[q]['process_peak_rss_bytes'] for q in range(6)]
        paired[arm]=dict(direct_old_time_ratios=t,median_ratio=statistics.median(t),paired_range=[min(t),max(t)],
            direct_old_rss_ratios=rss,rss_median_ratio=statistics.median(rss),rss_paired_range=[min(rss),max(rss)])
    best=min(ARMS[2:],key=lambda arm:group_stats[arm]['seconds_median'])
    reduced.append(dict(capacity=cap,arms=group_stats,paired_direct_old=paired,fastest_observed_boehm_median_arm=best))
    concrete.append(dict(capacity=cap,baseline_ms=group_stats['custom-baseline']['seconds_median']*1000,
        direct_old_ms=group_stats['custom-direct-old']['seconds_median']*1000,fastest_boehm_ms=group_stats[best]['seconds_median']*1000,
        fastest_boehm_arm=best,paired_time_ratio_median=paired['custom-baseline']['median_ratio'],
        paired_time_ratio_range=paired['custom-baseline']['paired_range'],
        direct_fastest_boehm_ratio_of_medians=group_stats['custom-direct-old']['seconds_median']/group_stats[best]['seconds_median'],
        baseline_rss_mib=group_stats['custom-baseline']['rss_median_bytes']/1048576,
        direct_rss_mib=group_stats['custom-direct-old']['rss_median_bytes']/1048576,
        fastest_boehm_rss_mib=group_stats[best]['rss_median_bytes']/1048576,
        deterministic={k:[baseline[0][k],direct[0][k]] for k in ('minor_count','major_count','work_queue_bytes','remembered_queue_bytes','accounted_bytes','peak_accounted_bytes')}))
assert reduced==A['summary'],'summary disagreement'
report=dict(status='independent read-only audit passed',raw_sha256=sha(D/'results.jsonl'),audit_sha256=sha(D/'audit.json'),
    protocol_sha256=sha(D/'PROTOCOL.md'),runner_sha256=sha(D/'run.py'),rows=144,unique_balanced=True,
    pinned_input_count=len(A['input_hashes_before']),binary_count=4,source_drift=False,summary_exact_match=True,
    concrete_results=concrete,summary=reduced,
    limits=['Placement/allocation order, direct checked call and full zeroing change alongside removal of nursery promotion. This does not isolate copying cost.',
        'Boehm capacity labels are paired controls, not Boehm nursery configurations. Fixed128 initial heap is not a memory cap.',
        'RSS is process high-water, not exact live heap. Combined elapsed includes construction, checksum traversal and final collection; no phase attribution is available.',
        'Frozen protocol status remains SOURCE ONLY although audit records completed execution; preserve original protocol and annotate this historical label when exporting.'])
Path('/tmp/pool-review-direct-old-audit.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({key:value for key,value in report.items() if key!='summary'},indent=2))
