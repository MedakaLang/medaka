"""Independent record audit only; no collector or verifier execution."""
import hashlib
import json
from pathlib import Path
import struct
import tarfile

D=Path('/tmp/medaka-copy-scan-resume-c3f19e532')
V=json.loads((D/'execution/verification.json').read_text())
P=json.loads((D/'postrun-audit.json').read_text())
T=json.loads((D/'toolchain.json').read_text())
J=[json.loads(x) for x in (D/'execution/attempts.jsonl').read_text().splitlines()]
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def digest(b):return hashlib.sha256(b).hexdigest()
assert json.loads((D/'execution-status.json').read_text())['exit_status']==0==P['actual_verifier_process_exit_status']
assert V['execution_performed'] and V['failure'] is None and 'source_check_error' not in V
assert V['frozen_inputs']==V['frozen_inputs_after'] and V['source_closure_before_sha256']==V['source_closure_after_sha256']
for path,h in V['source_closure_before_sha256'].items():assert sha(path)==h
for role in ('runner','fixture'):assert V[role+'_sha256']==V[role+'_sha256_after']
assert sha(D/'execution/verification.json')==P['verification_sha256']
assert sha(D/'execution/attempts.jsonl')==P['attempt_journal_sha256']
assert sha(D/'toolchain.json')==P['toolchain_sha256']
assert sha(T['clang_path'])==T['clang_sha256'] and str(Path(T['clang_path']).resolve())==T['clang_realpath']
frozen=V['frozen_inputs']['source_sha256']
assert frozen['candidate']['gc.c']=='02246c8148d2086ae70aef645305298605b3249c40f2ee666a4b9fb1a217de11'
assert frozen['baseline']['gc.c']=='8b3d4bf65beccb9a019d2330f8266fc5261120140d94b611981add3b720876b4'
for name in ('gc.h','workload.c'):assert frozen['candidate'][name]==frozen['baseline'][name]
AA=json.loads((D/'archive-audit.json').read_text());archive=Path(AA['archive'])
assert sha(archive)==AA['archive_sha256']==P['archive_sha256']
with tarfile.open(archive,'r:gz') as tar:
    members=tar.getmembers();assert len(members)==17==AA['member_count']
    manifest={x['name']:x for x in AA['members']}
    for member in members:
        assert member.isfile() and not Path(member.name).is_absolute() and '..' not in Path(member.name).parts
        data=tar.extractfile(member).read();assert len(data)==manifest[member.name]['bytes'] and digest(data)==manifest[member.name]['sha256']
        assert data==(D/'restore'/member.name).read_bytes()

def needed_libraries(binary):
    data=Path(binary).read_bytes();assert data[:6]==b'\x7fELF\x02\x01'
    off=struct.unpack_from('<Q',data,40)[0];size,count=struct.unpack_from('<HH',data,58)
    result=[]
    for index in range(count):
        section=off+index*size
        if struct.unpack_from('<I',data,section+4)[0]!=6:continue
        offset,length=struct.unpack_from('<QQ',data,section+24)
        link=struct.unpack_from('<I',data,section+40)[0]
        strings=struct.unpack_from('<Q',data,off+link*size+24)[0]
        for pos in range(offset,offset+length,16):
            tag,value=struct.unpack_from('<QQ',data,pos)
            if tag==1:
                start=strings+value;end=data.index(b'\0',start);result.append(data[start:end].decode())
    return result
build_events=[x for x in J if x['kind'] in ('build','build-fallback')]
assert len(V['builds'])==9 and len(build_events)==18
needed={}
for arm,build in V['builds'].items():
    assert sha(build['binary'])==build['binary_sha256']==P['builds'][arm]['binary_sha256']
    assert sha(Path(build['binary']).parent/'gc.c')==build['gc_source_sha256']==P['builds'][arm]['gc_source_sha256']
    attempts=build['build_attempts'];assert len(attempts)==2 and attempts[0]['returncode']==1 and attempts[1]['returncode']==0
    assert 'libclang_rt.asan' in attempts[0]['stderr'] and attempts[1]['stderr']==attempts[1]['stdout']==''
    for attempt in attempts:
        assert '-fsanitize=address,undefined' in attempt['command'] and '-fno-sanitize-recover=all' in attempt['command']
        entry=next(x for x in build_events if x['label']==arm and x['command']==attempt['command'])
        for key in ('returncode','stdout','stderr'):assert entry[key]==attempt[key]
    assert '-fno-sanitize-link-runtime' in attempts[1]['command'] and '-lasan' in attempts[1]['command'] and '-lubsan' in attempts[1]['command']
    needed[arm]=needed_libraries(build['binary']);assert {'libasan.so.8','libubsan.so.1'}<=set(needed[arm])
    assert b'__asan_init' in Path(build['binary']).read_bytes() and b'__ubsan_handle' in Path(build['binary']).read_bytes()
    libraries=P['linked_libraries'][arm];assert libraries['returncode']==0
    for lib in libraries['libraries']:assert sha(lib['path'])==lib['sha256']

cases=('graphs','remembered-chain','payloads','completion','forwarded-alias','barrier-control','lifecycle','direct-old','ledger','root-control','nursery-zero-control')
markers={'mutant-lost-saved-field0':('payloads','raw-field-zero-corrupt'),'mutant-stale-fused-edge':('payloads','rawfield-one-child-stale'),'mutant-missing-raw-tail':('payloads','raw-tail-64-65-corrupt'),'mutant-incomplete-completion':('completion','completion-edge-not-written'),'mutant-root-slot':('root-control','root-slot-not-relocated'),'mutant-write-barrier':('barrier-control','barrier-edge-not-remembered'),'mutant-nursery-zeroing':('nursery-zero-control','nursery-zero-oracle')}
assert len(V['runs'])==29 and len({(r['arm'],r['case']) for r in V['runs']})==29
fixture_events=[x for x in J if x['kind']=='fixture'];starts=[x for x in J if x['kind']=='fixture-start']
assert len(fixture_events)==len(starts)==29
parsed={};snapshot_count=0
for r,entry,start in zip(V['runs'],fixture_events,starts):
    for key in ('command','returncode','stdout','stderr','elapsed_ns'):assert r[key]==entry[key]
    assert r['command']==start['command'] and start['environment']=={'ASAN_OPTIONS':'detect_leaks=0:abort_on_error=1','UBSAN_OPTIONS':'halt_on_error=1:print_stacktrace=1'}
    assert digest(r['stdout'].encode())==r['stdout_sha256'] and digest(r['stderr'].encode())==r['stderr_sha256']
    if r['arm'].startswith('mutant-'):
        case,marker=markers[r['arm']];assert r['case']==case and r['returncode']==86 and r['stdout']=='' and r['stderr']=='FIXTURE_FAIL '+marker+'\n'
        assert start['expected_status']==86 and start['expected_marker']==marker
        continue
    assert r['arm'] in ('baseline','candidate') and r['case'] in cases and r['returncode']==0 and r['stderr']==''
    lines=r['stdout'].splitlines();assert lines[-1]=='FIXTURE_OK '+r['case'] and all(line.startswith('{') for line in lines[:-1])
    snapshots=[json.loads(line) for line in lines[:-1]];assert len(snapshots)==(2 if r['case']=='ledger' else 1)
    assert len({s['stage'] for s in snapshots})==len(snapshots)
    parsed.setdefault(r['arm'],{})[r['case']]={s['stage']:s for s in snapshots};snapshot_count+=len(snapshots)
    for s in snapshots:
        assert len(s)==46 and isinstance(s['stage'],str) and sum(isinstance(v,int) for v in s.values())==45
        assert s['nursery_allocations']+s['direct_old_allocations']==s['allocations'] and s['allocation_header_bytes']==8*s['allocations']
        assert s['nursery_payload_bytes']+s['direct_old_payload_bytes']==s['payload_bytes']
        assert s['old_total_allocated_bytes']-s['reclaimed_bytes']==s['old_live_bytes']
        assert s['exact_live_payload_bytes']+8*s['old_object_count']==s['old_live_bytes']
        assert s['pool_allocations']-s['pool_releases']==s['pool_count']
        assert s['accounted_bytes']==sum(s[k] for k in ('nursery_capacity_bytes','pool_reserved_bytes','large_reserved_bytes','descriptor_bytes','work_queue_bytes','remembered_queue_bytes','root_bytes','static_metadata_bytes'))
        assert s['peak_accounted_bytes']>=s['accounted_bytes']
assert parsed==V['paired_stats'] and parsed['baseline']==parsed['candidate'] and snapshot_count==24
assert set(parsed['baseline'])==set(cases)
for case,stages in parsed['baseline'].items():
    recorded=P['statistics_snapshot_audit'][case]
    assert sorted(stages)==recorded['stages']
    for stage,s in stages.items():assert sorted(s)==recorded['fields_by_stage'][stage] and len(s)==recorded['field_count_by_stage'][stage]
report=dict(status='PASS independent record audit; no native execution',positive_runs=22,negative_runs=7,
    paired_stages=12,fields_per_stage=46,numeric_fields_per_stage=45,total_snapshot_rows=24,
    build_failures_expected_missing_clang_runtime=9,successful_instrumented_system_runtime_builds=9,
    needed_libraries=needed,source_archive_sha256=sha(archive),verification_sha256=sha(D/'execution/verification.json'),
    journal_sha256=sha(D/'execution/attempts.jsonl'),postrun_audit_sha256=sha(D/'postrun-audit.json'),
    source_and_binary_identities_verified=True,
    limits=['Correctness-only sanitized-O1 fixture evidence, not performance or compiler integration.',
        'LeakSanitizer disabled under ptrace; address and undefined-behavior instrumentation and runtime linkage verified.',
        'Runner overrides ASAN/UBSAN and removes LSAN_OPTIONS but otherwise inherits process environment; toolchain records selected variables, not a hermetic execution environment.',
        'Compiler/source identities are recorded; installed runtime library hashes are post-run receipts, not an independently frozen full-system header/runtime closure.'],
    meaningful_gaps='No contradiction in executed positive/mutation/statistics evidence; broader full-suite verification is a separate pending job.')
Path('/tmp/pool-review-copy-scan-verifier-audit.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
