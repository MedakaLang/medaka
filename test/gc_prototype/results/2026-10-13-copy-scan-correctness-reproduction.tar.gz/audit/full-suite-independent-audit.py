"""Read-only independent reduction of full Variant-V correctness records."""
import collections
import hashlib
import json
from pathlib import Path

D=Path('/tmp/medaka-copy-scan-full-correctness-c3f19e532')
A=json.loads((D/'execution.json').read_text());P=json.loads((D/'postrun-audit.json').read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert A['status']=='passed' and A['actual_runner_returncode']==P['actual_process_exit']==0 and A['inputs_unchanged']
prep=A['prepared'];assert prep['candidate_sha256']['gc.c']=='02246c8148d2086ae70aef645305298605b3249c40f2ee666a4b9fb1a217de11'
for name,digest in prep['input_sha256'].items():assert sha(D/'inputs'/name)==digest
assert sha(prep['module'])==prep['module_sha256']=='151505c92ac42732de5ca975f61ba65b4592eb55e37fad1a676040488bb59695'
assert sha(D/'run_review.py')==prep['driver_sha256']
assert sha(D/'observer/sitecustomize.py')==prep['child_observer_sha256']
assert (D/'run_review.py').read_text()==prep['driver_text'] and (D/'observer/sitecustomize.py').read_text()==prep['child_observer_text']
assert sha(D/'pinned_repo/runtime/medaka_rt.c')==prep['runtime_sha256']=='5ca4ce0a019cabf73ae24ce576223ff13c7536a9ae98f472c5c8371ce45b7667'
assert sha(A['compiler_executable'])==A['compiler_sha256']=='0a3c55936ac43954fbe4914e6e73b577ca9e35e75d89ef13d3e28c187f41ca1a'
assert sha('/usr/lib/x86_64-linux-gnu/libgc.a')==A['boehm_archive_sha256']=='337a7cf7e9ff4a161025fc07b67ea0b613338dfc14ea510033d9c4e102a37045'
assert [json.loads(x) for x in (D/'child-commands.jsonl').read_text().splitlines()]==A['nested_commands']
assert (D/'stdout.log').read_text()==A['stdout'] and (D/'stderr.log').read_text()==A['stderr']==''
outer=A['commands'];nested=A['nested_commands']
def compile(r):return '-o' in r['argv'] and r['argv'][0]==A['compiler_executable']
def native(r):return r['argv'][0].startswith(str(D)+'/medaka-gc-')
success_outer=[x for x in outer if compile(x) and x['returncode']==0]
success_nested=[x for x in nested if compile(x) and x['returncode']==0]
fail_outer=[x for x in outer if compile(x) and x['returncode']!=0]
fail_nested=[x for x in nested if compile(x) and x['returncode']!=0]
assert len(success_outer)==19 and len(success_nested)==5 and len(fail_outer)==4 and len(fail_nested)==1
for r in success_outer+success_nested:assert r['stderr']==r['stdout']=='' and len(r['binary_sha256'])==64
for r in fail_outer+fail_nested:
    assert r['returncode']==1 and 'libclang_rt.asan' in r['stderr'] and r['stdout']=='' and '-fsanitize=address,undefined' in r['argv']
    target=r['argv'][r['argv'].index('-o')+1]
    matching=[x for x in success_outer+success_nested if x['argv'][x['argv'].index('-o')+1]==target]
    assert len(matching)==1
    assert all(flag in matching[0]['argv'] for flag in ('-fsanitize=address,undefined','-fno-sanitize-link-runtime','-lasan','-lubsan'))
positives_outer=[x for x in outer if native(x) and x['returncode']==0]
positives_nested=[x for x in nested if native(x) and x['returncode']==0]
negatives_outer=[x for x in outer if native(x) and x['returncode']!=0]
negatives_nested=[x for x in nested if native(x) and x['returncode']!=0]
assert len(positives_outer)==200 and len(positives_nested)==3 and len(negatives_outer)==8 and len(negatives_nested)==2
for r in positives_outer+positives_nested:assert r['stderr']==''
for r in negatives_outer:
    assert r['returncode']==-6 and r['stdout']==''
    name=Path(r['argv'][0]).name
    messages={'prepared_gc_mutate_roots':'prepared-api assertion: prepared root relocation\n',
        'prepared_gc_mutate_zero':'prepared-api assertion: prepared zero initialization\n',
        'prepared_gc_mutate_barrier':'prepared-api assertion: prepared direct-old initialization barrier\n'}
    if name in messages:assert r['stderr']==messages[name]
    else:
        assert name in ('gc_mutate_roots','gc_mutate_barrier')
        assert ("Assertion `a != before' failed." if name=='gc_mutate_roots' else "Assertion `load(a, 1) != child' failed.") in r['stderr']
    assert not any(x in r['stderr'] for x in ('AddressSanitizer','runtime error:','DEADLYSIGNAL'))
assert [(Path(r['argv'][0]).name,r['returncode'],r['stderr']) for r in negatives_nested]==[
    ('missing-reload',1,'LLVM contract: moved root reload failed\n'),
    ('missing-argument',2,'LLVM contract: earlier argument relocation failed\n')]
names=collections.Counter(Path(r['argv'][0]).name for r in positives_outer)
assert names['prepared_api_sanitized']==46 and names['pool_review_sanitized']==21 and names['custom_adversarial_sanitized']==35 and names['custom_sanitized']==18
ordinary=('custom','custom_P','custom_K','custom_A','custom_S','custom_AS','boehm','boehm_inline','boehm_prepared_outline','boehm_caller_inline')
for name in ordinary:
    tests=[r for r in positives_outer if Path(r['argv'][0]).name==name]
    assert len(tests)==8 and sum(r['argv'][1]=='--selftest' for r in tests)==1
    for r in tests:
        if r['argv'][1]=='--selftest':assert r['stdout']=='selftest passed\n';continue
        x=json.loads(r['stdout']);profile=r['argv'][1];count=int(r['argv'][2]);assert count==1024
        assert x['profile']==profile and x['allocations']==count+(profile=='mutation') and x['checksum']==count*(count-1)//2
for p,runs in ((P['main_positive_processes'],positives_outer),(P['llvm_positive_processes'],positives_nested),
               (P['main_expected_negative_processes'],negatives_outer),(P['llvm_expected_negative_processes'],negatives_nested)):
    assert p==len(runs)
assert P['positive_fixture_processes']==203 and P['expected_negative_processes']==10 and P['successful_builds']==24 and P['preserved_default_sanitizer_link_failures']==5
assert P['binary_hashes']==[{'argv':r['argv'],'binary_sha256':r['binary_sha256']} for r in success_outer+success_nested]
report=dict(status='PASS independent offline full-suite evidence audit',execution_sha256=sha(D/'execution.json'),postrun_audit_sha256=sha(D/'postrun-audit.json'),
    successful_outer_builds=19,successful_nested_llvm_builds=5,expected_initial_sanitizer_link_failures=5,
    positive_native_fixtures=203,expected_negative_native_fixtures=10,
    positive_breakdown=dict(backend_selftests=10,backend_profile_smokes=70,sanitized_prepared_boundaries=18,prepared_api=46,pool_review=21,adversarial=35,llvm=3),
    source_compiler_static_boehm_runtime_observer_driver_hashes_verified=True,assertion_changes='none',
    limits=['Full-suite temporary fixture binaries were removed by the unchanged runner; build hashes are captured receipts, not current-file rehash claims.',
        'This is correctness-only C/LLVM validation, not a performance screen or application/compiler moving-GC integration.',
        'ASan/UBSan compile instrumentation retained through recorded GCC runtime fallback; LeakSanitizer disabled under ptrace.',
        'Pinned collector/helper/runtime source and toolchain identities are recorded; no full host/sysroot reconstruction claim.'])
Path('/tmp/pool-review-copy-scan-full-audit.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
