import argparse
import contextlib
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

ROOT=Path('/root/.codex/worktrees/f396/medaka')
OUT=Path(__file__).resolve().parent
FROZEN=Path('/tmp/medaka-copy-scan-resume-c3f19e532/restore/sources')
PINNED_REPO=OUT/'pinned_repo'
INPUTS=OUT/'inputs'
FILES=('gc.h','gc.c','workload.c','run.py','adversarial.c','pool_review.c','prepared_api.c',
       'llvm_contract/contract.ll','llvm_contract/driver.c','llvm_contract/validate_llvm.py')

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def prepare():
    manifest=json.loads((FROZEN/'manifest.json').read_text())
    INPUTS.mkdir(exist_ok=True)
    for name in FILES:
        source=FROZEN/'candidate'/name if name in ('gc.c','gc.h','workload.c') else ROOT/'test/gc_prototype'/name
        destination=INPUTS/name
        destination.parent.mkdir(exist_ok=True,parents=True)
        shutil.copyfile(source,destination)
        if name in ('gc.c','gc.h','workload.c'):
            assert sha(destination)==manifest['source_sha256']['candidate'][name]
        else:
            assert destination.read_bytes()==source.read_bytes()
    assert sha(INPUTS/'gc.c')=='02246c8148d2086ae70aef645305298605b3249c40f2ee666a4b9fb1a217de11'
    for name in ('gc.h','workload.c'):
        original=subprocess.check_output(['git','show',manifest['baseline_commit']+':test/gc_prototype/'+name],cwd=ROOT)
        assert (INPUTS/name).read_bytes()==original
    for name in ('gc.h','workload.c'):
        assert (INPUTS/name).read_bytes()==(FROZEN/'baseline'/name).read_bytes()
    runtime=subprocess.check_output(['git','show',manifest['baseline_commit']+':runtime/medaka_rt.c'],cwd=ROOT)
    (PINNED_REPO/'runtime').mkdir(parents=True,exist_ok=True)
    (PINNED_REPO/'runtime/medaka_rt.c').write_bytes(runtime)
    assert hashlib.sha256(runtime).hexdigest()=='5ca4ce0a019cabf73ae24ce576223ff13c7536a9ae98f472c5c8371ce45b7667'
    archive=ROOT/'test/gc_prototype/results/2026-10-13-copy-scan-source-reproduction.tar.gz'
    assert sha(archive)=='0e76460f8d7a06c32bb83ebb0c304c81bbe8c51efc3d44d34ecd3490264ee067'
    assert sha(INPUTS/'run.py')=='151505c92ac42732de5ca975f61ba65b4592eb55e37fad1a676040488bb59695'
    record={'mode':'Variant V full unchanged prototype correctness; no timing execution',
            'archive_sha256':sha(archive),'baseline_commit':manifest['baseline_commit'],
            'workspace_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),
            'adapter_input_override':str(PINNED_REPO/'runtime/medaka_rt.c'),
            'historical_source_only_record':'preserved unchanged; this external record describes resumed execution',
            'child_observer_text':(OUT/'observer/sitecustomize.py').read_text(),
            'child_observer_sha256':sha(OUT/'observer/sitecustomize.py'),
            'module':str(ROOT/'test/gc_prototype/run.py'),
            'module_sha256':sha(ROOT/'test/gc_prototype/run.py'),
            'HERE_override':str(INPUTS),'REPO_override':str(ROOT),
            'argv':['run.py','--correctness-only'],
            'candidate_sha256':manifest['source_sha256']['candidate'],
            'input_sha256':{name:sha(INPUTS/name) for name in FILES},
            'runtime_sha256':hashlib.sha256(runtime).hexdigest(),
            'assertion_changes':'none; existing assertions derive actual static/work metadata dynamically',
            'driver_text':Path(__file__).read_text(),'driver_sha256':sha(Path(__file__))}
    (OUT/'preparation.json').write_text(json.dumps(record,indent=2)+'\n')
    return record

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--execute',action='store_true')
    args=parser.parse_args()
    prepared=prepare()
    if not args.execute:
        print(json.dumps({'prepared':True,'execution_performed':False,'input_sha256':prepared['input_sha256']}))
        return
    assert not (OUT/'execution.json').exists(), 'preserve prior execution evidence'
    for name in list(os.environ):
        if name.startswith(('GC_','MEDAKA_')) or name in ('ASAN_OPTIONS','UBSAN_OPTIONS'):
            os.environ.pop(name)
    compiler=Path(shutil.which('clang')).resolve()
    assert sha(compiler)=='0a3c55936ac43954fbe4914e6e73b577ca9e35e75d89ef13d3e28c187f41ca1a'
    archive=Path('/usr/lib/x86_64-linux-gnu/libgc.a')
    assert sha(archive)=='337a7cf7e9ff4a161025fc07b67ea0b613338dfc14ea510033d9c4e102a37045'
    os.environ.update(CC=str(compiler),ASAN_OPTIONS='detect_leaks=0',UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1',TMPDIR=str(OUT))
    spec=importlib.util.spec_from_file_location('unchanged_gc_correctness',ROOT/'test/gc_prototype/run.py')
    module=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    module.HERE=INPUTS
    module.REPO=ROOT
    original_adapter=module.adapter
    def pinned_adapter(directory):
        previous=module.REPO
        module.REPO=PINNED_REPO
        try:
            result=original_adapter(directory)
            assert sha(directory/'boehm_adapter.c')=='e1c59e81beb74d163ad96d9adfccae819319fffbb999a8d13f12c47c21f2cf4c'
            assert sha(directory/'boehm_caller.h')=='5ea44cdef51ef719e43e57e07f73d811873cb4d8b0043117c5706bda071c3e4c'
            return result
        finally:
            module.REPO=previous
    module.adapter=pinned_adapter
    os.environ['PYTHONPATH']=str(OUT/'observer')
    os.environ['REVIEW_CHILD_LOG']=str(OUT/'child-commands.jsonl')
    real_run=subprocess.run
    commands=[]
    def observed_run(*argv,**kwargs):
        command=argv[0] if argv else kwargs['args']
        env=kwargs.get('env',os.environ)
        record={'argv':[str(x) for x in command],
                'environment':{k:v for k,v in env.items() if k.startswith('GC_') or k in ('CC','ASAN_OPTIONS','UBSAN_OPTIONS')},
                'cwd':str(kwargs.get('cwd',Path.cwd()))}
        try:
            result=real_run(*argv,**kwargs)
            record.update(returncode=result.returncode,stdout=result.stdout,stderr=result.stderr)
            if result.returncode==0 and '-o' in command:
                binary=Path(command[command.index('-o')+1])
                if binary.is_file(): record['binary_sha256']=sha(binary)
            return result
        except subprocess.CalledProcessError as error:
            record.update(returncode=error.returncode,stdout=error.stdout,stderr=error.stderr)
            raise
        except BaseException as error:
            record.update(error=repr(error))
            raise
        finally:
            commands.append(record)
    execution={'prepared':prepared,'compiler_executable':str(compiler),'compiler_sha256':sha(compiler),'boehm_archive_sha256':sha(archive),'status':'running'}
    subprocess.run=observed_run
    sys.argv=['run.py','--correctness-only']
    try:
        with (OUT/'stdout.log').open('w') as stdout, (OUT/'stderr.log').open('w') as stderr:
            with contextlib.redirect_stdout(stdout), contextlib.redirect_stderr(stderr):
                module.main()
        assert {name:sha(INPUTS/name) for name in FILES}==prepared['input_sha256']
        assert sha(ROOT/'test/gc_prototype/run.py')==prepared['module_sha256']
        execution['status']='passed'
        execution['actual_runner_returncode']=0
    except BaseException as error:
        execution['status']='failed'
        execution['error']=repr(error)
        raise
    finally:
        subprocess.run=real_run
        execution['commands']=commands
        execution['build_commands']=module.BUILD_COMMANDS
        execution['nested_commands']=[json.loads(line) for line in (OUT/'child-commands.jsonl').read_text().splitlines()] if (OUT/'child-commands.jsonl').exists() else []
        execution['inputs_unchanged']={name:sha(INPUTS/name) for name in FILES}==prepared['input_sha256']
        execution['stdout']=(OUT/'stdout.log').read_text()
        execution['stderr']=(OUT/'stderr.log').read_text()
        (OUT/'execution.json').write_text(json.dumps(execution,indent=2)+'\n')
    print(json.dumps({'status':execution['status'],'actual_runner_returncode':execution['actual_runner_returncode'],
                      'stdout_tail':execution['stdout'].splitlines()[-5:],'execution':str(OUT/'execution.json')}))

if __name__=='__main__':
    main()
