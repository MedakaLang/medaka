# Observer only: calls delegate with original arguments, return value and exceptions.
import hashlib,json,os,subprocess
from pathlib import Path
_original=subprocess.run
_log=os.environ.get('REVIEW_CHILD_LOG')
def _observed(*args,**kwargs):
    command=args[0] if args else kwargs['args']
    record={'argv':[str(x) for x in command],'cwd':str(kwargs.get('cwd',Path.cwd()))}
    try:
        result=_original(*args,**kwargs)
        record.update(returncode=result.returncode,stdout=result.stdout,stderr=result.stderr)
        if result.returncode==0 and '-o' in command:
            binary=Path(command[command.index('-o')+1])
            if binary.is_file(): record['binary_sha256']=hashlib.sha256(binary.read_bytes()).hexdigest()
        return result
    except subprocess.CalledProcessError as error:
        record.update(returncode=error.returncode,stdout=error.stdout,stderr=error.stderr)
        raise
    except BaseException as error:
        record.update(error=repr(error))
        raise
    finally:
        with open(_log,'a') as stream: stream.write(json.dumps(record)+'\n')
if _log: subprocess.run=_observed
