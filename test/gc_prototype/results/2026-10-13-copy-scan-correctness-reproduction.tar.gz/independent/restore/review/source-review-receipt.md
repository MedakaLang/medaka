# Independent source-only review receipts

Reviewer: /root/nursery_prototype. Receipts below were transcribed from the
reviewer's collaboration messages by /root/fast_alloc_design for this handoff.
They establish source review only: collector and fixtures remain UNBUILT and
UNEXECUTED, and verification --execute has never run.

## Candidate implementation

Reviewed gc.c SHA256:
02246c8148d2086ae70aef645305298605b3249c40f2ee666a4b9fb1a217de11.
Patch e97c051161239574fb9e20f7cd33b566b83656c22406b39267dbbef9490831ee;
source manifest 026be9dfb958a619b1919bbd2ed67860d0054e575c269e1a250596f27f42b1d7.

> Read-only variant V implementation PASS at gc.c SHA02246c8148d2086ae70aef645305298605b3249c40f2ee666a4b9fb1a217de11; patch e97c0511 and manifest026be9df verified. Exact85 gc.h/workload unchanged. Traced field0 saved before forwarding; later source words never overwritten; source Header* entries pop before child promotion and destination descriptors are authoritative. Aliases/cycles return forwarded destination without unfinished-field reads. Bit63 shift guarded; raw64+ copied; mask0 fullcopy retained. Remembered scan, public/direct-old zeroing, major marking and accounting unchanged; minor drains before poison/major. No findings requiring fixes; tests must establish asserted counter/storage/order equality and fail controls. No builds/tests/edits.

## Final independent verifier

Fixture SHA256 509c3a253b2d75dde0789f87b4ba2e107d983b5b3d843e143093f1f62f33293a;
runner SHA256 3c345ad5290bd7773a5adc4409e690a66d78da59c53b5535d98ce24448ffd4c8.

> Final source-only verifier review PASS for handoff: fixture.c SHA509c3a253b2d75dde0789f87b4ba2e107d983b5b3d843e143093f1f62f33293a; run.py SHA3c345ad5290bd7773a5adc4409e690a66d78da59c53b5535d98ce24448ffd4c8. Paths /tmp/medaka-copy-scan-fusion-85/verification/{fixture.c,run.py}. Candidate remains reviewed02246c8148d2086ae70aef645305298605b3249c40f2ee666a4b9fb1a217de11. Fix round addressed cumulative promotion count, exact success markers, source-root relocation, controlled-zero field0 mutation, promote-then-stale edge, deterministic nursery poison, complete snapshots/old_limit and failure journaling/hash rejection. Planned scope: 22 positive ASan/UBSan executions (11 cases×2 arms), seven named negative controls, nine compiled arms; all UNBUILT/UNEXECUTED. Named controls inspect raw bytes/equalities/full nursery range before unexpected-edge dereference; range checks are not general arbitrary-pointer authentication. Runner requires exact status86+marker, rejects sanitizer/crash/timeout grades, journals start/result and preserves failed verification records. Every printed counter/storage snapshot plus old-limit compares exactly across arms. No timings, selection or execution PASS implied; include this receipt as source-only review evidence.

The source-only plan.json was subsequently supplied by verifier owner
/root/pool_verify, SHA256 dbffb5d69954165f4a11d66c03ca38fc952aaef97c06c31fcececabaa2dc5867.
It reports execution_performed=false. The owner ran preparation metadata/Python
syntax checks only; no C builds, collector/fixture executions or timings occurred.
