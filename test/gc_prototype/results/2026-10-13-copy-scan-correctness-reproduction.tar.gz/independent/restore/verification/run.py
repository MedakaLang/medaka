#!/usr/bin/env python3
"""Prepared independent Variant-V checks. Execution is separately gated by --execute."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
FIXTURE = HERE / "fixture.c"
CASES = ("graphs", "remembered-chain", "payloads", "completion",
         "forwarded-alias", "barrier-control", "lifecycle", "direct-old", "ledger",
         "root-control", "nursery-zero-control")
TIMEOUT_BUILD_SECONDS = 60
TIMEOUT_CASE_SECONDS = 10
DEFAULT_PACKET = Path("/tmp/medaka-copy-scan-fusion-plan.md")
SANITIZER_ENV = {
    "ASAN_OPTIONS": "detect_leaks=0:abort_on_error=1",
    "UBSAN_OPTIONS": "halt_on_error=1:print_stacktrace=1",
}


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def append_journal(path: Path, row: dict) -> None:
    with path.open("a", encoding="utf-8") as stream:
        stream.write(json.dumps(row, sort_keys=True) + "\n")
        stream.flush()
        os.fsync(stream.fileno())


def frozen_inputs(source_root: Path, packet: Path) -> dict:
    manifest_path = source_root / "manifest.json"
    manifest = json.loads(manifest_path.read_text())
    got: dict[str, dict[str, str]] = {}
    for arm in ("baseline", "candidate"):
        got[arm] = {}
        for name, expected in manifest["source_sha256"][arm].items():
            path = source_root / arm / name
            actual = sha(path.read_bytes())
            if actual != expected:
                raise RuntimeError(f"frozen {arm}/{name} drift: {actual} != {expected}")
            got[arm][name] = actual
    expected_packet = manifest["packet_sha256"]
    actual_packet = sha(packet.read_bytes())
    if actual_packet != expected_packet:
        raise RuntimeError(f"packet drift: {actual_packet} != {expected_packet}")
    if got["baseline"]["gc.h"] != got["candidate"]["gc.h"] or \
       got["baseline"]["workload.c"] != got["candidate"]["workload.c"]:
        raise RuntimeError("V arms do not share frozen header/workload")
    return {"source_sha256": got, "manifest_sha256": sha(manifest_path.read_bytes()),
            "packet_sha256": actual_packet}


def replace_once(text: str, old: str, new: str, label: str) -> str:
    count = text.count(old)
    if count != 1:
        raise RuntimeError(f"{label}: expected one source anchor, found {count}")
    return text.replace(old, new, 1)


def candidate_mutants(text: str) -> dict[str, tuple[str, str, str]]:
    # Each selected case must trip the named byte/range oracle before graph traversal.
    lost_field0 = replace_once(
        text,
        "  if (d.mask) ((Word *)(to + 1))[0] = ((Word *)(from + 1))[0];\n",
        "  if (d.mask) ((Word *)(to + 1))[0] = 0; /* controlled saved-field0 corruption */\n",
        "lost-saved-field0")
    stale_edge = replace_once(
        text,
        "      fields[i] = i < 64 && ((d.mask >> i) & 1) ? promote(source[i]) : source[i];\n",
        "      fields[i] = i < 64 && ((d.mask >> i) & 1) ? (promote(source[i]), source[i]) : source[i];\n",
        "stale-fused-edge")
    missing_tail = replace_once(
        text,
        "      fields[i] = i < 64 && ((d.mask >> i) & 1) ? promote(source[i]) : source[i];\n",
        "      fields[i] = i < 64 && ((d.mask >> i) & 1) ? promote(source[i]) : (i >= 64 ? 0 : source[i]);\n",
        "missing-raw-tail")
    incomplete = replace_once(
        text,
        "  Descriptor d = *descriptor(to);\n  Word *fields = (Word *)(to + 1), *source = (Word *)(from + 1);\n",
        "  Descriptor d = *descriptor(to);\n  Word *fields = (Word *)(to + 1), *source = (Word *)(from + 1);\n"
        "  (void)d; (void)fields; (void)source; return; /* mutation: skip completion */\n",
        "incomplete-completion")
    return {
        "lost-saved-field0": (lost_field0, "payloads", "raw-field-zero-corrupt"),
        "stale-fused-edge": (stale_edge, "payloads", "rawfield-one-child-stale"),
        "missing-raw-tail": (missing_tail, "payloads", "raw-tail-64-65-corrupt"),
        "incomplete-completion": (incomplete, "completion", "completion-edge-not-written"),
    }


def source_closure(source_root: Path, packet: Path) -> dict[str, str]:
    paths = [source_root / "manifest.json", source_root / "copy-scan-fusion-v.patch",
             packet, FIXTURE, Path(__file__)]
    for arm in ("baseline", "candidate"):
        paths.extend(source_root / arm / name for name in ("gc.c", "gc.h", "workload.c"))
    result = {}
    for path in paths:
        result[str(path)] = sha(path.read_bytes())
    return result


def build(cc: str, source_root: Path, gc_text: str, label: str, output: Path,
          journal: Path, define: str | None = None) -> dict:
    build_dir = output / "builds" / label
    build_dir.mkdir(parents=True, exist_ok=False)
    gc_copy = build_dir / "gc.c"
    gc_copy.write_text(gc_text)
    exe = build_dir / "fixture"
    cmd = [cc, "-std=c11", "-O1", "-g", "-fno-omit-frame-pointer",
           "-fsanitize=address,undefined", "-fno-sanitize-recover=all",
           "-I", str(source_root / "candidate"), str(FIXTURE), str(gc_copy), "-o", str(exe)]
    if define:
        cmd.insert(1, f"-D{define}")
    attempts = []
    append_journal(journal, {"kind": "build-start", "label": label, "command": cmd,
                             "timeout_seconds": TIMEOUT_BUILD_SECONDS})
    started = time.monotonic_ns()
    try:
        cp = subprocess.run(cmd, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                            timeout=TIMEOUT_BUILD_SECONDS)
    except subprocess.TimeoutExpired as exc:
        row = {"kind": "build", "label": label, "command": cmd, "status": "timeout",
               "timeout_seconds": TIMEOUT_BUILD_SECONDS,
               "stdout": exc.stdout.decode(errors="replace") if isinstance(exc.stdout, bytes) else (exc.stdout or ""),
               "stderr": exc.stderr.decode(errors="replace") if isinstance(exc.stderr, bytes) else (exc.stderr or ""),
               "elapsed_ns": time.monotonic_ns() - started}
        append_journal(journal, row)
        raise RuntimeError(f"build timeout for {label}: {cmd}") from exc
    attempts.append({"command": cmd, "returncode": cp.returncode,
                     "stdout": cp.stdout, "stderr": cp.stderr})
    append_journal(journal, {"kind": "build", "label": label, "command": cmd,
                             "returncode": cp.returncode, "stdout": cp.stdout,
                             "stderr": cp.stderr, "elapsed_ns": time.monotonic_ns() - started})
    if cp.returncode and ("libclang_rt.asan" in cp.stderr or "libclang_rt.ubsan" in cp.stderr):
        fallback = [cc, "-fno-sanitize-link-runtime", "-Wl,--no-as-needed", "-lasan", "-lubsan",
                    "-Wl,--as-needed", *cmd[1:]]
        started = time.monotonic_ns()
        append_journal(journal, {"kind": "build-fallback-start", "label": label,
                                 "command": fallback, "timeout_seconds": TIMEOUT_BUILD_SECONDS})
        try:
            cp = subprocess.run(fallback, text=True, stdout=subprocess.PIPE,
                                stderr=subprocess.PIPE, timeout=TIMEOUT_BUILD_SECONDS)
        except subprocess.TimeoutExpired as exc:
            row = {"kind": "build-fallback", "label": label, "command": fallback,
                   "status": "timeout", "timeout_seconds": TIMEOUT_BUILD_SECONDS,
                   "stdout": exc.stdout.decode(errors="replace") if isinstance(exc.stdout, bytes) else (exc.stdout or ""),
                   "stderr": exc.stderr.decode(errors="replace") if isinstance(exc.stderr, bytes) else (exc.stderr or ""),
                   "elapsed_ns": time.monotonic_ns() - started}
            append_journal(journal, row)
            raise RuntimeError(f"sanitizer fallback timeout for {label}: {fallback}") from exc
        attempts.append({"command": fallback, "returncode": cp.returncode,
                         "stdout": cp.stdout, "stderr": cp.stderr})
        append_journal(journal, {"kind": "build-fallback", "label": label,
                                 "command": fallback, "returncode": cp.returncode,
                                 "stdout": cp.stdout, "stderr": cp.stderr,
                                 "elapsed_ns": time.monotonic_ns() - started})
    if cp.returncode:
        raise RuntimeError(f"build failed for {label}: {cp.returncode}: {cp.stderr}")
    return {"command": cmd, "build_attempts": attempts, "binary": str(exe),
            "binary_sha256": sha(exe.read_bytes()), "gc_source_sha256": sha(gc_copy.read_bytes())}


def run_case(exe: Path, case: str, output: Path, journal: Path,
             status: int = 0, marker: str | None = None) -> dict:
    env = os.environ.copy()
    env.update(SANITIZER_ENV)
    env.pop("LSAN_OPTIONS", None)
    cmd = [str(exe), case]
    started = time.monotonic_ns()
    append_journal(journal, {"kind": "fixture-start", "case": case, "command": cmd,
                             "expected_status": status, "expected_marker": marker,
                             "timeout_seconds": TIMEOUT_CASE_SECONDS,
                             "environment": SANITIZER_ENV})
    try:
        cp = subprocess.run(cmd, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                            env=env, timeout=TIMEOUT_CASE_SECONDS)
    except subprocess.TimeoutExpired as exc:
        append_journal(journal, {"kind": "fixture", "case": case, "command": cmd,
                                 "status": "timeout", "expected_status": status,
                                 "expected_marker": marker, "timeout_seconds": TIMEOUT_CASE_SECONDS,
                                 "stdout": exc.stdout.decode(errors="replace") if isinstance(exc.stdout, bytes) else (exc.stdout or ""),
                                 "stderr": exc.stderr.decode(errors="replace") if isinstance(exc.stderr, bytes) else (exc.stderr or ""),
                                 "elapsed_ns": time.monotonic_ns() - started})
        raise RuntimeError(f"fixture timeout {cmd}: {exc}") from exc
    elapsed = time.monotonic_ns() - started
    append_journal(journal, {"kind": "fixture", "case": case, "command": cmd,
                             "returncode": cp.returncode, "expected_status": status,
                             "expected_marker": marker, "stdout": cp.stdout,
                             "stderr": cp.stderr, "elapsed_ns": elapsed})
    if cp.returncode != status:
        raise RuntimeError(f"{cmd}: exit {cp.returncode}, expected {status}; stdout={cp.stdout!r}; stderr={cp.stderr!r}")
    if marker:
        if cp.stderr.strip() != f"FIXTURE_FAIL {marker}" or cp.stdout:
            raise RuntimeError(f"{cmd}: expected only named oracle {marker!r}; stdout={cp.stdout!r}; stderr={cp.stderr!r}")
        if any(s in cp.stderr for s in ("AddressSanitizer", "UndefinedBehaviorSanitizer", "runtime error:")):
            raise RuntimeError(f"{cmd}: sanitizer failure is not a valid mutation grade")
    elif cp.stderr:
        raise RuntimeError(f"{cmd}: positive fixture wrote stderr: {cp.stderr!r}")
    (output / "last-stdout.txt").write_text(cp.stdout)
    return {"command": cmd, "returncode": cp.returncode, "elapsed_ns": elapsed,
            "stdout": cp.stdout, "stderr": cp.stderr,
            "stdout_sha256": sha(cp.stdout.encode()), "stderr_sha256": sha(cp.stderr.encode())}


def stats_rows(stdout: str) -> dict[str, dict]:
    found = {}
    for line in stdout.splitlines():
        if line.startswith("{"):
            row = json.loads(line)
            found[row["stage"]] = row
    return found


def check_positive(stdout: str, case: str) -> dict[str, dict]:
    if f"FIXTURE_OK {case}" not in stdout:
        raise RuntimeError(f"positive {case} did not print its exact success marker")
    return stats_rows(stdout)


def run_plan(source_root: Path, packet: Path) -> dict:
    frozen = frozen_inputs(source_root, packet)
    candidate_text = (source_root / "candidate/gc.c").read_text()
    mutants = candidate_mutants(candidate_text)
    return {
        "execution_performed": False,
        "frozen_inputs": frozen,
        "fixture_sha256": sha(FIXTURE.read_bytes()),
        "runner_sha256": sha(Path(__file__).read_bytes()),
        "source_closure_sha256": source_closure(source_root, packet),
        "compiler_candidate": shutil.which("clang"),
        "positive_cases": list(CASES),
        "mutation_sources": {name: {"gc_source_sha256": sha(text.encode()), "case": case,
                                    "expected_marker": marker}
                             for name, (text, case, marker) in mutants.items()},
        "additional_mutants": {
            "root-slot": {"define": "GC_MUTATE_ROOTS", "case": "root-control",
                          "marker": "root-slot-not-relocated"},
            "write-barrier": {"define": "GC_MUTATE_BARRIER", "case": "barrier-control",
                              "marker": "barrier-edge-not-remembered"},
            "nursery-zeroing": {"define": "GC_MUTATE_ZERO", "case": "nursery-zero-control",
                                "marker": "nursery-zero-oracle"},
        },
        "build_policy": {"flags": ["-std=c11", "-O1", "-g", "-fno-omit-frame-pointer",
                                     "-fsanitize=address,undefined", "-fno-sanitize-recover=all"],
                         "timeout_seconds": TIMEOUT_BUILD_SECONDS,
                         "fallback": "external -lasan/-lubsan only if Clang bundled sanitizer runtime is missing"},
        "run_policy": {"timeout_seconds": TIMEOUT_CASE_SECONDS, **SANITIZER_ENV,
                       "LSan": "disabled; existing environment aborts LSan under ptrace",
                       "mutation_grade": "expected status 86 plus exact FIXTURE_FAIL marker; sanitizer failures/timeouts do not grade"},
        "paired_invariants": ["all fixture success markers and every JSON stats/storage snapshot match exactly between baseline and V",
                              "all post-minor traced roots and checked edges rejected if inside entire nursery capacity before dereference",
                              "raw-field0/traced-child1, bit63, raw tails64/65, atomic bytes, graph aliases/cycles, remembered chains, lifecycle, direct-old zeroing"],
    }


def execute(output: Path, source_root: Path, packet: Path) -> dict:
    if output.exists() and any(output.iterdir()):
        raise RuntimeError(f"refusing nonempty output directory: {output}")
    output.mkdir(parents=True, exist_ok=True)
    journal = output / "attempts.jsonl"
    runner_hash = sha(Path(__file__).read_bytes())
    fixture_hash = sha(FIXTURE.read_bytes())
    records = {"execution_performed": True, "source_root": str(source_root),
               "runner_sha256": runner_hash, "fixture_sha256": fixture_hash,
               "packet_path": str(packet),
               "builds": {}, "runs": [], "paired_stats": {}, "attempt_journal": str(journal)}
    failure = None
    try:
        frozen = frozen_inputs(source_root, packet)
        closure_before = source_closure(source_root, packet)
        records["frozen_inputs"] = frozen
        records["source_closure_before_sha256"] = closure_before
        cc = shutil.which("clang")
        if not cc:
            raise RuntimeError("clang unavailable")
        records["compiler"] = cc
        gc_texts = {arm: (source_root / arm / "gc.c").read_text()
                    for arm in ("baseline", "candidate")}
        for arm, text in gc_texts.items():
            built = build(cc, source_root, text, arm, output, journal)
            records["builds"][arm] = built
            by_case = {}
            for case in CASES:
                run = run_case(Path(built["binary"]), case, output, journal)
                rows = check_positive(run["stdout"], case)
                by_case[case] = rows
                records["runs"].append({"arm": arm, "case": case, **run})
            records["paired_stats"][arm] = by_case
        for case in CASES:
            base = records["paired_stats"]["baseline"][case]
            candidate = records["paired_stats"]["candidate"][case]
            if base != candidate:
                raise RuntimeError(f"baseline/V deterministic snapshot mismatch for {case}")
        candidate_text = gc_texts["candidate"]
        for name, (text, case, marker) in candidate_mutants(candidate_text).items():
            built = build(cc, source_root, text, f"mutant-{name}", output, journal)
            records["builds"][f"mutant-{name}"] = built
            records["runs"].append({"arm": f"mutant-{name}", "case": case,
                                    **run_case(Path(built["binary"]), case, output, journal, 86, marker)})
        for name, define, case, marker in (
            ("root-slot", "GC_MUTATE_ROOTS", "root-control", "root-slot-not-relocated"),
            ("write-barrier", "GC_MUTATE_BARRIER", "barrier-control", "barrier-edge-not-remembered"),
            ("nursery-zeroing", "GC_MUTATE_ZERO", "nursery-zero-control", "nursery-zero-oracle"),
        ):
            built = build(cc, source_root, candidate_text, f"mutant-{name}", output, journal, define)
            records["builds"][f"mutant-{name}"] = built
            records["runs"].append({"arm": f"mutant-{name}", "case": case,
                                    **run_case(Path(built["binary"]), case, output, journal, 86, marker)})
    except Exception as exc:
        failure = f"{type(exc).__name__}: {exc}"
    finally:
        records["failure"] = failure
        try:
            final_frozen = frozen_inputs(source_root, packet)
            final_closure = source_closure(source_root, packet)
            records["frozen_inputs_after"] = final_frozen
            records["source_closure_after_sha256"] = final_closure
            if "frozen_inputs" in records and final_frozen != records["frozen_inputs"]:
                records["source_check_error"] = "source manifest changed during execution"
            if "source_closure_before_sha256" in records and final_closure != records["source_closure_before_sha256"]:
                records["source_check_error"] = "source closure changed during execution"
        except Exception as exc:
            records["source_check_error"] = f"{type(exc).__name__}: {exc}"
        records["runner_sha256_after"] = sha(Path(__file__).read_bytes())
        records["fixture_sha256_after"] = sha(FIXTURE.read_bytes())
        if records["runner_sha256_after"] != runner_hash:
            records["source_check_error"] = "runner changed during execution"
        if records["fixture_sha256_after"] != fixture_hash:
            records["source_check_error"] = "fixture changed during execution"
        out = output / "verification.json"
        out.write_text(json.dumps(records, sort_keys=True, indent=2) + "\n")
    if failure:
        raise RuntimeError(failure)
    if records.get("source_check_error"):
        raise RuntimeError(records["source_check_error"])
    return records


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--execute", action="store_true", help="compile and run bounded sanitizer checks")
    parser.add_argument("--output", type=Path, default=HERE / "out")
    parser.add_argument("--source-root", type=Path,
                        default=Path("/tmp/medaka-copy-scan-fusion-v-85"),
                        help="frozen directory containing manifest.json and baseline/candidate")
    parser.add_argument("--packet", type=Path, default=DEFAULT_PACKET,
                        help="pinned Variant V packet copy")
    args = parser.parse_args()
    if args.execute:
        result = execute(args.output, args.source_root.resolve(), args.packet.resolve())
        print(args.output / "verification.json")
        print(json.dumps({"runs": len(result["runs"]), "builds": len(result["builds"]),
                          "execution_performed": True}, sort_keys=True))
    else:
        print(json.dumps(run_plan(args.source_root.resolve(), args.packet.resolve()), sort_keys=True, indent=2))
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as exc:
        print(f"verification runner error: {exc}", file=sys.stderr)
        raise SystemExit(1)
