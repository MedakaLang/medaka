#define _POSIX_C_SOURCE 200809L
#include "gc.h"
#include <inttypes.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static uintptr_t nursery_base;
static size_t nursery_capacity;

static _Noreturn void fail(const char *name) {
  fprintf(stderr, "FIXTURE_FAIL %s\n", name);
  fflush(stderr);
  _Exit(86);
}
#define NEED(c, name) do { if (!(c)) fail(name); } while (0)

static int in_full_nursery(Word word) {
  return word && !(word & 1) && word >= nursery_base
      && word - nursery_base < nursery_capacity;
}
static void checked_root(Word word, const char *name) {
  if (in_full_nursery(word)) fail(name);
  if (!word || (word & 1)) fail("expected-relocated-root");
}
static Word checked_edge(Word owner, size_t index, const char *name) {
  Word child = load(owner, index);
  if (in_full_nursery(child)) fail(name);
  if (!child || (child & 1)) fail("expected-relocated-pointer");
  return child;
}
static GcLayout layout(size_t words, uint64_t mask) {
  return prepare_layout(words, mask);
}
static Word fresh(GcLayout l) { return allocate_prepared(l); }
static void start_heap(size_t bytes) {
  heap_init(bytes);
  nursery_base = (uintptr_t)gc_fast.nursery;
  nursery_capacity = gc_fast.capacity;
}
static void finish_heap(const char *name) {
  NEED(stats.root_bytes == 0, "unbalanced-fixture-roots");
  heap_destroy();
  printf("FIXTURE_OK %s\n", name);
}
static void snapshot(const char *name) {
  printf("{\"stage\":\"%s\",", name);
  print_stats();
  printf(",\"old_limit_bytes\":%zu}\n", gc_fast.old_limit);
}

static void case_graphs(void) {
  start_heap(4096);
  GcLayout one = layout(1, UINT64_C(1));
  GcLayout node = layout(3, UINT64_C(6));
  Word self = fresh(one); ((Word *)self)[0] = self;
  Word leaf = fresh(node), left = fresh(node), right = fresh(node), diamond = fresh(node);
  ((Word *)leaf)[0] = integer(104); ((Word *)left)[0] = integer(102);
  ((Word *)right)[0] = integer(103); ((Word *)diamond)[0] = integer(101);
  store_prepared(node, left, 1, leaf); store_prepared(node, right, 1, leaf);
  store_prepared(node, diamond, 1, left); store_prepared(node, diamond, 2, right);
  Word ca = fresh(node), cb = fresh(node);
  ((Word *)ca)[0] = integer(105); ((Word *)cb)[0] = integer(106);
  store_prepared(node, ca, 1, cb); store_prepared(node, cb, 1, ca);
  Word self_a = self, self_b = self;
  Root rs, rs2, rd, rc; root_push(&rs, &self_a); root_push(&rs2, &self_b);
  root_push(&rd, &diamond); root_push(&rc, &ca);
  minor_collect();
  checked_root(self_a, "self-root-not-relocated"); checked_root(self_b, "alias-root-not-relocated");
  checked_root(diamond, "diamond-root-not-relocated"); checked_root(ca, "cycle-root-not-relocated");
  NEED(self_a == self_b, "alias-roots-diverged");
  NEED(checked_edge(self_a, 0, "self-edge-stale") == self_a, "self-cycle-broken");
  Word ml = checked_edge(diamond, 1, "diamond-left-stale");
  Word mr = checked_edge(diamond, 2, "diamond-right-stale");
  NEED(ml != mr && unbox(load(diamond, 0)) == 101, "diamond-root-data");
  NEED(unbox(load(ml, 0)) == 102 && unbox(load(mr, 0)) == 103, "diamond-child-data");
  NEED(checked_edge(ml, 1, "diamond-left-leaf-stale") ==
       checked_edge(mr, 1, "diamond-right-leaf-stale"), "diamond-sharing-lost");
  Word mb = checked_edge(ca, 1, "cycle-forward-stale");
  NEED(unbox(load(mb, 0)) == 106 && checked_edge(mb, 1, "cycle-back-stale") == ca,
       "multiword-cycle-broken");
  NEED(stats.promoted_count == 7, "graph-promotion-count");
  snapshot("graphs-minor");
  root_pop(&rc); root_pop(&rd); root_pop(&rs2); root_pop(&rs);
  finish_heap("graphs");
}

static void case_remembered_chain(void) {
  start_heap(4096); GcLayout n = layout(3, UINT64_C(6));
  Word owner = fresh(n); ((Word *)owner)[0] = integer(201);
  Root ro; root_push(&ro, &owner); minor_collect(); checked_root(owner, "owner-not-old");
  Word a = fresh(n), b = fresh(n), c = fresh(n);
  ((Word *)a)[0] = integer(202); ((Word *)b)[0] = integer(203); ((Word *)c)[0] = integer(204);
  store_prepared(n, a, 1, b); store_prepared(n, b, 1, c); store_prepared(n, owner, 1, a);
  NEED(stats.remembered_queue_bytes, "owner-not-remembered");
  minor_collect(); checked_root(owner, "remembered-owner-root-stale");
  Word ma = checked_edge(owner, 1, "remembered-edge-stale");
  Word mb = checked_edge(ma, 1, "chain-level-two-not-scanned");
  Word mc = checked_edge(mb, 1, "chain-level-three-not-scanned");
  NEED(unbox(load(ma, 0)) == 202 && unbox(load(mb, 0)) == 203 &&
       unbox(load(mc, 0)) == 204, "remembered-chain-data");
  NEED(stats.promoted_count == 4, "remembered-chain-promotion-count");
  snapshot("remembered-minor"); root_pop(&ro); finish_heap("remembered-chain");
}

static void case_payloads(void) {
  start_heap(4096);
  GcLayout atom_l = layout(3, 0), rawchild_l = layout(3, UINT64_C(2));
  GcLayout wide_l = layout(66, UINT64_C(1) << 63);
  Word atom = fresh(atom_l);
  Word atom_expected[3] = {UINT64_C(0x02030405060708a0), UINT64_C(0x00f1e2d3c4b5a697), UINT64_C(0x8877665544332211)};
  memcpy((Word *)atom, atom_expected, sizeof atom_expected);
  Word rawchild = fresh(rawchild_l), child = fresh(atom_l);
  Word child_expected[3] = {UINT64_C(0xfedcba9876543210), 0x123456789abcdef0, 0x0badf00d76543210};
  memcpy((Word *)child, child_expected, sizeof child_expected);
  ((Word *)rawchild)[0] = UINT64_C(0x1020304050607080); /* raw field zero */
  ((Word *)rawchild)[1] = child; ((Word *)rawchild)[2] = UINT64_C(0xe0d0c0b0a0908070);
  Word wide = fresh(wide_l), wide_expected[66];
  for (size_t i = 0; i < 66; ++i) ((Word *)wide)[i] = wide_expected[i] =
      UINT64_C(0xa001000000000000) + (Word)i * UINT64_C(0x101);
  Word bit_child = fresh(atom_l); memcpy((Word *)bit_child, child_expected, sizeof child_expected);
  store_prepared(wide_l, wide, 63, bit_child);
  Word atom_root = atom, raw_root = rawchild, wide_root = wide;
  Root ra, rr, rw; root_push(&ra, &atom_root); root_push(&rr, &raw_root); root_push(&rw, &wide_root);
  minor_collect();
  checked_root(atom_root, "atomic-root-stale"); checked_root(raw_root, "rawchild-root-stale");
  checked_root(wide_root, "wide-root-stale");
  NEED(memcmp((Word *)atom_root, atom_expected, sizeof atom_expected) == 0, "atomic-bytes-corrupt");
  NEED(((Word *)raw_root)[0] == UINT64_C(0x1020304050607080), "raw-field-zero-corrupt");
  Word moved_child = checked_edge(raw_root, 1, "rawfield-one-child-stale");
  NEED(memcmp((Word *)moved_child, child_expected, sizeof child_expected) == 0, "rawfield-one-child-corrupt");
  NEED(((Word *)raw_root)[2] == UINT64_C(0xe0d0c0b0a0908070), "rawchild-tail-corrupt");
  Word moved_bit_child = checked_edge(wide_root, 63, "bit63-child-stale");
  NEED(memcmp((Word *)moved_bit_child, child_expected, sizeof child_expected) == 0, "bit63-child-corrupt");
  for (size_t i = 0; i < 66; ++i) if (i != 63)
    NEED(((Word *)wide_root)[i] == wide_expected[i], i >= 64 ? "raw-tail-64-65-corrupt" : "wide-raw-word-corrupt");
  snapshot("payloads-minor");
  root_pop(&rw); root_pop(&rr); root_pop(&ra); finish_heap("payloads");
}

static void case_completion(void) {
  start_heap(512); GcLayout n = layout(3, UINT64_C(6));
  Word owner = fresh(n), child = fresh(n);
  ((Word *)owner)[0] = integer(301); ((Word *)child)[0] = integer(302);
  store_prepared(n, owner, 1, child);
  Root ro, rc; root_push(&ro, &owner); root_push(&rc, &child);
  minor_collect();
  checked_root(owner, "completion-owner-root-stale");
  checked_root(child, "completion-child-root-stale");
  /* Both destinations are independently known from root slots; never chase a stale edge. */
  NEED(unbox(load(owner, 0)) == 301, "completion-owner-field-zero-corrupt");
  NEED(unbox(load(child, 0)) == 302, "completion-child-field-zero-corrupt");
  NEED(load(owner, 1) == child, "completion-edge-not-written");
  NEED(unbox(load(child, 1)) == 0, "completion-child-rawword-corrupt");
  snapshot("completion-minor"); root_pop(&rc); root_pop(&ro); finish_heap("completion");
}

static void case_forwarded_alias(void) {
  start_heap(256); GcLayout a = layout(1, 0);
  Word object = fresh(a); ((Word *)object)[0] = UINT64_C(0xa1b2c3d4e5f60780);
  Word x = object, y = object; Root rx, ry; root_push(&rx, &x); root_push(&ry, &y);
  minor_collect(); checked_root(x, "forwarded-alias-root-stale"); checked_root(y, "forwarded-alias-root-stale");
  NEED(x == y, "forwarded-alias-diverged"); NEED(((Word *)x)[0] == UINT64_C(0xa1b2c3d4e5f60780), "forwarded-atomic-bytes");
  snapshot("forwarded-alias-minor"); root_pop(&ry); root_pop(&rx); finish_heap("forwarded-alias");
}

static void case_barrier(void) {
  start_heap(512); GcLayout n = layout(3, UINT64_C(6));
  Word owner = fresh(n); ((Word *)owner)[0] = integer(311); Root r; root_push(&r, &owner);
  minor_collect(); checked_root(owner, "barrier-owner-root-stale");
  Word child = fresh(n); ((Word *)child)[0] = integer(312); store_prepared(n, owner, 1, child);
  minor_collect(); checked_root(owner, "barrier-owner-root-stale");
  Word moved = checked_edge(owner, 1, "barrier-edge-not-remembered");
  NEED(unbox(load(moved, 0)) == 312, "barrier-child-data-corrupt");
  snapshot("barrier-minor"); root_pop(&r); finish_heap("barrier-control");
}

static void case_lifecycle(void) {
  start_heap(32); uintptr_t epoch = gc_heap_epoch; GcLayout n = layout(3, UINT64_C(6));
  Word a = fresh(n); ((Word *)a)[0] = integer(401); Root ra; root_push(&ra, &a);
  Word b = fresh(n); ((Word *)b)[0] = integer(402); Root rb; root_push(&rb, &b);
  NEED(in_full_nursery(b), "tiny-second-root-not-young");
  store_prepared(n, a, 1, b); minor_collect(); checked_root(a, "tiny-first-root-stale");
  Word mb = checked_edge(a, 1, "tiny-child-not-relocated");
  NEED(unbox(load(a, 0)) == 401 && unbox(load(mb, 0)) == 402, "tiny-content-corrupt");
  major_collect(); checked_root(a, "major-after-minor-root-stale");
  mb = checked_edge(a, 1, "major-after-minor-edge-stale");
  NEED(unbox(load(mb, 0)) == 402, "major-after-minor-content-corrupt");
  snapshot("lifecycle-major"); root_pop(&rb); root_pop(&ra); heap_destroy();
  NEED(gc_fast.nursery == NULL, "destroy-left-nursery"); start_heap(64);
  NEED(gc_heap_epoch == epoch + 1, "heap-epoch-not-advanced");
  GcLayout atom = layout(1, 0); Word x = fresh(atom); ((Word *)x)[0] = UINT64_C(0xfaceb00c);
  Root rx; root_push(&rx, &x); minor_collect(); checked_root(x, "reinitialized-root-stale");
  NEED(((Word *)x)[0] == UINT64_C(0xfaceb00c), "reinitialized-payload-corrupt");
  root_pop(&rx); finish_heap("lifecycle");
}

static void case_direct_old(void) {
  start_heap(32); GcLayout l = layout(4, 0); Word p = fresh(l);
  NEED(!in_full_nursery(p), "direct-old-allocated-young");
  NEED(stats.direct_old_allocations == 1 && stats.nursery_allocations == 0, "direct-old-accounting");
  for (size_t i = 0; i < 4; ++i) NEED(((Word *)p)[i] == 0, "direct-old-not-zeroed");
  size_t payload_bytes = l.words * sizeof(Word);
  size_t logical_object_bytes = old_header_size() + payload_bytes;
  NEED(stats.old_slot_bytes >= logical_object_bytes, "direct-old-slot-accounting");
  for (size_t i = payload_bytes; i < stats.old_slot_bytes - old_header_size(); ++i)
    NEED(((unsigned char *)p)[i] == 0, "direct-old-padding-not-zeroed");
  Root r; root_push(&r, &p); major_collect(); checked_root(p, "direct-old-root-invalid");
  snapshot("direct-old-major"); root_pop(&r); finish_heap("direct-old");
}

static void case_ledger(void) {
  start_heap(512); GcLayout a = layout(1, 0); Word cells[17] = {0}; Root roots[17];
  for (size_t i = 0; i < 17; ++i) root_push(&roots[i], &cells[i]);
  for (size_t i = 0; i < 17; ++i) { cells[i] = fresh(a); ((Word *)cells[i])[0] = integer(500 + i); }
  minor_collect();
  for (size_t i = 0; i < 17; ++i) { checked_root(cells[i], "ledger-root-stale"); NEED(unbox(load(cells[i], 0)) == 500 + i, "ledger-content-corrupt"); }
  snapshot("ledger-minor"); major_collect(); NEED(stats.old_object_count == 17, "ledger-major-dropped-roots");
  snapshot("ledger-major"); for (size_t i = 17; i-- > 0;) root_pop(&roots[i]); finish_heap("ledger");
}

static void case_root_mutation(void) {
  start_heap(256); GcLayout n = layout(3, UINT64_C(6)); Word x = fresh(n); ((Word *)x)[0] = integer(601);
  Root r; root_push(&r, &x); minor_collect(); checked_root(x, "root-slot-not-relocated");
  snapshot("root-control-minor"); root_pop(&r); finish_heap("root-control");
}

static void case_zero_mutation(void) {
  start_heap(64); memset(gc_fast.nursery, 0xa5, gc_fast.capacity);
  GcLayout a = layout(2, 0); Word x = fresh(a);
  NEED(((Word *)x)[0] == 0 && ((Word *)x)[1] == 0, "nursery-zero-oracle");
  snapshot("nursery-zero-control"); finish_heap("nursery-zero-control");
}

static void case_all(void) {
  case_graphs(); case_remembered_chain(); case_payloads(); case_completion();
  case_forwarded_alias(); case_barrier(); case_lifecycle(); case_direct_old(); case_ledger();
}
int main(int argc, char **argv) {
  if (argc != 2) fail("usage-case-required");
  if (!strcmp(argv[1], "all")) case_all();
  else if (!strcmp(argv[1], "graphs")) case_graphs();
  else if (!strcmp(argv[1], "remembered-chain")) case_remembered_chain();
  else if (!strcmp(argv[1], "payloads")) case_payloads();
  else if (!strcmp(argv[1], "completion")) case_completion();
  else if (!strcmp(argv[1], "forwarded-alias")) case_forwarded_alias();
  else if (!strcmp(argv[1], "barrier-control")) case_barrier();
  else if (!strcmp(argv[1], "lifecycle")) case_lifecycle();
  else if (!strcmp(argv[1], "direct-old")) case_direct_old();
  else if (!strcmp(argv[1], "ledger")) case_ledger();
  else if (!strcmp(argv[1], "root-control")) case_root_mutation();
  else if (!strcmp(argv[1], "nursery-zero-control")) case_zero_mutation();
  else fail("unknown-case");
  return 0;
}
