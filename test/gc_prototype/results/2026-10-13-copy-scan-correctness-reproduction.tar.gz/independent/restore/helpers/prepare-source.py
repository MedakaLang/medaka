import difflib
import hashlib
import json
from pathlib import Path
import subprocess

root = Path('/root/.codex/worktrees/f396/medaka')
work = Path('/tmp/medaka-copy-scan-fusion-v-85')
base = '85c364304684c44c544957c8ba2b180d15d736c5'
names = ['gc.c', 'gc.h', 'workload.c']
original = {}
for name in names:
    data = subprocess.check_output(['git','show',base+':test/gc_prototype/'+name],cwd=root)
    original[name] = data
    for arm in ['baseline','candidate']:
        path = work / arm / name
        path.parent.mkdir(parents=True,exist_ok=True)
        path.write_bytes(data)
assert hashlib.sha256(original['gc.c']).hexdigest() == '8b3d4bf65beccb9a019d2330f8266fc5261120140d94b611981add3b720876b4'
text = original['gc.c'].decode()
replacements = [
    ('  if (source) memcpy(h + 1, source + 1, bytes - sizeof(Header));\n',
     '  /* Traced promotion completes its payload while scanning the nursery source. */\n'
     '  if (source && !d->mask) memcpy(h + 1, source + 1, bytes - sizeof(Header));\n'),
    ('  size_t words = descriptor(from)->words;\n'
     '  Header *to = new_old(from->info, from);\n'
     '  from->info = payload(to) | FORWARDED;\n'
     '  queue_push(&work, to, &stats.work_queue_bytes);\n'
     '  stats.promoted_count++; stats.copied_bytes += object_bytes(words);\n'
     '  stats.copied_payload_bytes += words * sizeof(Word);\n',
     '  Descriptor d = *descriptor(from);\n'
     '  Header *to = new_old(from->info, from);\n'
     '  /* Preserve field zero before forwarding; other traced payload words remain private. */\n'
     '  if (d.mask) ((Word *)(to + 1))[0] = ((Word *)(from + 1))[0];\n'
     '  from->info = payload(to) | FORWARDED;\n'
     '  queue_push(&work, from, &stats.work_queue_bytes);\n'
     '  stats.promoted_count++; stats.copied_bytes += object_bytes(d.words);\n'
     '  stats.copied_payload_bytes += d.words * sizeof(Word);\n'),
    ('void minor_collect(void) {\n',
     '/* Minor work entries locate nursery sources; major work entries remain old headers.\n'
     '   Forwarded destinations are complete before poisoning or mutator resumption. */\n'
     'static void scan_fused(Header *from) {\n'
     '  assert(from->info & FORWARDED);\n'
     '  Header *to = header(from->info & ~(uintptr_t)7);\n'
     '  Descriptor d = *descriptor(to);\n'
     '  Word *fields = (Word *)(to + 1), *source = (Word *)(from + 1);\n'
     '  if (d.mask) {\n'
     '    if (d.mask & 1) fields[0] = promote(fields[0]);\n'
     '    for (size_t i = 1; i < d.words; ++i)\n'
     '      fields[i] = i < 64 && ((d.mask >> i) & 1) ? promote(source[i]) : source[i];\n'
     '  } else {\n'
     '    /* Atomic objects retain their full copy and original destination scan. */\n'
     '    for (size_t i = 0; i < d.words && i < 64; ++i)\n'
     '      if ((d.mask >> i) & 1) fields[i] = promote(fields[i]);\n'
     '  }\n'
     '}\n'
     'void minor_collect(void) {\n'),
    ('  while (work.count) scan_promote(work.items[--work.count]);\n',
     '  while (work.count) {\n'
     '    Header *from = work.items[--work.count];\n'
     '    scan_fused(from);\n'
     '  }\n'),
]
for old,new in replacements:
    assert text.count(old) == 1, old
    text = text.replace(old,new)
(work/'candidate/gc.c').write_text(text)
patch = ''.join(difflib.unified_diff(original['gc.c'].decode().splitlines(keepends=True),
                                   text.splitlines(keepends=True),
                                   fromfile='baseline/gc.c',tofile='candidate/gc.c'))
(work/'copy-scan-fusion-v.patch').write_text(patch)
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
manifest = dict(
    status='source-only; no builds, tests or timing authorized yet',
    variant='V: vector source-header locator plus deferred traced-payload completion',
    baseline_commit=base,
    packet='/tmp/medaka-copy-scan-fusion-plan.md',
    packet_sha256=sha(Path('/tmp/medaka-copy-scan-fusion-plan.md')),
    source_sha256={arm:{name:sha(work/arm/name) for name in names} for arm in ['baseline','candidate']},
    patch_sha256=sha(work/'copy-scan-fusion-v.patch'),
    mechanism=[
        'new_old retains full direct-old clearing and promotion padding clearing; mask0 sources copy completely as before',
        'traced sources defer full memcpy, preserving field0 before forwarding; no uninitialized allocation API is exposed',
        'minor vector holds nursery Header pointers, popped before scans; destination descriptor is read after following forwarding header',
        'traced field0 resolves from saved destination word; later logical fields copy raw or resolve traced source words with guarded index<64',
        'atomic sources are still enqueued and popped, with original zero-mask destination scan semantics',
        'remembered scan_promote and major mark/sweep vector are unchanged',
    ],
    temporary_invariant='forwarded old destinations may have private incomplete later payload words; no reentry/major/mutator/observer until all minor work drains before nursery poison/reset',
    source_preservation='nursery payload remains intact in V throughout collection; source descriptor is never decoded after forwarding',
    expected_counter_identity='every deterministic Stats and printed storage field exact, including logical copied bytes and queue capacities/peaks; no new static or reserved storage',
    unchanged_contracts='gc.h/workload byte-identical; allocation schedule/public zeroing/direct-old padding/barriers/root records/descriptor identity/order untouched',
    safe_mutations='accepted packet pre-dereference alias/range/raw-byte oracles; do not omit forwarding publication',
    direct_old_evidence_limit='birth-route timing changes major pacing and placement, so it provides no isolated physical-copy budget',
)
(work/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps(manifest,indent=2))
