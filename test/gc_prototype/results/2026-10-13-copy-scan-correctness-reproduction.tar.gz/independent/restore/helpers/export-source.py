"""Archive only the frozen, reviewed source-only handoff; never execute GC code."""
import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile

repo = Path('/root/.codex/worktrees/f396/medaka')
source = Path('/tmp/medaka-copy-scan-fusion-v-85')
verification = Path('/tmp/medaka-copy-scan-fusion-85/verification')
out = repo / 'test/gc_prototype/results'
prefix = '2026-10-13-copy-scan-source-'
def digest(data):
    return hashlib.sha256(data).hexdigest()

manifest = json.loads((source/'manifest.json').read_text())
assert digest((source/'manifest.json').read_bytes()) == '026be9dfb958a619b1919bbd2ed67860d0054e575c269e1a250596f27f42b1d7'
members = {}
def add(name, path, expected=None):
    data = path.read_bytes()
    assert name not in members and not name.startswith('/') and '..' not in Path(name).parts
    if expected:
        assert digest(data) == expected, str(path)
    members[name] = (path, data)

for arm in ['baseline','candidate']:
    for name, expected in manifest['source_sha256'][arm].items():
        add('sources/'+arm+'/'+name, source/arm/name, expected)
add('sources/manifest.json', source/'manifest.json')
add('sources/copy-scan-fusion-v.patch', source/'copy-scan-fusion-v.patch', manifest['patch_sha256'])
add('plan/accepted-plan.md', Path('/tmp/medaka-copy-scan-fusion-plan.md'), manifest['packet_sha256'])
add('helpers/prepare-source.py', Path('/tmp/medaka-copy-scan-fusion-v-85-prepare.py'))
for name, expected in [
    ('fixture.c','509c3a253b2d75dde0789f87b4ba2e107d983b5b3d843e143093f1f62f33293a'),
    ('run.py','3c345ad5290bd7773a5adc4409e690a66d78da59c53b5535d98ce24448ffd4c8'),
    ('plan.json','dbffb5d69954165f4a11d66c03ca38fc952aaef97c06c31fcececabaa2dc5867'),
]:
    add('verification/'+name, verification/name, expected)
prepared = json.loads(members['verification/plan.json'][1])
assert prepared['execution_performed'] is False
assert prepared['fixture_sha256'] == digest(members['verification/fixture.c'][1])
assert prepared['runner_sha256'] == digest(members['verification/run.py'][1])
assert prepared['frozen_inputs']['source_sha256'] == manifest['source_sha256']
add('review/source-review-receipt.md', Path('/tmp/medaka-copy-scan-source-review-receipt.md'))
if (repo/'LICENSE').is_file():
    add('LICENSE', repo/'LICENSE')

readme = '''# Copy/scan-fusion Variant V: source-only handoff

Status: UNBUILT / UNEXECUTED. The collector candidate, C fixture and seven
mutation controls have not been compiled or run. Verification --execute has
never run. Source review passed; no correctness execution PASS, performance
claim, policy selection or production integration follows. Preparation metadata
and Python syntax checks were performed; plan.json says execution_performed=false.

The main collector remains 85c364304684c44c544957c8ba2b180d15d736c5. Variant V
retains its minor vector capacity/growth but queues nursery source Header pointers.
Traced promotions save field0 and complete later words directly from the nursery;
destination descriptors govern scanning. Atomic objects keep full copying and
queueing; remembered scanning, direct-old zeroing/padding and major marking stay
unchanged. All deterministic counters/storage and old-limit schedules are expected
to match 85 exactly. This expectation has not been tested. Intrusive queue work
was not advanced; fusion is compared against the original vector queue only.

The new temporary invariant keeps incomplete forwarded old destinations private
until all minor work completes before nursery poison, major collection or mutator
resumption. It assumes the existing single-mutator/no-reentry collector. It does
not authorize uninitialized public allocation, callbacks or concurrent marking.

The reproduction archive contains exact baseline/candidate gc.c, identical gc.h
and workload.c, the source patch/manifest, accepted diagnostic plan, prepared
independent fixture/runner/control metadata and independent source-review receipt.
The external manifest binds every member's SHA256/size and original path.
No host executable, library archive, object file or measurement artifact is needed.
Source-review PASS is separate from execution, and nursery-range checks are not
general authentication of arbitrary pointers.

## Restore without old /tmp files

Choose a fresh empty extraction directory; these commands are for the next session,
not commands already run. Replace the extraction path if it already exists.

```sh
mkdir /tmp/medaka-copy-scan-handoff-next
tar -xzf test/gc_prototype/results/2026-10-13-copy-scan-source-reproduction.tar.gz -C /tmp/medaka-copy-scan-handoff-next
```

The runner supports relocation via explicit --source-root and --packet; restoring
the recorded original absolute paths is unnecessary. Verify archive/member hashes
against 2026-10-13-copy-scan-source-manifest.json before using the sources.
The preparation helper is provenance, not a required restore step: it uses the
original repository path and pinned git commit. The archived C sources are complete.

After explicit resume and CPU scheduling, the first command prints a source-only
plan without compiling or invoking the C fixture:

```sh
python3 /tmp/medaka-copy-scan-handoff-next/verification/run.py --source-root /tmp/medaka-copy-scan-handoff-next/sources --packet /tmp/medaka-copy-scan-handoff-next/plan/accepted-plan.md
```

Only after the next session authorizes and reserves the CPU slot:

```sh
python3 /tmp/medaka-copy-scan-handoff-next/verification/run.py --source-root /tmp/medaka-copy-scan-handoff-next/sources --packet /tmp/medaka-copy-scan-handoff-next/plan/accepted-plan.md --execute --output /tmp/medaka-copy-scan-verification-next
```

The output directory must be empty/nonexistent. Requirements are Python 3.10+,
a 64-bit C11 Clang toolchain and ASan/UBSan runtimes (no Boehm dependency for
this prepared verifier). Capture compiler version/hash and execution provenance
then; this source-only handoff contains no measured toolchain or binary claim.

Prepared scope: nine builds; 22 positive runs (11 cases × 2 arms); seven named
negative controls. It compares every deterministic printed snapshot plus old_limit,
checks raw field0/bit63/tails/atomic data/cycles/aliases/remembered chains/direct-old
zeroing/lifecycle, and journals commands/results including failures. A valid mutant
grade requires status86 and its exact FIXTURE_FAIL marker; crashes, sanitizer
reports and timeouts do not count. See verification/plan.json for markers/flags.

If those checks pass, the accepted plan still requires the existing full collector
correctness matrix, independent review and a separate timing handoff. Neither a
performance runner nor performance results are supplied here. Do not replace main
gc.c, edit compiler/ByteBlock sources or choose a policy merely to resume validation.
'''
readme_path = out/(prefix+'README.md')
readme_path.write_text(readme)
add('README.md', readme_path)
add('helpers/export-source.py', Path(__file__))

archive_path = out/(prefix+'reproduction.tar.gz')
def archive_bytes():
    target = io.BytesIO()
    with gzip.GzipFile(filename='',mode='wb',fileobj=target,mtime=0) as gz:
        with tarfile.open(fileobj=gz,mode='w',format=tarfile.PAX_FORMAT) as tar:
            for name, (path,data) in sorted(members.items()):
                info = tarfile.TarInfo(name)
                info.size = len(data); info.mtime = info.uid = info.gid = 0
                info.uname = info.gname = ''; info.mode = 0o644
                tar.addfile(info,io.BytesIO(data))
    return target.getvalue()
first = archive_bytes()
assert first == archive_bytes(), 'archive is not deterministic'
archive_path.write_bytes(first)
with tarfile.open(fileobj=io.BytesIO(first),mode='r:gz') as tar:
    assert {m.name for m in tar.getmembers()} == set(members)
    for member in tar.getmembers():
        assert member.isfile() and tar.extractfile(member).read() == members[member.name][1]
result = dict(
    status='UNBUILT / UNEXECUTED source-only handoff; independent source review PASS only',
    collector_execution_performed=False, verification_execute_performed=False,
    source_plan_generation_performed=True, baseline_commit=manifest['baseline_commit'],
    variant='V: original vector queue plus traced copy/scan fusion',
    candidate_gc_sha256=manifest['source_sha256']['candidate']['gc.c'],
    planned_builds=9, planned_positive_runs=22, planned_negative_controls=7,
    no_performance_claim=True, no_host_binaries=True,
    review_receipt='review/source-review-receipt.md',
    external_requirements=['Python 3.10+','64-bit C11 Clang with ASan/UBSan runtime; no Boehm needed'],
    durable_files={
        readme_path.name:dict(sha256=digest(readme_path.read_bytes()),bytes=readme_path.stat().st_size),
        archive_path.name:dict(sha256=digest(first),bytes=len(first),format='deterministic gzip/tar, exact source bytes'),
    },
    members={name:dict(sha256=digest(data),bytes=len(data),original_path=str(path),archive_mode='0o644')
             for name,(path,data) in sorted(members.items())},
    packaging_validation='two independently produced archive byte strings equal; every archived member verified against frozen input bytes; no collector/verifier execution',
)
manifest_path = out/(prefix+'manifest.json')
manifest_path.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(dict(files=[str(readme_path),str(archive_path),str(manifest_path)],
                     members=len(members),archive_bytes=len(first),archive_sha256=digest(first)),indent=2))
