# Copy/scan fusion: bounded diagnostic packet

Status: preparation only. No implementation, builds, correctness execution or
timing is authorized by this packet. Select its base only after the pending
intrusive-queue correctness and timing review. This is neither a pretenuring
policy nor a production compiler/ByteBlock change.

## Pinned comparison and question

Medaka collector base:85c364304684c44c544957c8ba2b180d15d736c5,
gc.c SHA2568b3d4bf65beccb9a019d2330f8266fc5261120140d94b611981add3b720876b4.
Exact snapshots: /tmp/medaka-intrusive-promotion-85/baseline/{gc.c,gc.h,workload.c}.
The queued intrusive candidate gc.c SHA256 is
ffdc7cec188abec33fc9b9b147c4477b93097242f1555f980aee09724b7cfa0e.
That candidate replaces only minor work storage and retains complete copying.

Existing new_old copies all payload words (gc.c240); scan_promote then reads
the destination and rewrites every bitmap-selected field (gc.c299–302). The
question is whether copying raw fields and resolving traced fields directly
from the nursery reduces this duplicate destination traffic. Logical copy
counters alone cannot answer this: they count promoted volume, not physical
loads/stores. Descriptor caching, promotion inlining and whole-init-on-zeroed-
allocation have already been measured; they are not part of this experiment.

OCaml5.4 pinned commit907eec0b75c5bcf0fe6da5f4b9f11c5c22995a16 preserves
field0 in the destination, then finishes later fields directly from the source:

- https://github.com/ocaml/ocaml/blob/907eec0b75c5bcf0fe6da5f4b9f11c5c22995a16/runtime/minor_gc.c#L298-L314
- https://github.com/ocaml/ocaml/blob/907eec0b75c5bcf0fe6da5f4b9f11c5c22995a16/runtime/minor_gc.c#L405-L425

Local pinned source: /tmp/ocaml-907eec-minor_gc.c. Borrow only deferred completion;
do not import parallel header arbitration, infix/continuation handling, atomic
queue skipping, tail shortcuts or a new major collector.

## Two mutually exclusive base choices

V: if vector work survives, compare unchanged85 vector-copy/scan against vector-
fusion. Minor queue entries become source Header pointers, keeping Header**
capacity/growth/order unchanged; the forwarded source header identifies the old
destination at pop. Major queue entries remain old headers. Their phases never
overlap. Source-pointer queueing is the minimal locator change required to fuse;
record it as part of V, not an independent queue optimization.

I: if intrusive work survives, compare its frozen full-copy candidate against
intrusive-fusion. Keep exactly the existing source-payload head/link and pop-
before-scan discipline. The borrowed nursery field0 already requires saving the
original first word in the old destination before publishing the link.

Do not call I-fusion versus85 a fusion-only comparison. If both choices merit
measurement, use the explicit2×2 vector/intrusive × full-copy/fusion matrix, with
every source/build hash retained and each conditional fusion delta reported
against its own queue base. Prefer one selected queue base for the first bounded
run. Header and workload sources remain byte-identical to that base.

## Proposed mechanism and exact temporary invariant

1. Reserve the same old slot/header using existing class selection, pool/large
   paths and accounting. Direct-old mutator birth retains complete zeroing.
   For traced promotion only, use an internal deferred-payload mode: preserve
   existing padding zeroing but omit the initial complete payload memcpy.
   This mode is never exposed through allocate/allocate_prepared.
2. Save source field0 verbatim into destination field0 before forwarding and
   before any intrusive link overwrites source field0. Only words>=1 are valid.
   Atomic mask0 promotions retain their complete copy before enqueue, and are
   still queued/popped/scanned; this experiment does not optimize atomics.
3. Publish the same forwarding header, enqueue once, and increment the same
   unique-promotion/logical-copy counters. Forwarded repetitions return the old
   payload without inspecting its unfinished fields or recopying borrowed data.
4. At pop, remove the entry before any child can enqueue. Decode the destination
   via the forwarding header and validate its descriptor through the same
   collector authority. For a traced object, resolve saved destination field0
   iff bit0 is selected; otherwise leave its saved raw word intact. For every
   later logical word, read the original source word and write either promote
   of that word (selected bitmap index<64) or the raw word unchanged. All words
   beyond index63 are raw under this prototype's existing descriptor contract.
   Atomic pending entries retain the original scan behavior on their already
   completely copied destination.
5. Leave remembered-owner scan_promote unchanged: its mature payload is already
   initialized and must not be treated as a deferred nursery source. Completely
   drain promotion work before poison/reset, major marking or mutator resumption.

This deliberately permits a private forwarded destination whose later payload
words are incomplete. Root slots may already point to it, but the mutator,
callbacks, major marker and generic payload readers cannot run until drain ends.
Promotion allocation/system malloc and accounting introduce no Medaka safepoint
or collector reentry. Forwarded aliases/cycles may point to pending destinations
without reading them. Header layout, descriptor IDs, slot reuse/padding and raw
source words1..N-1 remain unchanged until their entry completes. This is a new
collector-internal completion invariant, not permission to expose uninitialized
mutator allocation. A concurrent/incremental collector would require another
protocol and is outside scope.

## Required behavior and accounting

Preserve root/remembered processing order, child index order and LIFO completion,
young/direct-old allocation triggers, zeroed public allocations, store barriers,
final drain, nursery poison, all assertions and ordinary mutations. Preserve
one-word self-cycles, shared children/diamonds, multiword cycles, traced/raw
field0, bit63, raw word64+ tails, atomic arbitrary bytes, remembered old→young
edges and direct-old large/reused-slot behavior. No inferred pointer role from
an i64 carrier or raw bit pattern replaces the registered bitmap.

For each queue base, every deterministic Stats field and printed storage field
must match its full-copy control exactly: allocation/promotion/copy/reclaim,
collection counts and old_limit schedule, pool allocation/release/reuse, logical
old/root/descriptor bytes, queue capacities and accounted peaks. Fusing writes
does not change logical copied_bytes or copied_payload_bytes. No new global,
heap storage or Stats field is needed; locals do not add collector reservation.
I's existing static+8 is already included in both I arms; V adds no static word.
The major and remembered queues retain their exact capacities/growth accounting.
Any separately instrumented physical-write/completion counters require their own
charged diagnostic source, never an unreported change in the timed candidate.

## Independent correctness and safe fail-capability controls

Positive fixtures must cover: one-word traced self-cycle; acyclic aliases and
diamond; multiword cycles; traced bit0; raw field0 with traced child1; bit63 and
raw tails at64/65; atomic bytes including even patterns; remembered owner with
unrooted descendants at explicit minor; repeated minor then major; ordinary
direct-old zeroing/padding/barrier; tiny/exact-capacity boundaries and heap reuse.
Compare exact expected relocated aliases/counts before traversing their edges.
After minor, reject traced values in the entire nursery capacity range before
dereference; is_young alone cannot detect stale words after used resets.

Mutants are isolated source copies, graded by the intended nonzero status AND
exact named fixture diagnostic. Crashes, sanitizer errors/timeouts and arbitrary
nonzero exits do not count. Suggested controls:

- Lost saved field0: omit or corrupt the first-word save. A raw-field0/traced-
  child1 object fails exact integer-byte comparison; a self-cycle fails exact
  relocated self-edge equality before following the edge. Never dereference an
  unexpected field0. Applies to both V and I.
- Stale fused edge: evaluate promote normally but write the original nursery
  child word instead of the returned destination. The explicit-minor acyclic
  fixture fails its nursery-range/alias diagnostic before major or graph reads.
- Missing raw tail: omit copying a raw word64+; compare bytes, not pointer
  interpretations. Dirty/reused slots prevent zero fill from hiding omission.
- Incomplete drain/source clobber: use a graph whose expected cells are each
  separately rooted. All destinations are known from relocated root slots;
  compare every expected raw word and edge against those destinations before
  traversal. Suppress later completion or clobber a source field1 before pop;
  require the exact completion/source-preservation diagnostic. This avoids
  interpreting arbitrary unfinished destination contents as pointers.
- Atomic copy-after-borrow (I only): move atomic full copy past the field0 link
  write; the atomic byte-pattern oracle fails without scanning its bytes.
- Retain existing safe forwarding-return, delayed-pop, roots and barrier controls
  from the queue fixture. Inspect immediately after explicit minor, before any
  major/automatic threshold can visit a stale edge. Do not omit forwarding-header
  publication: drain uses it as the destination locator.

After parent CPU authorization: independent positive ASan+UBSan fixtures and
named mutations, existing full correctness matrix, exact all-counter paired
smokes, then independent source/assembly review. Only afterward schedule matched
phase timings with strongest historical and caller-inline Boehm arms, all seven
profiles, small/large nursery controls and final collection included. Existing
retain/drop/ephemeral controls remain important even though this change leaves
policy untouched. A useful result must improve construction for its own queue
base without hiding atomic/mixed regressions or changing any logical work.

Direct-old results remain diagnostic: avoiding evacuation also changes major
pacing, so their improvement is motivation rather than a measured fusion budget.
Negative fusion results reject this implementation, not the correctness of the
completion contract or every future specialization. No default policy follows.
