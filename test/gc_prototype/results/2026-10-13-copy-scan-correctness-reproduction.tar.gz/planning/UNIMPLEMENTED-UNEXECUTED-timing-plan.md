# Copy/scan Variant V: proposed timing screen

Source preparation only. No harness implementation, builds or timings performed.
Execute only after full/independent correctness, source review of the common
phase workload, and explicit serialized CPU handoff. Main remains 85; this plan
authorizes neither collector installation nor a default policy.

## Reuse and source pins

Adapt the existing intrusive 576 screen, not a new framework:
test/gc_prototype/results/2026-10-13-intrusive-screen-reproduction.tar.gz,
members screen/run.py (SHA b44cdedb94e8f1f775a41b266bdd15d74ef16a97fb922e564cce4bc38cd6f6bc)
and screen/PROTOCOL.md (SHA 67317a985fd26ea1035a7fe0fbdfecdac1e8dc26b880f133064c6a98f7c0386a).
That historical screen has no phase clocks; its timing numbers are not controls
for this newly phase-instrumented experiment.

Use the committed c3f19e532 source-handoff archive as fusion input. Collector pins:
baseline 85c364304684c44c544957c8ba2b180d15d736c5,
gc.c 8b3d4bf65beccb9a019d2330f8266fc5261120140d94b611981add3b720876b4;
candidate gc.c 02246c8148d2086ae70aef645305298605b3249c40f2ee666a4b9fb1a217de11.
Original gc.h/workload.c are identical between these arms. The common phase-only
workload will be a separately recorded patch of original workload SHA
b2c38813145487d506191d7c172048f11c367a2af8968026b603bceb4774c112.
Freeze its exact bytes/hash and independent review before compiling any arm.

Replace intrusive qualification paths with actual completed fusion independent
and full correctness artifacts. Require their successful status, unchanged inputs,
expected named controls, and exact candidate/header/source hashes; preserve those
receipts. No prior intrusive/direct-old qualification substitutes for fusion.

## Fixed 576-process screen

N=5,000,000. Six fresh-process rounds per cell, six cohorts per round:
custom baseline, custom fusion V, historical Boehm default/128 MiB initial heap,
caller-inline Boehm default/128 MiB initial heap. Four binaries serve six cohorts.

Sixteen cells: all seven profiles (ephemeral, list, tree, mutation, atomic, mixed,
sizes) at 262144 and 262136 bytes, plus tree at 16777216 and 16777208 bytes.
Keep the original cell order and cyclic cohort rotation: round r uses
ARMS[(r+position)%6]. Every cohort visits every ordinal position once per cell.
Keep every sample; no adaptive repeats, discarded outliers, result-dependent
cells or replacement runs. A failure/drift preserves partial evidence and stops.

Reuse O2/g/C11/Wall/Wextra/Werror, separate translation units/no LTO, prepared
layouts, caller-inline allocation/stores, all diagnostics/statistics/nursery poison.
No NDEBUG, mutation defines, policy change or cheaper custom/Boehm comparator.
Retain the existing historical and caller adapters, version/size guards, traced
uncollectable freelist heads, GC_THREADS/pthread, static libgc 8.2.8, divisor 1.
Clear inherited GC_*; only fixed 128 cohorts set GC_INITIAL_HEAP_SIZE=134217728.
Boehm ignores nursery capacity, and 128 MiB is an initial request, not a cap.
Reacquire/hash actual compiler, archive and transitive headers; do not treat old
binary/toolchain hashes as a substitute for the newly built binaries.

## Common phase accounting, same logical workload

Use one byte-identical phase workload in all four binaries, with a bounded number
of clock reads per process, never per node/loop iteration. Keep original allocation,
root/reload/store/checksum/assertion/drop/collection order. No extra cleanup GC.
Use existing clock_gettime outside asserts; keep current measured elapsed interval:
workload root setup through return/root cleanup, excluding heap/layout preparation,
printing, startup and heap destruction.

Report total elapsed, build_seconds, checksum_seconds (nullable when absent),
final_gc_seconds and residual_seconds=total-minus-reported-nonoverlapping-phases.
Build starts after initial root registration; final GC brackets only the existing
terminal major_collect. Residual retains root setup/cleanup, post-GC validation,
dispatch/clock overhead and all code outside the named intervals. Never suppress
residual or claim the phases cover all elapsed time. Validate each interval is
inside total; allow only 1e-8 seconds for rounded subtotal overshoot, preserving
the raw residual rather than clamping it. Each individual phase is nonnegative.

| Profile | Build label | Separate checksum interval |
|---|---|---|
| tree | construction (includes recursive roots and threshold collections) | existing sum_tree after tree |
| list | construction | existing final sum_list |
| ephemeral/mutation | construction+inline checksum/validation | existing final tail sum_list; interval sums inside loop remain in build |
| atomic | construction+inline checksum/validation | absent/null; every checksum contribution is in loop |
| mixed | construction+inline checksum/validation | existing retained-anchor assertion after loop |
| sizes | construction+inline checksum/validation | existing retained graph and atomic-root checks before its existing terminal major |

Record deterministic phase_semantics/has_separate_checksum fields, and retain
their exact equality across cohorts. Put phase bookkeeping in a local caller
record, not new collector globals or root records. Record its size as caller
instrumentation metadata; gc.c static metadata remains unchanged (fusion adds 0).
Freeze/source-review the timer placement, both normal/sizes return branches,
reloaded roots and post-GC checks; timing instrumentation must preserve every
original logical/counter outcome. Both custom arms must freshly pass paired smokes
with this workload. Inspect caller allocation/store code after build as before.

## Exact counters and minimal harness edits

Rename only custom-intrusive to custom-fusion; replace frozen source/qualification
paths, patch pins and proposal metadata. In pair(), remove all four intrusive
memory exceptions and the +8/work-capacity formulas. Compare the entire custom
row exactly after excluding ONLY these enumerated measured fields:

elapsed_seconds, preparation_seconds, process_peak_rss_bytes, build_seconds,
checksum_seconds, final_gc_seconds, residual_seconds.

No prefix-based exclusion. All other fields/keys must match, including identity,
logical copy/promotion/reclamation, GC counts, root/descriptor bytes, static bytes,
both queue capacities, current/peak accounted bytes, pool storage, layouts and
phase-semantics metadata. Apply existing independent sum/identity checks too.
An unexpected schema key is retained in equality, not silently classified away.
Preserve every paired row and all cohort allocation/payload/checksum identities.

Reuse 42 small cohort/profile smokes and 96 launcher RSS-floor probes (one per
cell/round). Full/independent fusion correctness remains a separate prerequisite.
Remove intrusive-specific peak-ledger generation/32 diagnostic processes: fusion
has no static 8 or capacity delta to explain. A storage mismatch fails; do not
expand allowances or start new diagnostic jobs within a timed matrix.

## Proposed frozen decision rules and reporting

Keep the prior total-time screening rules unchanged. Both small tree cells must
have median paired fusion/baseline total ratio<.95 AND at least 5/6 ratios<.95.
Any of the other 14 cells rejects a repeatable regression when its paired median
is>1.05 AND at least 5/6 ratios>1.05. Large trees are secondary controls, not a
post hoc replacement for failed small-tree primaries. Phases explain results;
they never rescue a failing total-time screen or alter these thresholds.

Retain total high-water RSS, no subtraction. As before, qualify RSS only when
baseline median RSS>=2×its independently observed median launcher floor; reject
qualifying cells with candidate/baseline median RSS ratio>1.10. Floor-limited
cells remain explicitly inconclusive, even though collector storage matches.

Report all six raw times/RSS and every paired ratio, medians/ranges for total,
each applicable phase and residual, plus exact custom counters/storage. Phase
medians need not sum to total median. Keep four Boehm cohorts visible; choose
the strongest observed Boehm by lowest total median per cell, then report fusion
ratios against that fixed cohort (not per-round minimum cherry-picking).

A baseline improvement is not proof of beating strongest Boehm. An advance is
only permission to consider independently held-out confirmation; it installs
nothing and declares no production/application win. Preserve whole raw JSONL,
command/GC environment journal including failures, input/binary before/after
hashes, phase patch/source and qualification receipts. Independent artifact
review must recompute balance, exact equality, decisions and fastest-B selection.

Changes are limited to the existing runner's source/qualification names, exact
pair rules, common phase output/reduction and deletion of obsolete peak diagnostics.
No new collector policy, allocator, statistics toggle or benchmarking framework.
