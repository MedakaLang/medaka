#!/usr/bin/env python3
"""Package exact existing evidence; execute no compiler or workload."""
import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile

HERE = Path(__file__).resolve().parent
FULL = Path('/tmp/medaka-copy-scan-full-correctness-c3f19e532')
INDEPENDENT = Path('/tmp/medaka-copy-scan-resume-c3f19e532')
ROOT = Path('/root/.codex/worktrees/f396/medaka')
BASE = '2026-10-13-copy-scan-correctness'

def sha(data):
    return hashlib.sha256(data).hexdigest()

def main():
    files = {}
    def add(name, path):
        if name in files:
            raise RuntimeError('duplicate member: ' + name)
        files[name] = (path.read_bytes(), str(path))
    for path in sorted((FULL / 'inputs').rglob('*')):
        if path.is_file() and '__pycache__' not in path.parts:
            add('full-suite/inputs/' + path.relative_to(FULL / 'inputs').as_posix(), path)
    for name in ('run_review.py', 'observer/sitecustomize.py', 'execution.json',
                 'preparation.json', 'postrun-audit.json', 'stdout.log', 'stderr.log',
                 'child-commands.jsonl', 'pinned_repo/runtime/medaka_rt.c'):
        add('full-suite/' + name, FULL / name)
    for path in sorted((INDEPENDENT / 'restore').rglob('*')):
        if path.is_file() and '__pycache__' not in path.parts:
            add('independent/restore/' + path.relative_to(INDEPENDENT / 'restore').as_posix(), path)
    for name in ('archive-audit.json', 'relocated-plan.json', 'toolchain.json',
                 'execution-status.json', 'postrun-audit.json', 'execution/attempts.jsonl',
                 'execution/last-stdout.txt', 'execution/verification.json'):
        add('independent/' + name, INDEPENDENT / name)
    for path in sorted((INDEPENDENT / 'execution/builds').glob('*/gc.c')):
        add('independent/' + path.relative_to(INDEPENDENT).as_posix(), path)
    for suffix in ('json', 'py'):
        add('audit/verifier-independent-audit.' + suffix, Path('/tmp/pool-review-copy-scan-verifier-audit.' + suffix))
    # Any separately completed full-suite read-only audit is retained verbatim.
    for suffix in ('json', 'py'):
        path = Path('/tmp/pool-review-copy-scan-full-audit.' + suffix)
        if path.is_file():
            add('audit/full-suite-independent-audit.' + suffix, path)
    add('planning/UNIMPLEMENTED-UNEXECUTED-timing-plan.md', Path('/tmp/medaka-copy-scan-timing-plan-c3f19e532/PLAN.md'))
    add('replay.py', HERE / 'replay.py')
    add('helpers/export.py', Path(__file__))
    add('README.md', HERE / (BASE + '-README.md'))
    memory = io.BytesIO()
    with gzip.GzipFile(fileobj=memory, mode='wb', filename='', mtime=0, compresslevel=9) as compressed:
        with tarfile.open(fileobj=compressed, mode='w', format=tarfile.USTAR_FORMAT) as archive:
            for name, (data, _) in sorted(files.items()):
                info = tarfile.TarInfo(name)
                info.size = len(data)
                info.mode = 0o644
                info.mtime = info.uid = info.gid = 0
                info.uname = info.gname = ''
                archive.addfile(info, io.BytesIO(data))
    raw = memory.getvalue()
    destination = HERE / (BASE + '-reproduction.tar.gz')
    destination.write_bytes(raw)
    with tarfile.open(destination, 'r:gz') as archive:
        assert len(archive.getmembers()) == len(files)
        for member in archive.getmembers():
            assert member.isfile() and archive.extractfile(member).read() == files[member.name][0]
    historical = ROOT / 'test/gc_prototype/results/2026-10-13-copy-scan-source-reproduction.tar.gz'
    assert sha(historical.read_bytes()) == '0e76460f8d7a06c32bb83ebb0c304c81bbe8c51efc3d44d34ecd3490264ee067'
    suite = json.loads((FULL / 'postrun-audit.json').read_text())
    verifier = json.loads((INDEPENDENT / 'postrun-audit.json').read_text())
    manifest = {
        'status': 'correctness PASS; no Variant V timings, installation or production integration',
        'baseline_commit': '85c364304684c44c544957c8ba2b180d15d736c5',
        'workspace_execution_head': json.loads((FULL / 'preparation.json').read_text())['workspace_head'],
        'candidate_gc_sha256': suite['candidate_gc_sha256'],
        'historical_source_archive': {'path': str(historical.relative_to(ROOT)), 'sha256': sha(historical.read_bytes()), 'bytes': historical.stat().st_size,
            'status': 'original source-only evidence unchanged; all 17 decoded members retained under independent/restore'},
        'archive': {'filename': destination.name, 'sha256': sha(raw), 'bytes': len(raw), 'member_count': len(files),
            'decoded_member_bytes': sum(len(data) for data, _ in files.values()),
            'determinism': 'sorted USTAR members, zero uid/gid/mtime, mode0644; gzip mtime0/no filename; every decoded member byte-verified'},
        'full_suite': {'actual_exit': 0, 'positive_fixture_processes': 203, 'expected_negative_processes': 10,
            'successful_builds': 24, 'default_sanitizer_link_failures_preserved': 5,
            'execution_sha256': sha((FULL / 'execution.json').read_bytes()),
            'postrun_audit_sha256': sha((FULL / 'postrun-audit.json').read_bytes())},
        'targeted_verifier': {'actual_exit': verifier['actual_verifier_process_exit_status'],
            'positive_fixture_processes': 22, 'expected_named_negative_processes': 7,
            'positive_cases': 11, 'paired_stages': 12, 'raw_stats_snapshots': 24,
            'exact_fields_per_snapshot': 46, 'numeric_fields_per_snapshot': 45,
            'successful_builds': 9, 'default_sanitizer_link_failures_preserved': 9},
        'timing_plan': {'status': 'proposed only; unimplemented and unexecuted', 'sha256': '034474f797161138c57abe825ebb6157bd41be90e8ee2bb394d19efa116acc9c'},
        'omissions': ['Rebuildable binaries omitted; all 24 full-suite and nine targeted build hashes preserved in execution records.',
            'Compiler, Boehm and sanitizer libraries are external toolchain dependencies, recorded by hashes; no full host replay claim.'],
        'members': [{'path': name, 'bytes': len(data), 'sha256': sha(data), 'origin_path': origin}
            for name, (data, origin) in sorted(files.items())],
        'readme_sha256': sha((HERE / (BASE + '-README.md')).read_bytes()),
    }
    manifest_path = HERE / (BASE + '-manifest.json')
    manifest_path.write_text(json.dumps(manifest, indent=2) + '\n')
    print(json.dumps({'archive': manifest['archive'], 'manifest_sha256': sha(manifest_path.read_bytes()),
        'readme_sha256': manifest['readme_sha256']}))

if __name__ == '__main__':
    main()
