#!/usr/bin/env python3
"""Restore/check pinned inputs; run workloads only with explicit --execute."""
import argparse
import hashlib
import importlib.util
from pathlib import Path
import shutil
import sys

HERE = Path(__file__).resolve().parent

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--repo', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--execute', action='store_true')
    args = parser.parse_args()
    root = args.repo.resolve()
    output = args.output.resolve()
    if output.exists():
        raise RuntimeError('use a new output directory to preserve all prior attempts')
    inputs = HERE / 'full-suite/inputs'
    for path in inputs.rglob('*'):
        if path.is_file() and path.name not in ('gc.c', 'gc.h', 'workload.c'):
            actual = root / 'test/gc_prototype' / path.relative_to(inputs)
            if not actual.is_file() or digest(actual) != digest(path):
                raise RuntimeError('repository helper/fixture differs: ' + str(actual))
    output.mkdir(parents=True)
    shutil.copytree(HERE / 'full-suite/observer', output / 'observer')
    spec = importlib.util.spec_from_file_location('frozen_v_correctness', HERE / 'full-suite/run_review.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    module.ROOT = root
    module.OUT = output
    module.FROZEN = HERE / 'independent/restore/sources'
    module.INPUTS = output / 'inputs'
    module.PINNED_REPO = output / 'pinned_repo'
    sys.argv = ['run_review.py'] + (['--execute'] if args.execute else [])
    module.main()

if __name__ == '__main__':
    main()
